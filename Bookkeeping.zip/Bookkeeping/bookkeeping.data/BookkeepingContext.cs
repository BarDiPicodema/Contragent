﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;

namespace Bookkeeping.Data
{
    [DbConfigurationType(typeof (BookkeepingConfiguration))]
    public class BookkeepingContext : DbContext
    {
        public BookkeepingContext (string connectionName)
            : base (connectionName)
        {
            // without it not called OnModelCreating
            Database.Initialize (true);
            this.Configuration.LazyLoadingEnabled = false;
        }

        protected override void OnModelCreating (DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<BookkeepingContext> (new BookkeepingDatabaseInitializer ());
            modelBuilder.HasDefaultSchema ("MYKA_SCHEMA");
            BookkeepingConfiguration.Configure (modelBuilder);
        }

        [EF.AssociationName ("Типы доступа")]
        public DbSet<AccessType> AccessTypes { get; set; }
        public DbSet<Flag> Flags { get; set; }
        [EF.AssociationName ("Типы важности")]
        public DbSet<Signing> Signing { get; set; }

        [EF.AssociationName ("ОКАТО", EF.FieldOperation.Filter)]
        public DbSet<Okato> Okato { get; set; }
        [EF.AssociationName ("ОКФС", EF.FieldOperation.Filter)]
        public DbSet<Okfs> Okfs { get; set; }
        [EF.AssociationName ("ОКОГУ", EF.FieldOperation.Filter)]
        public DbSet<Okogu> Okogu { get; set; }
        [EF.AssociationName ("ОКОПФ", EF.FieldOperation.Filter)]
        public DbSet<Okopf> Okopf { get; set; }
        [EF.AssociationName ("ОКСМ", EF.FieldOperation.Filter)]
        public DbSet<Oksm> Oksm { get; set; }
        [EF.AssociationName ("ОКВ", EF.FieldOperation.Filter)]
        public DbSet<Okv> Okv { get; set; }
        [EF.AssociationName ("ОКВЭД", EF.FieldOperation.Filter)]
        public DbSet<Okved> Okved { get; set; }
        [EF.AssociationName ("СОНО", EF.FieldOperation.Filter)]
        public DbSet<Sono> Sono { get; set; }

        public DbSet<User> Users { get; set; }
        public DbSet<UserGrant> UserGrants { get; set; }
        public DbSet<Departament> Departaments { get; set; }

        [EF.AssociationName ("Партнеры", EF.FieldOperation.FilterSearch, isTableFiltred: true)]
        public DbSet<Partner> Partners { get; set; }
        [EF.AssociationName ("Физ. лица", EF.FieldOperation.FilterSearch, isTableFiltred: true)]
        public DbSet<Individual> Individuals { get; set; }
        [EF.AssociationName ("Юр. лица", EF.FieldOperation.FilterSearch, isTableFiltred: true)]
        public DbSet<Entrepreneur> Entrepreneurs { get; set; }

        [EF.AssociationName ("Классификаторы")]
        public DbSet<Classifier> Classifiers { get; set; }

        [EF.AssociationName ("Спецификации")]
        public DbSet<Specification> Specifications { get; set; }

        [EF.AssociationName ("Тип счета", EF.FieldOperation.Filter)]
        public DbSet<AccountType> AccountTypes { get; set; }
        [EF.AssociationName ("Вид счета", EF.FieldOperation.Filter)]
        public DbSet<AccountKind> AccountKinds { get; set; }
        [EF.AssociationName ("Счета", EF.FieldOperation.Filter)]
        public DbSet<Account> Accounts { get; set; }

        [EF.AssociationName ("Тип адреса", EF.FieldOperation.Filter)]
        public DbSet<AddressType> AddressTypes { get; set; }
        [EF.AssociationName ("Адреса", EF.FieldOperation.Filter)]
        public DbSet<Address> Addresses { get; set; }
        [EF.AssociationName ("Другие типы адресов")]
        public DbSet<AddressValue> AddressValue { get; set; }

        [EF.AssociationName ("Тип контакта", EF.FieldOperation.Filter)]
        public DbSet<ContactType> ContactTypes { get; set; }
        [EF.AssociationName ("Контакты", EF.FieldOperation.Filter)]
        public DbSet<Contact> Contacts { get; set; }

        [EF.AssociationName ("Тип процесса", EF.FieldOperation.Filter)]
        public DbSet<ProcessType> ProcessTypes { get; set; }
        [EF.AssociationName ("Процессы", EF.FieldOperation.Filter)]
        public DbSet<Process> Process { get; set; }

        [EF.AssociationName ("Ссылки")]
        public DbSet<Link> Links { get; set; }
        [EF.AssociationName ("Тип документа", EF.FieldOperation.Filter)]
        public DbSet<DocumentType> DocumentTypes { get; set; }
        [EF.AssociationName ("Документы", EF.FieldOperation.Filter)]
        public DbSet<Document> Documents { get; set; }
        [EF.AssociationName ("Участники")]
        public DbSet<DocumentParticipant> DocumentParticipant { get; set; }

        [EF.AssociationName ("Типы групп")]
        public DbSet<GroupType> GroupTypes { get; set; }
        public DbSet<GroupTypeToType> GroupTypeToTypes { get; set; }
        [EF.AssociationName ("Группы")]
        public DbSet<Group> Groups { get; set; }

        public DbSet<AssociationTable> AssociationTables { get; set; }

        public DbSet<Filter> Filters { get; set; }
        public DbSet<QueryNode> QueryNodes { get; set; }
        public DbSet<FilterValue> FilterValues { get; set; }
    }
}
