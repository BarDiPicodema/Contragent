﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.Interface
{
    public interface ITypeEntity
    {
        string TypeName { get; set; }
    }
}
