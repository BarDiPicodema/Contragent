﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data
{
    public interface IEntity
    {
        decimal Id {get; set;}
    }

    public class Entity : IEntity
    {
        public decimal Id { get; set; }
    }
}
