﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.Data.Interface
{
    public interface IAccessData
    {
        decimal IdAccessType { get; set; }
        AccessType AccessType { get; set; }
    }
}
