﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.Interface
{
    public interface IExtraType
    {
        string TypeName { get; set; }
        byte[] TypeImage { get; set; }
        string TypeColor { get; set; }
        string FontStyle { get; set; }
    }
}
