﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.Data.Interface
{
    public interface ICounterparties : IAccessData
    {
        string Alias { get; set; }

        StateEntity IsDelete { get; set; }

        decimal IdSigning { get; set; }
        [EF.Include]
        Signing Signing { get; set; }

        decimal IdFlag { get; set; }
        [EF.Include]
        Flag Flag { get; set; }

        ICollection<Address> Addresses { get; set; }
        ICollection<Account> Accounts { get; set; }
        ICollection<Contact> Contacts { get; set; }
        ICollection<Specification> Specifications { get; set; }
        ICollection<Process> Processes { get; set; }
        ICollection<Document> Documents { get; set; }
        ICollection<DocumentParticipant> Participant { get; set; } 
        ICollection<Group> Groups { get; set; }
    }
}
