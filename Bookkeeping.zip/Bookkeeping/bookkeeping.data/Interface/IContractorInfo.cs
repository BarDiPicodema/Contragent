﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.Interface
{
    public interface IContractorInfo
    {
        decimal? IdPartner { get; set; }
        Partner Partner { get; set; }

        decimal? IdIndividual { get; set; }
        Individual Individual { get; set; }

        decimal? IdEntrepreneur { get; set; }
        Entrepreneur Entrepreneur { get; set; }
    }
}
