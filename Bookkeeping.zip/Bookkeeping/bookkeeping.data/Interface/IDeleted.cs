﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.Interface
{
    public enum StateEntity
    {
        [Display (Name = "Существующая запись")]
        ExistsEntity,
        [Display (Name = "Удаленная запись")]
        DeleteEntity
    };
}
