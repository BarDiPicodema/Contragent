﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;
using System.Data.Entity.Infrastructure.Annotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Bookkeeping.Data
{
    public class BookkeepingConfiguration : System.Data.Entity.DbConfiguration
    {
        public BookkeepingConfiguration ()
        {
            SetProviderServices("Oracle.ManagedDataAccess.Client", Oracle.ManagedDataAccess.EntityFramework.EFOracleProviderServices.Instance);
        }

        public static void Configure (DbModelBuilder modelBuilder)
        {
            #region User data
            modelBuilder.Entity<Departament> ().ToTable ("DEPARTAMENTS");
            ConfigureEntity<Departament> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<Departament> ().Property (p => p.NameDepartament).HasMaxLength (220).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NAMEDEPARTAMENT"), "UniqNameDepartament");

            modelBuilder.Entity<User> ().ToTable ("USERS");
            ConfigureEntity<User> (modelBuilder);
            modelBuilder.Entity<User> ().HasRequired (p => p.Departament).WithMany (b => b.Users).HasForeignKey (p => p.IdDepartament);
            modelBuilder.Entity<User> ().Property (p => p.IdDepartament).HasColumnName ("IDDEPARTAMENT");
            modelBuilder.Entity<User> ().Property (p => p.Name).HasMaxLength (100).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            ConfigureUniqueString (modelBuilder.Entity<User> ().Property (p => p.Login).HasMaxLength (50).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("LOGIN"), "UniqLogin");
            modelBuilder.Entity<User> ().Property (p => p.Password).HasMaxLength (255).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("PASSWORD");
            modelBuilder.Entity<User> ().Property (p => p.Post).HasMaxLength (150).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("POST");
            modelBuilder.Entity<User> ().Property (p => p.IsDelete).HasColumnName ("ISDELETE");

            modelBuilder.Entity<UserGrant> ().ToTable ("USERGRANTS");
            ConfigureEntity<UserGrant> (modelBuilder);
            modelBuilder.Entity<UserGrant> ().Property (p => p.PrivateData).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.OverallData).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.TheirPersonal).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.HisDepartament).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.ForeignPrivate).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.ForeignPersonal).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.TaskDepartament).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.OtherPersonal).IsOptional ();
            modelBuilder.Entity<UserGrant> ().Property (p => p.OtherDepartament).IsOptional ();

            /// link each on other
            modelBuilder.Entity<User> ().HasRequired (p => p.UserGrant).WithMany (b => b.Users).HasForeignKey (p => p.IdGrant);
            modelBuilder.Entity<User> ().Property (p => p.IdGrant).HasColumnName ("IDGRANT");
            #endregion

            #region EX data
            modelBuilder.Entity<Signing> ().ToTable ("SIGNING");
            ConfigureEntity<Signing> (modelBuilder);
            modelBuilder.Entity<Signing> ().Property (p => p.TypeName).HasMaxLength (50).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("SIGNINGNAME");
            modelBuilder.Entity<Signing> ().Property (p => p.TypeImage).IsOptional ().HasColumnName ("SIGNINGIMAGE");
            modelBuilder.Entity<Signing> ().Property (p => p.FontStyle).HasMaxLength (100).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SIGNINGFONTSTYPE");
            modelBuilder.Entity<Signing> ().Property (p => p.TypeColor).HasMaxLength (100).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SIGNINGCOLOR");

            modelBuilder.Entity<AccessType> ().ToTable ("ACCESSTYPES");
            ConfigureEntity<AccessType> (modelBuilder);
            modelBuilder.Entity<AccessType> ().Property (p => p.TypeName).HasMaxLength (70).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TYPENAME");
            modelBuilder.Entity<AccessType> ().HasOptional (p => p.User).WithMany (c => c.AccessTypes).HasForeignKey (p => p.IdUser);
            modelBuilder.Entity<AccessType> ().Property (p => p.IdUser).IsOptional ().HasColumnName ("IDUSER");
            modelBuilder.Entity<AccessType> ().HasOptional (p => p.Departament).WithMany (c => c.AccessTypes).HasForeignKey (p => p.IdDepartament);
            modelBuilder.Entity<AccessType> ().Property (p => p.IdDepartament).IsOptional ().HasColumnName ("IDDEPARTAMENT");
            modelBuilder.Entity<AccessType> ().Property (p => p.IsPrivate).IsOptional ().HasColumnName ("ISPRIVATE");

            modelBuilder.Entity<Flag> ().ToTable ("FLAGS");
            ConfigureEntity<Flag> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<Flag> ().Property (p => p.Name).HasMaxLength (50).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("FLAGNAME"), "UniqFlagName");
            modelBuilder.Entity<Flag> ().Property (p => p.TypeName).HasMaxLength (50).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("FLAGTYPE");
            modelBuilder.Entity<Flag> ().Property (p => p.TypeImage).IsOptional ().HasColumnName ("FLAGIMAGE");
            modelBuilder.Entity<Flag> ().Property (p => p.FontStyle).HasMaxLength (100).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("FLAGFONTSTYLE");
            modelBuilder.Entity<Flag> ().Property (p => p.TypeColor).HasMaxLength (100).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("FLAGCOLOR");
            #endregion

            #region Clasificators
            modelBuilder.Entity<Okopf> ().ToTable ("OKOPF");
            ConfigureEntity<Okopf> (modelBuilder);
            modelBuilder.Entity<Okopf> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Okopf> ().Property (p => p.Title).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TITLE");

            modelBuilder.Entity<Okogu> ().ToTable ("OKOGU");
            ConfigureEntity<Okogu> (modelBuilder);
            modelBuilder.Entity<Okogu> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Okogu> ().Property (p => p.Title).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TITLE");
            modelBuilder.Entity<Okogu> ().Property (p => p.FullName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("FULLNAME");

            modelBuilder.Entity<Okved> ().ToTable ("OKVED");
            ConfigureEntity<Okved> (modelBuilder);
            modelBuilder.Entity<Okved> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Okved> ().Property (p => p.Title).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TITLE");

            modelBuilder.Entity<Okv> ().ToTable ("OKV");
            ConfigureEntity<Okv> (modelBuilder);
            modelBuilder.Entity<Okv> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Okv> ().Property (p => p.CharCode).HasMaxLength (10).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("CHARCODE");
            modelBuilder.Entity<Okv> ().Property (p => p.Name).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Okv> ().Property (p => p.Countries).HasMaxLength (780).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("COUNTRIES");

            modelBuilder.Entity<Okato> ().ToTable ("OKATO");
            ConfigureEntity<Okato> (modelBuilder);
            modelBuilder.Entity<Okato> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Okato> ().Property (p => p.Region).HasMaxLength (100).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("REGION");
            modelBuilder.Entity<Okato> ().Property (p => p.City).HasMaxLength (100).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("CITY");
            modelBuilder.Entity<Okato> ().Property (p => p.OktmoCode).IsRequired ().HasColumnName ("OKTMOCODE");
            modelBuilder.Entity<Okato> ().Property (p => p.MunicipalForm).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("MUNICIPALFORM");

            modelBuilder.Entity<Oksm> ().ToTable ("OKSM");
            ConfigureEntity<Oksm> (modelBuilder);
            modelBuilder.Entity<Oksm> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Oksm> ().Property (p => p.Name).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Oksm> ().Property (p => p.FullName).HasMaxLength (2000).IsOptional().HasColumnType ("VARCHAR2").HasColumnName ("FULLNAME");
            modelBuilder.Entity<Oksm> ().Property (p => p.Alpha2).HasMaxLength (4).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("ALPHA2");
            modelBuilder.Entity<Oksm> ().Property (p => p.Alpha3).HasMaxLength (6).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("ALPHA3");

            modelBuilder.Entity<Okfs> ().ToTable ("OKFS");
            ConfigureEntity<Okfs> (modelBuilder);
            modelBuilder.Entity<Okfs> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Okfs> ().Property (p => p.Title).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TITLE");
            modelBuilder.Entity<Okfs> ().Property (p => p.CollectionAlgorithm).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("COLLECTIONALGORITHM");

            modelBuilder.Entity<Sono> ().ToTable ("SONO");
            ConfigureEntity<Sono> (modelBuilder);
            modelBuilder.Entity<Sono> ().Property (p => p.NumberCode).HasMaxLength (30).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NUMBERCODE");
            modelBuilder.Entity<Sono> ().Property (p => p.Title).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TITLE");
            #endregion

            #region Client data
            modelBuilder.Entity<Partner> ().ToTable ("PARTNERS");
            ConfigureEntity<Partner> (modelBuilder);
            modelBuilder.Entity<Partner> ().HasRequired (p => p.Curator).WithMany (b => b.Partners).HasForeignKey (p => p.IdUser);
            modelBuilder.Entity<Partner> ().Property (p => p.IdUser).HasColumnName ("IDUSER");
            modelBuilder.Entity<Partner> ().Property (p => p.Alias).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("ALIAS");
            modelBuilder.Entity<Partner> ().Property (p => p.Region).HasMaxLength (100).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("REGION");
            modelBuilder.Entity<Partner> ().Property (p => p.Activity).HasMaxLength (255).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("ACTIVITY");
            modelBuilder.Entity<Partner> ().Property (p => p.IsDelete).IsOptional ().HasColumnName ("ISDELETE");
            modelBuilder.Entity<Partner> ().HasRequired (p => p.Signing).WithMany (b => b.Partners).HasForeignKey (p => p.IdSigning);
            modelBuilder.Entity<Partner> ().Property (p => p.IdSigning).HasColumnName ("IDSIGNING");
            modelBuilder.Entity<Partner> ().Property (p => p.IdFlag).HasColumnName ("IDFLAG");
            modelBuilder.Entity<Partner> ().HasRequired (p => p.Flag).WithMany (b => b.Partners).HasForeignKey (p => p.IdFlag);
            modelBuilder.Entity<Partner> ().Property (p => p.IdAccessType).HasColumnName ("IDACCESSTYPE");
            modelBuilder.Entity<Partner> ().HasRequired (p => p.AccessType).WithMany (b => b.Partners).HasForeignKey (p => p.IdAccessType);

            modelBuilder.Entity<Entrepreneur> ().ToTable ("ENTREPRENEURS");
            ConfigureEntity<Entrepreneur> (modelBuilder);
            modelBuilder.Entity<Entrepreneur> ().HasRequired (p => p.Partner).WithMany (b => b.Entreperneurs).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.Alias).HasMaxLength (250).IsOptional().HasColumnType ("VARCHAR2").HasColumnName ("ALIAS");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.Name).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.BriefName).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("BRIEFNAME");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.ForeignName).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("FOREIGNNAME");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.RegistrationDate).IsOptional ().HasColumnName ("REGISTRATIONDATE");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.Ogrn).HasMaxLength (30).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("OGRN");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.INN).HasMaxLength (24).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("INN");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.KPP).HasMaxLength (18).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("KPP");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.Okpo).HasMaxLength (20).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("OKPO");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.Icon).HasColumnName ("ICON");
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IsDelete).IsOptional ().HasColumnName ("ISDELETE");
            modelBuilder.Entity<Entrepreneur> ().HasOptional (p => p.Okopf).WithMany (b => b.Entrepreneurs).HasForeignKey (p => p.IdOkopf);
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IdOkopf).HasColumnName ("IDOKOPF");
            modelBuilder.Entity<Entrepreneur> ().HasOptional (p => p.Okfs).WithMany (b => b.Entrepreneurs).HasForeignKey (p => p.IdOkfs);
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IdOkfs).HasColumnName ("IDOKFS");
            modelBuilder.Entity<Entrepreneur> ().HasOptional (p => p.Okogu).WithMany (b => b.Entrepreneurs).HasForeignKey (p => p.IdOkogu);
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IdOkogu).HasColumnName ("IDOKOGU");
            modelBuilder.Entity<Entrepreneur> ().HasRequired (p => p.Signing).WithMany (b => b.Entrepreneurs).HasForeignKey (p => p.IdSigning);
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IdSigning).HasColumnName ("IDSIGNING");
            modelBuilder.Entity<Entrepreneur> ().HasRequired (p => p.Flag).WithMany (b => b.Entrepreneurs).HasForeignKey (p => p.IdFlag);
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IdFlag).HasColumnName ("IDFLAG");
            modelBuilder.Entity<Entrepreneur> ().HasRequired (p => p.AccessType).WithMany (b => b.Entrepreneurs).HasForeignKey (p => p.IdAccessType);
            modelBuilder.Entity<Entrepreneur> ().Property (p => p.IdAccessType).HasColumnName ("IDACCESSTYPE");

            modelBuilder.Entity<Classifier> ().ToTable ("CLASSIFIERS");
            ConfigureEntity<Classifier> (modelBuilder);
            modelBuilder.Entity<Classifier> ().HasRequired (p => p.Entrepreneur).WithMany (b => b.Classifiers).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Classifier> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Classifier> ().HasOptional (p => p.Oksm).WithMany (b => b.Classifiers).HasForeignKey (p => p.IdOksm);
            modelBuilder.Entity<Classifier> ().Property (p => p.IdOksm).HasColumnName ("IDOKSM");
            modelBuilder.Entity<Classifier> ().HasOptional (p => p.Okato).WithMany (b => b.Classifiers).HasForeignKey (p => p.IdOkato);
            modelBuilder.Entity<Classifier> ().Property (p => p.IdOkato).HasColumnName ("IDOKATO");
            modelBuilder.Entity<Classifier> ().HasOptional (p => p.Okved).WithMany (b => b.Classifiers).HasForeignKey (p => p.IdOkved);
            modelBuilder.Entity<Classifier> ().Property (p => p.IdOkved).HasColumnName ("IDOKVED");

            modelBuilder.Entity<Individual> ().ToTable ("INDIVIDUALS");
            ConfigureEntity<Individual> (modelBuilder);
            modelBuilder.Entity<Individual> ().HasRequired (p => p.Partner).WithMany (b => b.Individuals).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Individual> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Individual> ().Property (p => p.Alias).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("ALIAS");
            modelBuilder.Entity<Individual> ().Property (p => p.Name).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Individual> ().Property (p => p.SecondName).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SECONDNAME");
            modelBuilder.Entity<Individual> ().Property (p => p.MiddleName).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("MIDDLENAME");
            modelBuilder.Entity<Individual> ().Property (p => p.Sex).IsOptional ().HasColumnName ("SEX");
            modelBuilder.Entity<Individual> ().Property (p => p.BirthDate).IsOptional ().HasColumnName ("BIRTHDATE");
            modelBuilder.Entity<Individual> ().Property (p => p.BirthPlace).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("BIRTHPLACE");
            modelBuilder.Entity<Individual> ().Property (p => p.Citizenship).HasMaxLength (20).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("CITIZENSHIP");
            modelBuilder.Entity<Individual> ().Property (p => p.INN).HasMaxLength (24).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("INN");
            modelBuilder.Entity<Individual> ().Property (p => p.Nationality).HasMaxLength (12).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("NATIONALITY");
            modelBuilder.Entity<Individual> ().Property (p => p.Note).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("NOTE");
            modelBuilder.Entity<Individual> ().Property (p => p.InfoWork).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("INFOWORK");
            modelBuilder.Entity<Individual> ().Property (p => p.BloodGroup).HasMaxLength (20).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("BLOODGROUP");
            modelBuilder.Entity<Individual> ().Property (p => p.Snils).HasMaxLength (28).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SNILS");
            modelBuilder.Entity<Individual> ().Property (p => p.Med).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("MED");
            modelBuilder.Entity<Individual> ().Property (p => p.Icon).HasColumnName ("ICON");
            modelBuilder.Entity<Individual> ().Property (p => p.IsDelete).IsOptional ().HasColumnName ("ISDELETE");
            modelBuilder.Entity<Individual> ().HasRequired (p => p.Signing).WithMany (b => b.Individuals).HasForeignKey (p => p.IdSigning);
            modelBuilder.Entity<Individual> ().Property (p => p.IdSigning).HasColumnName ("IDSIGNING");
            modelBuilder.Entity<Individual> ().HasRequired (p => p.Flag).WithMany (b => b.Individuals).HasForeignKey (p => p.IdFlag);
            modelBuilder.Entity<Individual> ().Property (p => p.IdFlag).HasColumnName ("IDFLAG");
            modelBuilder.Entity<Individual> ().HasRequired (p => p.AccessType).WithMany (b => b.Individuals).HasForeignKey (p => p.IdAccessType);
            modelBuilder.Entity<Individual> ().Property (p => p.IdAccessType).HasColumnName ("IDACCESSTYPE");
            #endregion

            #region Process data
            modelBuilder.Entity<ProcessType> ().ToTable ("PROCESSTYPES");
            ConfigureEntity<ProcessType> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<ProcessType> ().Property (p => p.TypeName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TYPENAME"), "UniqProcessType");

            modelBuilder.Entity<Process> ().ToTable ("PROCESS");
            ConfigureEntity<Process> (modelBuilder);
            modelBuilder.Entity<Process> ().HasRequired (p => p.ProcessType).WithMany (b => b.Processes).HasForeignKey (p => p.IdProcessType);
            modelBuilder.Entity<Process> ().Property (p => p.IdProcessType).HasColumnName ("IDPROCESSTYPE");
            modelBuilder.Entity<Process> ().HasOptional (p => p.Entrepreneur).WithMany (b => b.Processes).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Process> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Process> ().HasOptional (p => p.Partner).WithMany (b => b.Processes).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Process> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Process> ().HasOptional (p => p.Individual).WithMany (b => b.Processes).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<Process> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<Process> ().Property (p => p.ProcessBegin).IsRequired ().HasColumnName ("PROCESSBEGIN");
            modelBuilder.Entity<Process> ().Property (p => p.ProcessEnd).IsOptional ().HasColumnName ("PROCESSEND");
            #endregion

            #region Specification data
            modelBuilder.Entity<Specification> ().ToTable ("SPECIFICATIONS");
            ConfigureEntity<Specification> (modelBuilder);
            modelBuilder.Entity<Specification> ().HasOptional (p => p.Entrepreneur).WithMany (b => b.Specifications).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Specification> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Specification> ().HasOptional (p => p.Partner).WithMany (b => b.Specifications).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Specification> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<Specification> ().HasOptional (p => p.Individual).WithMany (b => b.Specifications).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<Specification> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Specification> ().Property (p => p.SpecificationText).HasMaxLength (4000).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("SPECIFICATIONTEXT");
            modelBuilder.Entity<Specification> ().Property (p => p.SpecificationTextStyle).IsRequired ().HasColumnName ("SPECIFICATIONTEXTSTYLE");
            #endregion

            #region Address data
            modelBuilder.Entity<AddressType> ().ToTable ("ADDRESSTYPES");
            ConfigureEntity<AddressType> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<AddressType> ().Property (p => p.TypeName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TYPENAME"), "UniqAddressType");

            modelBuilder.Entity<Address> ().ToTable ("ADDRESSES");
            ConfigureEntity<Address> (modelBuilder);
            modelBuilder.Entity<Address> ().HasRequired (p => p.AddressType).WithMany (b => b.Addresses).HasForeignKey (p => p.IdAddressType);
            modelBuilder.Entity<Address> ().Property (p => p.IdAddressType).HasColumnName ("IDADDRESSTYPE");
            modelBuilder.Entity<Address> ().HasOptional (p => p.Entrepreneur).WithMany (b => b.Addresses).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Address> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Address> ().HasOptional (p => p.Partner).WithMany (b => b.Addresses).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Address> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Address> ().HasOptional (p => p.Individual).WithMany (b => b.Addresses).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<Address> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<Address> ().Property (p => p.PostIndex).HasMaxLength (12).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("POSTINDEX");
            modelBuilder.Entity<Address> ().Property (p => p.Land).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("LAND");
            modelBuilder.Entity<Address> ().Property (p => p.Area).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("AREA");
            modelBuilder.Entity<Address> ().Property (p => p.City).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("CITY");
            modelBuilder.Entity<Address> ().Property (p => p.Settlement).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SETTLEMENT");
            modelBuilder.Entity<Address> ().Property (p => p.Street).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("STREET");
            modelBuilder.Entity<Address> ().Property (p => p.House).HasMaxLength (32).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("HOUSE");
            modelBuilder.Entity<Address> ().Property (p => p.Structure).HasMaxLength (32).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("STRUCTURE");
            modelBuilder.Entity<Address> ().Property (p => p.Porch).HasMaxLength (32).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("PORCH");
            modelBuilder.Entity<Address> ().Property (p => p.Office).HasMaxLength (32).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("OFFICE");
            modelBuilder.Entity<Address> ().HasOptional (p => p.Okato).WithMany (b => b.Addresses).HasForeignKey (p => p.IdOkato);
            modelBuilder.Entity<Address> ().Property (p => p.IdOkato).HasColumnName ("IDOKATO");
            modelBuilder.Entity<Address> ().HasOptional (p => p.Oksm).WithMany (b => b.Addresses).HasForeignKey (p => p.IdOksm);
            modelBuilder.Entity<Address> ().Property (p => p.IdOksm).HasColumnName ("IDOKSM");
            modelBuilder.Entity<Address> ().HasOptional (p => p.Sono).WithMany (b => b.Addresses).HasForeignKey (p => p.IdSono);
            modelBuilder.Entity<Address> ().Property (p => p.IdSono).HasColumnName ("IDSONO");
            modelBuilder.Entity<Address> ().Property (p => p.Name).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Address> ().Property (p => p.Soun).HasMaxLength (10).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SOUN");
            modelBuilder.Entity<Address> ().Property (p => p.Kladr).HasMaxLength (50).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("KLADR");
            modelBuilder.Entity<Address> ().Property (p => p.Description).HasMaxLength (4000).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("DESCRIPTION");
            modelBuilder.Entity<Address> ().HasRequired (p => p.Flag).WithMany (b => b.Addresses).HasForeignKey (p => p.IdFlag);
            modelBuilder.Entity<Address> ().Property (p => p.IdFlag).HasColumnName ("IDFLAG");
            modelBuilder.Entity<Address> ().HasRequired (p => p.AccessType).WithMany (b => b.Addresses).HasForeignKey (p => p.IdAccessType);
            modelBuilder.Entity<Address> ().Property (p => p.IdAccessType).HasColumnName ("IDACCESSTYPE");

            modelBuilder.Entity<AddressValue> ().ToTable ("ADDRESSVALUES");
            ConfigureEntity<AddressValue> (modelBuilder);
            modelBuilder.Entity<AddressValue> ().HasRequired (p => p.Address).WithMany (b => b.AddressValues).HasForeignKey (p => p.IdAddress);
            modelBuilder.Entity<AddressValue> ().Property (p => p.IdAddress).HasColumnName ("IDADDRESS");
            modelBuilder.Entity<AddressValue> ().HasRequired (p => p.AddressType).WithMany (b => b.AddressValues).HasForeignKey (p => p.IdAddressType);
            modelBuilder.Entity<AddressValue> ().Property (p => p.IdAddressType).HasColumnName ("IDADDRESSTYPE");
            #endregion

            #region Contact data
            modelBuilder.Entity<ContactType> ().ToTable ("CONTACTTYPES");
            ConfigureEntity<ContactType> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<ContactType> ().Property (p => p.TypeName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TYPENAME"), "UniqContactType");

            modelBuilder.Entity<Contact> ().ToTable ("CONTACTS");
            ConfigureEntity<Contact> (modelBuilder);
            modelBuilder.Entity<Contact> ().HasRequired (p => p.ContactType).WithMany (b => b.Contacts).HasForeignKey (p => p.IdContactType);
            modelBuilder.Entity<Contact> ().Property (p => p.IdContactType).HasColumnName ("IDCONTACTTYPE");
            modelBuilder.Entity<Contact> ().HasOptional (p => p.Entrepreneur).WithMany (b => b.Contacts).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Contact> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Contact> ().HasOptional (p => p.Partner).WithMany (b => b.Contacts).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Contact> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Contact> ().HasOptional (p => p.Individual).WithMany (b => b.Contacts).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<Contact> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<Contact> ().Property (p => p.ContactText).HasMaxLength (150).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("CONTACTTEXT");
            modelBuilder.Entity<Contact> ().Property (p => p.Name).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Contact> ().Property (p => p.Post).HasMaxLength (150).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("POST");
            modelBuilder.Entity<Contact> ().Property (p => p.Sub).HasMaxLength (150).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SUB");
            modelBuilder.Entity<Contact> ().Property (p => p.Description).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("DESCRIPTION");
            modelBuilder.Entity<Contact> ().HasRequired (p => p.Flag).WithMany (b => b.Contacts).HasForeignKey (p => p.IdFlag);
            modelBuilder.Entity<Contact> ().Property (p => p.IdFlag).HasColumnName ("IDFLAG");
            modelBuilder.Entity<Contact> ().HasRequired (p => p.AccessType).WithMany (b => b.Contacts).HasForeignKey (p => p.IdAccessType);
            modelBuilder.Entity<Contact> ().Property (p => p.IdAccessType).HasColumnName ("IDACCESSTYPE");
            #endregion

            #region Account data
            modelBuilder.Entity<AccountKind> ().ToTable ("ACCOUNTKINDS");
            ConfigureEntity<AccountKind> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<AccountKind> ().Property (p => p.TypeName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TYPENAME"), "UniqAccountKind");

            modelBuilder.Entity<AccountType> ().ToTable ("ACCOUNTTYPES");
            ConfigureEntity<AccountType> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<AccountType> ().Property (p => p.TypeName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TYPENAME"), "UniqAccountType");

            modelBuilder.Entity<Account> ().ToTable ("ACCOUNTS");
            ConfigureEntity<Account> (modelBuilder);
            modelBuilder.Entity<Account> ().HasRequired (p => p.AccountType).WithMany (b => b.Accounts).HasForeignKey (p => p.IdAccountType);
            modelBuilder.Entity<Account> ().Property (p => p.IdAccountType).HasColumnName ("IDACCOUNTTYPE");
            modelBuilder.Entity<Account> ().HasRequired (p => p.AccountKind).WithMany (b => b.Accounts).HasForeignKey (p => p.IdAccountKind);
            modelBuilder.Entity<Account> ().Property (p => p.IdAccountKind).HasColumnName ("IDACCOUNTKIND");
            modelBuilder.Entity<Account> ().HasOptional (p => p.Entrepreneur).WithMany (b => b.Accounts).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Account> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Account> ().HasOptional (p => p.Partner).WithMany (b => b.Accounts).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Account> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Account> ().HasOptional (p => p.Individual).WithMany (b => b.Accounts).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<Account> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<Account> ().HasOptional (p => p.Okv).WithMany (b => b.Accounts).HasForeignKey (p => p.IdOkv);
            modelBuilder.Entity<Account> ().Property (p => p.IdOkv).HasColumnName ("IDOKV");
            modelBuilder.Entity<Account> ().Property (p => p.Name).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Account> ().Property (p => p.AccountNumber).HasMaxLength (50).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("ACCOUNTNUMBER");
            modelBuilder.Entity<Account> ().Property (p => p.IbanNumber).HasMaxLength (68).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("IBANNUMBER");
            modelBuilder.Entity<Account> ().Property (p => p.Bank).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("BANK");
            modelBuilder.Entity<Account> ().Property (p => p.Settlement).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SETTLEMENT");
            modelBuilder.Entity<Account> ().Property (p => p.Bic).HasMaxLength (22).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("BIC");
            modelBuilder.Entity<Account> ().Property (p => p.CorrespondentAccount).HasMaxLength (50).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("CORRESPONDENTACCOUNT");
            modelBuilder.Entity<Account> ().Property (p => p.CorrespondentBank).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("CORRESPONDENTBANK");
            modelBuilder.Entity<Account> ().Property (p => p.PersonAccount).HasMaxLength (50).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("PERSONACCOUNT");
            modelBuilder.Entity<Account> ().Property (p => p.Recipient).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("RECIPIENT");
            modelBuilder.Entity<Account> ().Property (p => p.Extra).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("EXTRA");
            modelBuilder.Entity<Account> ().Property (p => p.Description).HasMaxLength (4000).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("DESCRIPTION");
            modelBuilder.Entity<Account> ().HasRequired (p => p.Flag).WithMany (b => b.Accounts).HasForeignKey (p => p.IdFlag);
            modelBuilder.Entity<Account> ().Property (p => p.IdFlag).HasColumnName ("IDFLAG");
            modelBuilder.Entity<Account> ().HasRequired (p => p.AccessType).WithMany (b => b.Accounts).HasForeignKey (p => p.IdAccessType);
            modelBuilder.Entity<Account> ().Property (p => p.IdAccessType).HasColumnName ("IDACCESSTYPE");
            #endregion

            #region Document data
            modelBuilder.Entity<DocumentType> ().ToTable ("DOCUMENTTYPES");
            ConfigureEntity<DocumentType> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<DocumentType> ().Property (p => p.TypeName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("TYPENAME"), "UniqDocumentType");

            modelBuilder.Entity<Document> ().ToTable ("DOCUMENTS");
            ConfigureEntity<Document> (modelBuilder);
            modelBuilder.Entity<Document> ().HasRequired (p => p.DocumentType).WithMany (b => b.Documents).HasForeignKey (p => p.IdDocumentType);
            modelBuilder.Entity<Document> ().Property (p => p.IdDocumentType).HasColumnName ("IDDOCUMENTTYPE");
            modelBuilder.Entity<Document> ().HasOptional (p => p.Entrepreneur).WithMany (b => b.Documents).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Document> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Document> ().HasOptional (p => p.Partner).WithMany (b => b.Documents).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Document> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Document> ().HasOptional (p => p.Individual).WithMany (b => b.Documents).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<Document> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<Document> ().Property (p => p.Appointment).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("APPOINTMENT");
            modelBuilder.Entity<Document> ().Property (p => p.Name).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("NAME");
            modelBuilder.Entity<Document> ().Property (p => p.Series).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SERIES");
            modelBuilder.Entity<Document> ().Property (p => p.DocumentNumber).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("DOCUMENTNUMBER");
            modelBuilder.Entity<Document> ().Property (p => p.DocumentDate).IsOptional ().HasColumnName ("DOCUMENTDATE");
            modelBuilder.Entity<Document> ().Property (p => p.DocumentPlace).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("DOCUMENTPLACE");
            modelBuilder.Entity<Document> ().Property (p => p.SubdividionCode).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("SUBDIVIDIONCODE");
            modelBuilder.Entity<Document> ().Property (p => p.ExpDate).IsOptional ().HasColumnName ("EXPDATE");
            modelBuilder.Entity<Document> ().Property (p => p.Renew).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("RENEW");
            modelBuilder.Entity<Document> ().Property (p => p.Issuer).HasMaxLength (250).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("ISSUER");
            modelBuilder.Entity<Document> ().Property (p => p.Description).HasMaxLength (4000).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("DESCRIPTION");
            modelBuilder.Entity<Document> ().HasRequired (p => p.Flag).WithMany (b => b.Documents).HasForeignKey (p => p.IdFlag);
            modelBuilder.Entity<Document> ().Property (p => p.IdFlag).HasColumnName ("IDFLAG");
            modelBuilder.Entity<Document> ().HasRequired (p => p.AccessType).WithMany (b => b.Documents).HasForeignKey (p => p.IdAccessType);
            modelBuilder.Entity<Document> ().Property (p => p.IdAccessType).HasColumnName ("IDACCESSTYPE");

            modelBuilder.Entity<Link> ().ToTable ("LINKS");
            ConfigureEntity<Link> (modelBuilder);
            modelBuilder.Entity<Link> ().Property (p => p.UriLink).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("URILINK");
            modelBuilder.Entity<Link> ().Property (p => p.Description).HasMaxLength (4000).IsOptional ().HasColumnType ("VARCHAR2").HasColumnName ("DESCRIPTION");
            modelBuilder.Entity<Link> ().HasRequired (p => p.Document).WithMany (c => c.Links).HasForeignKey (p => p.IdDocument);
            modelBuilder.Entity<Link> ().Property (p => p.IdDocument).HasColumnName ("IDDOCUMENT");

            modelBuilder.Entity<DocumentParticipant> ().ToTable ("DOCUMENTPARTICIPANT");
            ConfigureEntity<DocumentParticipant> (modelBuilder);
            modelBuilder.Entity<DocumentParticipant> ().HasOptional (p => p.Partner).WithMany (c => c.Participant).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<DocumentParticipant> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<DocumentParticipant> ().HasOptional (p => p.Individual).WithMany (c => c.Participant).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<DocumentParticipant> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<DocumentParticipant> ().HasOptional (p => p.Entrepreneur).WithMany (c => c.Participant).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<DocumentParticipant> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<DocumentParticipant> ().HasRequired (p => p.Document).WithMany (c => c.Participant).HasForeignKey (p => p.IdDocument);
            modelBuilder.Entity<DocumentParticipant> ().Property (p => p.IdDocument).HasColumnName ("IDDOCUMENT");
            #endregion

            #region Group data
            modelBuilder.Entity<GroupType> ().ToTable ("GROUPTYPES");
            ConfigureEntity<GroupType> (modelBuilder);
            ConfigureUniqueString (modelBuilder.Entity<GroupType> ().Property (p => p.TypeName).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2").HasColumnName ("GROUPNAME"), "UniqGroupType");
            

            modelBuilder.Entity<GroupTypeToType> ().ToTable ("GROUPTYPETOTYPES");
            ConfigureEntity<GroupTypeToType> (modelBuilder);
            modelBuilder.Entity<GroupTypeToType> ().HasRequired (p => p.GroupTypeOne).WithMany (b => b.GroupTypeParent).HasForeignKey (p => p.IdGroupTypeOne); //(b => b.GroupTypeParent).HasForeignKey (p => p.IdGroupTypeOne);
            //modelBuilder.Entity<GroupTypeToType> ().HasRequired (p => p.GroupTypeOne).WithOptional (b => b.GroupTypeToType);
            modelBuilder.Entity<GroupTypeToType> ().Property (p => p.IdGroupTypeOne).HasColumnName ("IDGROUPTYPEONE");
            modelBuilder.Entity<GroupTypeToType> ().HasRequired (p => p.GroupTypeTwo).WithMany (b => b.GroupTypeChildren).HasForeignKey (p => p.IdGroupTypeTwo); //.HasForeignKey (p => p.IdGroupTypeTwo);
            modelBuilder.Entity<GroupTypeToType> ().Property (p => p.IdGroupTypeTwo).HasColumnName ("IDGROUPTYPETWO");
            

            modelBuilder.Entity<Group> ().ToTable ("GROUPS");
            ConfigureEntity<Group> (modelBuilder);
            modelBuilder.Entity<Group> ().HasOptional (p => p.Partner).WithMany (b => b.Groups).HasForeignKey (p => p.IdPartner);
            modelBuilder.Entity<Group> ().Property (p => p.IdPartner).HasColumnName ("IDPARTNER");
            modelBuilder.Entity<Group> ().HasOptional (p => p.Individual).WithMany (b => b.Groups).HasForeignKey (p => p.IdIndividual);
            modelBuilder.Entity<Group> ().Property (p => p.IdIndividual).HasColumnName ("IDINDIVIDUAL");
            modelBuilder.Entity<Group> ().HasOptional (p => p.Entrepreneur).WithMany (b => b.Groups).HasForeignKey (p => p.IdEntrepreneur);
            modelBuilder.Entity<Group> ().Property (p => p.IdEntrepreneur).HasColumnName ("IDENTREPRENEUR");
            modelBuilder.Entity<Group> ().HasRequired (p => p.GroupTypeToType).WithMany (b => b.Groups).HasForeignKey (p => p.IdGroupTypeToType);
            modelBuilder.Entity<Group> ().Property (p => p.IdGroupTypeToType).HasColumnName ("IDGROUPTYPETOTYPE");
            #endregion

            #region Association table and column names
            modelBuilder.Entity<AssociationTable> ().ToTable ("ASSOCIATIONTABLES");
            ConfigureEntity<AssociationTable> (modelBuilder);
            modelBuilder.Entity<AssociationTable> ().Property (p => p.NameTable).HasMaxLength (80).IsRequired ().HasColumnType ("VARCHAR2");
            modelBuilder.Entity<AssociationTable> ().Property (p => p.AssociationNameTable).HasMaxLength (80).IsRequired ().HasColumnType ("VARCHAR2");

            #endregion

            #region Filters data
            modelBuilder.Entity<Filter> ().ToTable ("FILTERS");
            ConfigureEntity<Filter> (modelBuilder);
            modelBuilder.Entity<Filter> ().Property (p => p.NameFilter).HasMaxLength (80).IsRequired ().HasColumnType ("VARCHAR2");

            modelBuilder.Entity<QueryNode> ().ToTable ("QUERYNODES");
            ConfigureEntity<QueryNode> (modelBuilder);
            modelBuilder.Entity<QueryNode> ().HasMany (p => p.Filters).WithMany (b => b.QueryNodes);
            modelBuilder.Entity<QueryNode> ().Property (p => p.SqlQueryNode).HasMaxLength (500).IsRequired ().HasColumnType ("VARCHAR2");

            modelBuilder.Entity<FilterValue> ().ToTable ("FILTERVALUES");
            ConfigureEntity<FilterValue> (modelBuilder);
            modelBuilder.Entity<FilterValue> ().Property (p => p.ValueFilter).HasMaxLength (250).IsRequired ().HasColumnType ("VARCHAR2");
            modelBuilder.Entity<FilterValue> ().HasRequired (p => p.QueryNode).WithMany (b => b.FilterValues).HasForeignKey (p => p.IdQueryNode);
            #endregion
        }

        public static void ConfigureEntity<TEntity> (DbModelBuilder modelBuilder)
            where TEntity : class, IEntity
        {
            modelBuilder.Entity<TEntity> ().HasKey (p => p.Id);
            modelBuilder.Entity<TEntity> ().Property (p => p.Id).HasDatabaseGeneratedOption (DatabaseGeneratedOption.Identity).HasColumnName("ID");
        }

        public static void ConfigureUniqueString (StringPropertyConfiguration property, string nameIndex)
        {
            property.HasColumnAnnotation (IndexAnnotation.AnnotationName,
                new IndexAnnotation (new IndexAttribute (nameIndex, 1) { IsUnique = true }));
        }
    }
}
