namespace Bookkeeping.Data.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using Bookkeeping.Data.Entities;

    internal sealed class Configuration : DbMigrationsConfiguration<Bookkeeping.Data.BookkeepingContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(Bookkeeping.Data.BookkeepingContext context)
        {
            //SeedDefaultAdmin (context);
        }

        public static void SeedDefaultAdmin (BookkeepingContext context)
        {
            if (!context.Users.Any(item => item.Login == AdministratorDefaultCredentials.Login &&
                                                      item.Password == AdministratorDefaultCredentials.Password) )
            {
                /*   var departament = new Departament ()
                   {
                       NameDepartament = "Tester"
                   };
                      var grant = new UserGrant ()
                      {
                          PrivateData = GrantType.ReadWrite,
                          OverallData = GrantType.ReadWrite,
                          TheirPersonal = GrantType.ReadWrite,
                          HisDepartament = GrantType.ReadWrite,
                          ForeignPrivate = GrantType.ReadWrite,
                          ForeignPersonal = GrantType.ReadWrite,
                          TaskDepartament = GrantType.ReadWrite,
                          OtherPersonal = GrantType.ReadWrite,
                          OtherDepartament = GrantType.ReadWrite
                      };
                      var adminUser = new User
                      {
                          Id = 0,
                          Name = "������",
                          Login = AdministratorDefaultCredentials.Login,
                          Password = AdministratorDefaultCredentials.Password,
                          Post = "������������� �������"
                      };
                      context.Departaments.AddOrUpdate (p => p.Id, departament);
                      context.UserGrants.AddOrUpdate (p => p.Id, grant);
                      adminUser.Departament = departament;
                      adminUser.UserGrant = grant;
                      context.Users.AddOrUpdate (p => p.Id, adminUser);*/
            }
        }
    }
}
