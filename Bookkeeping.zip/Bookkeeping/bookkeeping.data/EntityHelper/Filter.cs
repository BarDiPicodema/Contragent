﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bookkeeping.Data.EntityHelper
{
    [EF.Include]
    public class Filter : Entity
    {
        public Filter ()
        {
            QueryNodes = new HashSet<QueryNode> ();
        }

        public string NameFilter { get; set; }

        public string Table { get; set; }
        
        [EF.Include]
        public virtual ICollection<QueryNode> QueryNodes { get; set; }
    }

    [EF.Include]
    public class QueryNode : Entity
    {
        public QueryNode ()
        {
            Filters = new HashSet<Filter> ();
            FilterValues = new HashSet<FilterValue> ();
        }

        public string SqlQueryNode { get; set; }

        public virtual ICollection<Filter> Filters { get; set; }
        [EF.Include]
        public virtual ICollection<FilterValue> FilterValues { get; set; }
    }

    [EF.Include]
    public class FilterValue : Entity
    {
        public string ValueFilter { get; set; }

        public decimal IdQueryNode { get; set; }
        public virtual QueryNode QueryNode { get; set; }
    }
}
