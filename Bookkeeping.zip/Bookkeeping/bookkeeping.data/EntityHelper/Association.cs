﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bookkeeping.Data.EntityHelper
{
    public class AssociationTable : Entity
    {
        public AssociationTable ()
        {
            Filters = new HashSet<Filter> ();
        }

        public string NameTable { get; set; }
        public string AssociationNameTable { get; set; }

        public virtual ICollection<Filter> Filters { get; set; }
    }
}
