﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.EF
{
    public enum FieldOperation
    {
        Filter,
        Search,
        FilterSearch,
        None
    };

    [AttributeUsage (AttributeTargets.Class | AttributeTargets.Property)]
    public class AssociationNameAttribute : Attribute
    {
        private string _name;
        private bool _isTableFiltred;
        private FieldOperation _operation;

        public AssociationNameAttribute ()
        {

        }

        public AssociationNameAttribute (string name)
        {
            _name = name;
            _operation = FieldOperation.None;
            _isTableFiltred = false;
        }

        public AssociationNameAttribute (string name, FieldOperation operation = FieldOperation.None)
        {
            _name = name;
            _operation = operation;
            _isTableFiltred = false;
        }

        public AssociationNameAttribute (string name, FieldOperation operation = FieldOperation.FilterSearch, bool isTableFiltred = true)
        {
            _name = name;
            _operation = operation;
            _isTableFiltred = isTableFiltred;
        }

        public string Name { get { return _name; } set { _name = value; } }
        public FieldOperation Operation { get { return _operation; } set { _operation = value; } }
        public bool IsTableFiltred { get { return _isTableFiltred; } set { _isTableFiltred = value; } }
    }
}
