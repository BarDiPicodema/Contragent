﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.EF
{
    [AttributeUsage (AttributeTargets.Property | AttributeTargets.Class)]
    public class IncludeAttribute : Attribute
    {
        private string _projectionName;

        public IncludeAttribute ()
        {
        }

        public IncludeAttribute (string projectionName)
        {
            _projectionName = projectionName;
        }

        public string ProjectionName { get { return _projectionName; } }
    }
}
