﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.EF
{
    [AttributeUsage (AttributeTargets.Property)]
    public class RelationAttribute : Attribute
    {
        private string _primaryProperty;
        private string _foreignProperty;
        
        public RelationAttribute (string primary, string foreign)
        {
            _primaryProperty = primary;
            _foreignProperty = foreign;
        }

        public string PromaryProperty { get { return _primaryProperty; } }
        public string ForeignProperty { get { return _foreignProperty; } }
    }
}
