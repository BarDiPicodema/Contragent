﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.EF
{
    public static class IncludeDataHelper
    {
        public static readonly string AllProjectionKey = "_ALL";
        private static readonly MethodInfo IncludeMethodInfo = typeof (QueryableExtensions).GetMethod ("Include", new[] { typeof (IQueryable<>), typeof (string) });
        public static readonly IDictionary<Type, Dictionary<string, Delegate>> _cacheProjections = new Dictionary<Type, Dictionary<string, Delegate>> ();

        public static void Init (Assembly a)
        {
            IEnumerable<Type> types = a.GetTypes ().Where (item => item.GetCustomAttributes (typeof (IncludeAttribute), true) != null);
            foreach ( Type type in types )
            {
                Type queryable = typeof (IQueryable<>).MakeGenericType (type);

                PropertyInfo[] members = type.GetProperties ().Where (item => item.GetCustomAttributes (typeof (IncludeAttribute), true).Any ()).ToArray ();

                var projections = new Dictionary<string, List<PropertyInfo>> ();
                var allProjection = new List<PropertyInfo> ();
                projections[AllProjectionKey] = allProjection;

                foreach (PropertyInfo property in members)
                {
                    var attributes = property.GetCustomAttributes (typeof (IncludeAttribute), true);
                    foreach (IncludeAttribute item in attributes)
                    {
                        string key = item.ProjectionName;
                        List<PropertyInfo> mil = null;
                        if (!string.IsNullOrWhiteSpace (key))
                        {
                            if (projections.ContainsKey (key))
                                mil = projections[key];
                            else
                            {
                                mil = new List<PropertyInfo>();
                                projections[key] = mil;
                            }
                        }
                        if (mil != null) 
                            mil.Add (property);
                        allProjection.Add (property);
                    }
                }

                Dictionary<string, Delegate> projectionRepo = null;
                if ( _cacheProjections.ContainsKey (type) ) projectionRepo = _cacheProjections[type];
                else
                {
                    projectionRepo = new Dictionary<string, Delegate> ();
                    _cacheProjections[type] = projectionRepo;
                }
                foreach ( var item in projections.Keys )
                {
                    List<PropertyInfo> projectionMembers = projections[item];
                    ParameterExpression pexp = Expression.Parameter (queryable);
                    Expression source = pexp;
                    foreach ( PropertyInfo projectionMember in projectionMembers )
                    {
                        ParameterExpression o = Expression.Parameter (type);
                        Expression prop = Expression.Constant (projectionMember.Name);
                        source = Expression.Call (null, IncludeMethodInfo, source, prop);
                    }
                    LambdaExpression l = Expression.Lambda (source, pexp);
                    Delegate compiled = l.Compile ();
                    projectionRepo.Add (item, compiled);
                }
            }
        }

        public static IQueryable<TEntity> IncludeAll<TEntity> (this IQueryable<TEntity> entity)
        {
            return IncludeProjection (entity, AllProjectionKey);
        }

        public static IQueryable<TEntity> IncludeProjection<TEntity> (this IQueryable<TEntity> entity, string projectionName)
        {
            if ( !_cacheProjections.ContainsKey (typeof (TEntity)) )
            {
                return entity;
            }
            Dictionary<string, Delegate> cached = _cacheProjections[typeof (TEntity)];
            Delegate del = cached[projectionName];
            object q = del.DynamicInvoke (entity);
            return (IQueryable<TEntity>) q;
        }
    }
}
