﻿namespace Bookkeeping.Data.Entities
{
    public class Specification : Entity
    {
        /// <summary>
        /// Спецификация для клиента
        /// </summary>
        #region Clients properties
        public decimal? IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal? IdIndividual { get; set; }
        [EF.Include]
        public virtual Individual Individual { get; set; }

        public decimal? IdEntrepreneur { get; set; }
        [EF.Include]
        public virtual Entrepreneur Entrepreneur { get; set; }
        #endregion

        /// <summary>
        /// Текст для поиска
        /// </summary>
        [EF.AssociationName ("Текст спецификации", EF.FieldOperation.Search)]
        public string SpecificationText { get; set; }

        /// <summary>
        /// Текст с форматированиями
        /// </summary>
        public byte[] SpecificationTextStyle { get; set; }
    }
}
