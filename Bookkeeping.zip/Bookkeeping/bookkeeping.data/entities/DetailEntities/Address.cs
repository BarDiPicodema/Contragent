﻿using System.Collections.Generic;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.Data.Entities
{
    public class AddressType : Entity, ITypeEntity
    {
        public AddressType ()
        {
            Addresses = new HashSet<Address> ();
            AddressValues = new HashSet<AddressValue> ();
        }
        /// <summary>
        /// Тип адреса
        /// </summary>
        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public string TypeName { get; set; }

        public virtual ICollection<Address> Addresses { get; set; }

        public virtual ICollection<AddressValue> AddressValues { get; set; }
    }

    [EF.Include]
    public class AddressValue : Entity
    {
        public decimal IdAddressType { get; set; }
        [EF.Include]
        public virtual AddressType AddressType { get; set; }

        public decimal IdAddress { get; set; }
        [EF.Include]
        public virtual Address Address { get; set; }
    }

    /// <summary>
    /// Адреса клиентов
    /// </summary>
    [EF.Include]
    public class Address : Entity, IAccessData, IContractorInfo
    {
        public Address ()
        {
            AddressValues = new HashSet<AddressValue> ();
        }

        public decimal IdAddressType { get; set; }
        [EF.Include]
        [EF.AssociationName ("Тип адреса", EF.FieldOperation.Filter)]
        public virtual AddressType AddressType { get; set; }

        [EF.Include]
        public virtual ICollection<AddressValue> AddressValues { get; set; }

        [EF.AssociationName ("Название", EF.FieldOperation.Search)]
        public string Name { get; set; }
        [EF.AssociationName ("Почтовый индекс", EF.FieldOperation.Search)]
        public string PostIndex { get; set; }
        [EF.AssociationName ("Страна", EF.FieldOperation.Search)]
        public string Land { get; set; }
        [EF.AssociationName ("Область", EF.FieldOperation.Search)]
        public string Area { get; set; }
        [EF.AssociationName ("Город", EF.FieldOperation.Search)]
        public string City { get; set; }
        [EF.AssociationName ("Поселок", EF.FieldOperation.Search)]
        public string Settlement { get; set; }
        [EF.AssociationName ("Улица", EF.FieldOperation.Search)]
        public string Street { get; set; }
        [EF.AssociationName ("Дом")]
        public string House { get; set; }
        [EF.AssociationName ("Строение, корпус")]
        public string Structure { get; set; }
        [EF.AssociationName ("Подъезд")]
        public string Porch { get; set; }
        [EF.AssociationName ("Офис")]
        public string Office { get; set; }
        [EF.AssociationName ("СОУН", EF.FieldOperation.Search)]
        public string Soun { get; set; }
        [EF.AssociationName ("КЛАДР", EF.FieldOperation.Search)]
        public string Kladr { get; set; }
        [EF.AssociationName ("Описание", EF.FieldOperation.Search)]
        public string Description { get; set; }

        public decimal? IdOkato { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКАТО", EF.FieldOperation.FilterSearch)]
        public virtual Okato Okato { get; set; }

        public decimal? IdOksm { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКСМ", EF.FieldOperation.FilterSearch)]
        public virtual Oksm Oksm { get; set; }

        public decimal? IdSono { get; set; }
        [EF.Include]
        [EF.AssociationName ("СОНО", EF.FieldOperation.FilterSearch)]
        public virtual Sono Sono { get; set; }

        /// <summary>
        /// Адреса для клиента
        /// </summary>
        #region Clients properties
        public decimal? IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal? IdIndividual { get; set; }
        [EF.Include]
        public virtual Individual Individual { get; set; }

        public decimal? IdEntrepreneur { get; set; }
        [EF.Include]
        public virtual Entrepreneur Entrepreneur { get; set; }
        #endregion

        public decimal IdFlag { get; set; }
        [EF.Include]
        public virtual Flag Flag { get; set; }

        public decimal IdAccessType { get; set; }
        [EF.Include]
        public virtual AccessType AccessType { get; set; }
    }
}
