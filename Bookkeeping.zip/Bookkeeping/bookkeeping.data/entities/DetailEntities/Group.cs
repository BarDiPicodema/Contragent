﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace Bookkeeping.Data.Entities
{
    [EF.Include]
    public class GroupType : Entity, Interface.ITypeEntity
    {
        public GroupType ()
        {
            GroupTypeParent = new HashSet<GroupTypeToType> ();
            GroupTypeChildren = new HashSet<GroupTypeToType> ();
        }

        [EF.AssociationName ("Название")]
        public string TypeName { get; set; }

        //[EF.Include]
        public virtual ICollection<GroupTypeToType> GroupTypeChildren { get; set; }

        //[EF.Include]
        public virtual ICollection <GroupTypeToType> GroupTypeParent { get; set; }
    }

    [EF.Include]
    public class GroupTypeToType : Entity
    {
        public GroupTypeToType ()
        {
            Groups = new HashSet<Group> ();
        }

        [EF.Include]
        public virtual ICollection<Group> Groups { get; set; }

        public decimal IdGroupTypeOne { get; set; }
        [EF.Include]
        public GroupType GroupTypeOne { get; set; }

        public decimal IdGroupTypeTwo { get; set; }
        [EF.Include]
        public GroupType GroupTypeTwo { get; set; }
    }

    /// <summary>
    /// Группы клиентов
    /// </summary>
    [EF.Include]
    public class Group : Entity
    {
        /// <summary>
        /// Документы для клиента
        /// </summary>
        #region Clients properties
        public decimal? IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal? IdIndividual { get; set; }
        [EF.Include]
        public virtual Individual Individual { get; set; }

        public decimal? IdEntrepreneur { get; set; }
        [EF.Include]
        public virtual Entrepreneur Entrepreneur { get; set; }
        #endregion

        public decimal IdGroupTypeToType { get; set; }
        [EF.Include]
        [EF.AssociationName ("Тип группы")]
        public virtual GroupTypeToType GroupTypeToType { get; set; }
    }
}
