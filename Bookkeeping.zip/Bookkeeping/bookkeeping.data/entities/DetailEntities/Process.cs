﻿using System;
using System.Collections.Generic;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.Data.Entities
{
    public class ProcessType : Entity, ITypeEntity
    {
        public ProcessType ()
        {
            Processes = new HashSet<Process> ();
        }

        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public string TypeName { get; set; }

        public virtual ICollection<Process> Processes { get; set; }
    }

    /// <summary>
    /// Процессы клиентов
    /// </summary>
    [EF.Include]
    public class Process : Entity
    {
        /// <summary>
        /// Тип процесса
        /// </summary>
        public decimal IdProcessType { get; set; }
        [EF.Include]
        [EF.AssociationName ("Тип процесса", EF.FieldOperation.Filter)]
        public virtual  ProcessType ProcessType { get; set; }

        /// <summary>
        /// Партнер в процессе
        /// </summary>
        public decimal? IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        /// <summary>
        /// Физлицо в процессе
        /// </summary>
        public decimal? IdIndividual { get; set; }
        [EF.Include]
        public virtual Individual Individual { get; set; }

        /// <summary>
        /// Юрлицо в процессе
        /// </summary>
        public decimal? IdEntrepreneur { get; set; }
        [EF.Include]
        public virtual Entrepreneur Entrepreneur { get; set; }

        /// <summary>
        /// Дата начала процесса
        /// </summary>
        public DateTime ProcessBegin { get; set; }
        /// <summary>
        /// Дата окончания процесса
        /// </summary>
        public DateTime? ProcessEnd { get; set; }
    }
}
