﻿using System.Collections.Generic;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.Data.Entities
{
    public class ContactType : Entity, ITypeEntity
    {
        public ContactType ()
        {
            Contacts = new HashSet<Contact> ();
        }
        /// <summary>
        /// Тип контакта
        /// </summary>
        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public string TypeName { get; set; }

        public virtual ICollection<Contact> Contacts { get; set; }
    }


    /// <summary>
    /// Контакты клиентов
    /// </summary>
    [EF.Include]
    public class Contact : Entity, IAccessData, IContractorInfo
    {
        public decimal IdContactType { get; set; }
        [EF.Include]
        [EF.AssociationName ("Тип контакта", EF.FieldOperation.Filter)]
        public virtual ContactType ContactType { get; set; }

        [EF.AssociationName ("Контакт", EF.FieldOperation.Search)]
        public string ContactText { get; set; }
        [EF.AssociationName ("Имя", EF.FieldOperation.Search)]
        public string Name { get; set; }
        [EF.AssociationName ("Должность", EF.FieldOperation.Search)]
        public string Post { get; set; }
        [EF.AssociationName ("Подразделение", EF.FieldOperation.Search)]
        public string Sub { get; set; }
        [EF.AssociationName ("Примечание", EF.FieldOperation.Search)]
        public string Description { get; set; }

        /// <summary>
        /// Конта для клиента
        /// </summary>
        #region Clients properties
        public decimal? IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal? IdIndividual { get; set; }
        [EF.Include]
        public virtual Individual Individual { get; set; }

        public decimal? IdEntrepreneur { get; set; }
        [EF.Include]
        public virtual Entrepreneur Entrepreneur { get; set; }
        #endregion

        public decimal IdFlag { get; set; }
        [EF.Include]
        public virtual Flag Flag { get; set; }

        public decimal IdAccessType { get; set; }
        [EF.Include]
        public virtual AccessType AccessType { get; set; }
    }
}
