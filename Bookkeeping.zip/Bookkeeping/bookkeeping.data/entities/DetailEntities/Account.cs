﻿using System.Collections.Generic;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.Data.Entities
{
    public class AccountType : Entity, ITypeEntity
    {
        public AccountType ()
        {
            Accounts = new HashSet<Account> ();
        }

        /// <summary>
        /// Тип счета
        /// </summary>
        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public  string TypeName { get; set; }

        public virtual ICollection<Account> Accounts { get; set; }
    }

    public class AccountKind : Entity, ITypeEntity
    {
        public AccountKind ()
        {
            Accounts = new HashSet<Account> ();
        }

        /// <summary>
        /// Вид счета
        /// </summary>
        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public string TypeName { get; set; }

        public virtual ICollection<Account> Accounts { get; set; }
    }

    /// <summary>
    /// Счета клиентов
    /// </summary>
    [EF.Include]
    public class Account : Entity, Interface.IAccessData, Interface.IContractorInfo
    {
        #region Account information columns
        [EF.AssociationName ("Название", EF.FieldOperation.Search)]
        public string Name { get; set; }
        [EF.AssociationName ("Номер счета", EF.FieldOperation.Search)]
        public string AccountNumber { get; set; }
        [EF.AssociationName ("IBAN", EF.FieldOperation.Search)]
        public string IbanNumber { get; set; }
        [EF.AssociationName ("Банк", EF.FieldOperation.Search)]
        public string Bank { get; set; }
        [EF.AssociationName ("Адрес банка", EF.FieldOperation.Search)]
        public string Settlement { get; set; }
        [EF.AssociationName ("БИК", EF.FieldOperation.Search)]
        public string Bic { get; set; }
        [EF.AssociationName ("Корреспондентский счет", EF.FieldOperation.Search)]
        public string CorrespondentAccount { get; set; }
        [EF.AssociationName ("Корресподнесткий банк", EF.FieldOperation.Search)]
        public string CorrespondentBank { get; set; }
        [EF.AssociationName ("Персональный счет", EF.FieldOperation.Search)]
        public string PersonAccount { get; set; }
        [EF.AssociationName ("Получатель", EF.FieldOperation.Search)]
        public string Recipient { get; set; }
        [EF.AssociationName ("Дополнительно", EF.FieldOperation.Search)]
        public string Extra { get; set; }
        [EF.AssociationName ("Описание", EF.FieldOperation.Search)]
        public string Description { get; set; }
        #endregion

        public decimal? IdOkv { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКВ", EF.FieldOperation.FilterSearch)]
        public virtual Okv Okv { get; set; }

        public decimal IdAccountType { get; set; }
        [EF.Include]
        [EF.AssociationName ("Тип счета", EF.FieldOperation.Filter)]
        public virtual AccountType AccountType { get; set; }

        public decimal IdAccountKind { get; set; }
        [EF.Include]
        [EF.AssociationName ("Вид счета", EF.FieldOperation.Filter)]
        public virtual AccountKind AccountKind { get; set; }

        /// <summary>
        /// Счет для клиента
        /// </summary>
        #region Clients properties
        public decimal? IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal? IdIndividual { get; set; }
        [EF.Include]
        public virtual Individual Individual { get; set; }

        public decimal? IdEntrepreneur { get; set; }
        [EF.Include]
        public virtual Entrepreneur Entrepreneur { get; set; }
        #endregion

        public decimal IdFlag { get; set; }
        [EF.Include]
        public virtual Flag Flag { get; set; }

        public decimal IdAccessType { get; set; }
        [EF.Include]
        public virtual AccessType AccessType { get; set; }
    }
}
