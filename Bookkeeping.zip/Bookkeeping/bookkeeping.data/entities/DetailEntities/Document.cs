﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.Data.Entities
{
    public class Link : Entity
    {
        public Link ()
        {
        }

        [EF.AssociationName ("uri адрес", EF.FieldOperation.Search)]
        public string UriLink { get; set; }
        [EF.AssociationName ("Дополнительно")]
        public string Description { get; set; }

        public decimal IdDocument { get; set; }
        [EF.Include]
        [EF.AssociationName ("Документ")]
        public virtual Document Document { get; set; }
    }

    public class DocumentType : Entity, ITypeEntity
    {
        public DocumentType ()
        {
            Documents = new HashSet<Document> ();
        }

        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public string TypeName { get; set; }

        public virtual ICollection<Document> Documents { get; set; }
    }

    /// <summary>
    /// Документы клиентов
    /// </summary>
    [EF.Include]
    public class Document : Entity, IAccessData, IContractorInfo
    {
        public Document ()
        {
            Links = new HashSet<Link> ();
            Participant = new HashSet<DocumentParticipant> ();
        }

        public decimal IdDocumentType { get; set; }
        [EF.Include]
        [EF.AssociationName ("Тип документа", EF.FieldOperation.Filter)]
        public virtual DocumentType DocumentType { get; set; }

        [EF.Include]
        [EF.AssociationName ("Ссылки", EF.FieldOperation.Search)]
        public virtual ICollection<Link> Links { get; set; }

        [EF.Include]
        [EF.AssociationName ("Участники")]
        public virtual ICollection<DocumentParticipant> Participant { get; set; }

        [EF.AssociationName ("Назначение", EF.FieldOperation.Search)]
        public string Appointment { get; set; }
        [EF.AssociationName ("Название", EF.FieldOperation.Search)]
        public string Name { get; set; }
        [EF.AssociationName ("Серия", EF.FieldOperation.Search)]
        public string Series { get; set; }
        [EF.AssociationName ("Номер", EF.FieldOperation.Search)]
        public string DocumentNumber { get; set; }
        public DateTime? DocumentDate { get; set; }
        [EF.AssociationName ("Место", EF.FieldOperation.Search)]
        public string DocumentPlace { get; set; }
        [EF.AssociationName ("Код подразделения", EF.FieldOperation.Search)]
        public string SubdividionCode { get; set; }
        public DateTime? ExpDate { get; set; }
        [EF.AssociationName ("Условия продления", EF.FieldOperation.Search)]
        public string Renew { get; set; }
        [EF.AssociationName ("Издатель", EF.FieldOperation.Search)]
        public string Issuer { get; set; }
        [EF.AssociationName ("Дополнительно", EF.FieldOperation.Search)]
        public string Description { get; set; }

        /// <summary>
        /// Документы для клиента
        /// </summary>
        #region Clients properties
        public decimal? IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal? IdIndividual { get; set; }
        [EF.Include]
        public virtual Individual Individual { get; set; }

        public decimal? IdEntrepreneur { get; set; }
        [EF.Include]
        public virtual Entrepreneur Entrepreneur { get; set; }
        #endregion

        public decimal IdFlag { get; set; }
        [EF.Include]
        public virtual Flag Flag { get; set; }

        public decimal IdAccessType { get; set; }
        [EF.Include]
        public virtual AccessType AccessType { get; set; }
    }

    public class DocumentParticipant : Entity
    {
        public DocumentParticipant ()
        {
        }

        #region Clients properties
        /// <summary>
        /// Участник
        /// </summary>
        public decimal? IdPartner { get; set; }
        public virtual Partner Partner { get; set; }
        /// <summary>
        /// Участник
        /// </summary>
        public decimal? IdIndividual { get; set; }
        public virtual Individual Individual { get; set; }
        /// <summary>
        /// Участник
        /// </summary>
        public decimal? IdEntrepreneur { get; set; }
        public virtual Entrepreneur Entrepreneur { get; set; }
        #endregion
        /// <summary>
        /// Документ
        /// </summary>
        public decimal? IdDocument { get; set; }
        public virtual Document Document { get; set; }
    }
}
