﻿using Bookkeeping.Data.Interface;
using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    [EF.Include]
    [EF.AssociationName ("Партнеры")]
    public class Partner : Entity, Interface.ICounterparties
    {
        public Partner ()
        {
            Entreperneurs = new HashSet<Entrepreneur> ();
            Individuals = new HashSet<Individual> ();

            Addresses = new HashSet<Address> ();
            Accounts = new HashSet<Account> ();
            Contacts = new HashSet<Contact> ();
            Specifications = new HashSet<Specification> ();
            Processes = new HashSet<Process> ();
            Documents = new HashSet<Document> ();
            Participant = new HashSet<DocumentParticipant> ();
            Groups = new HashSet<Group> ();
        }

        /// <summary>
        /// Partner information column
        /// </summary>
        #region Partner data
        [EF.AssociationName ("Псевдоним", EF.FieldOperation.Search)]
        public string Alias { get; set; }
        [EF.AssociationName ("Регион", EF.FieldOperation.Search)]
        public string Region { get; set; }
        [EF.AssociationName ("Деятельность", EF.FieldOperation.Search)]
        public string Activity { get; set; }
        public StateEntity IsDelete { get; set; }
        #endregion

        public decimal? IdUser { get; set; }
        [EF.Include]
        public virtual User Curator { get; set; }

        public decimal IdAccessType { get; set; }
        [EF.Include]
        public virtual AccessType AccessType { get; set; }

        public decimal IdFlag { get; set; }
        [EF.Include]
        public virtual Flag Flag { get; set; }

        public decimal IdSigning { get; set; }
        [EF.Include]
        public virtual Signing Signing { get; set; }

        #region Clients properties
        public virtual ICollection<Entrepreneur> Entreperneurs { get; set; }
        public virtual ICollection<Individual> Individuals { get; set; }
        #endregion

        #region Detail information properties
        [EF.AssociationName ("Адреса", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Address> Addresses { get; set; }

        [EF.AssociationName ("Счета", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Account> Accounts { get; set; }

        [EF.AssociationName ("Контакты", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Contact> Contacts { get; set; }

        [EF.AssociationName ("Спецификации", EF.FieldOperation.Search)]
        public virtual ICollection<Specification> Specifications { get; set; }

        [EF.AssociationName ("Процессы", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Process> Processes { get; set; }

        [EF.AssociationName ("Документы", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Document> Documents { get; set; }

        [EF.AssociationName ("Участник документов")]
        public virtual ICollection<DocumentParticipant> Participant { get; set; }

        [EF.AssociationName ("Группы")]
        public virtual ICollection<Group> Groups { get; set; }
        #endregion
    }
}
