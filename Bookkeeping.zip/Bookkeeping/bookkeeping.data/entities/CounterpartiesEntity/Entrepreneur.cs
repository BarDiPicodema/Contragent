﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    [EF.Include]
    [EF.AssociationName("Юрлица")]
    public class Entrepreneur : Entity, Interface.ICounterparties
    {
        public Entrepreneur ()
        {
            Classifiers = new HashSet<Classifier> ();
            Addresses = new HashSet<Address> ();
            Accounts = new HashSet<Account> ();
            Contacts = new HashSet<Contact> ();
            Specifications = new HashSet<Specification> ();
            Processes = new HashSet<Process> ();
            Documents = new HashSet<Document> ();
            Participant = new HashSet<DocumentParticipant> ();
            Groups = new HashSet<Group> ();
        }

        #region Data entrepreneur
        [EF.AssociationName ("Псевдоним", EF.FieldOperation.Search)]
        public string Alias { get; set; }
        [EF.AssociationName ("Название", EF.FieldOperation.Search)]
        public string Name { get; set; }
        [EF.AssociationName ("Сокращенное (рус.)", EF.FieldOperation.Search)]
        public string BriefName { get; set; }
        [EF.AssociationName ("Сокращенное (ин.)", EF.FieldOperation.Search)]
        public string ForeignName { get; set; }
        public DateTime? RegistrationDate { get; set; }
        [EF.AssociationName ("ОГРН", EF.FieldOperation.Search)]
        public string Ogrn { get; set; }
        [EF.AssociationName ("ИНН", EF.FieldOperation.Search)]
        public string INN { get; set; }
        [EF.AssociationName ("КПП", EF.FieldOperation.Search)]
        public string KPP { get; set; }
        [EF.AssociationName ("ОКПО", EF.FieldOperation.Search)]
        public string Okpo { get; set; }
        [EF.AssociationName ("Удаленный")]
        public StateEntity IsDelete { get; set; }
        public byte[] Icon { get; set; }
        [EF.AssociationName ("Заметка", EF.FieldOperation.Search)]
        public string Note { get; set; }
        #endregion

        public decimal IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal IdAccessType { get; set; }
        [EF.Include]
        public virtual AccessType AccessType { get; set; }

        public decimal IdFlag { get; set; }
        [EF.Include]
        public virtual Flag Flag { get; set; }

        public decimal IdSigning { get; set; }
        [EF.Include]
        public virtual Signing Signing { get; set; }

        public decimal? IdOkopf { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКОПФ", EF.FieldOperation.FilterSearch)]
        public virtual Okopf Okopf { get; set; }

        public decimal? IdOkfs { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКФС", EF.FieldOperation.FilterSearch)]
        public virtual Okfs Okfs { get; set; }

        public decimal? IdOkogu { get; set; }
        //[EF.Include]
        [EF.AssociationName ("ОКОГУ", EF.FieldOperation.FilterSearch)]
        public virtual Okogu Okogu { get; set; }

        [EF.AssociationName ("Доп. классификаторы", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Classifier> Classifiers { get; set; }

       #region Detail information properties
        [EF.AssociationName ("Адреса", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Address> Addresses { get; set; }

        [EF.AssociationName ("Счета", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Account> Accounts { get; set; }

        [EF.AssociationName ("Контакты", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Contact> Contacts { get; set; }

        [EF.AssociationName ("Спецификации", EF.FieldOperation.Search)]
        public virtual ICollection<Specification> Specifications { get; set; }

        [EF.AssociationName ("Процессы", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Process> Processes { get; set; }

        [EF.AssociationName ("Документы", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Document> Documents { get; set; }

        [EF.AssociationName ("Участник документов")]
        public virtual ICollection<DocumentParticipant> Participant { get; set; } 

        [EF.AssociationName ("Группы")]
        public virtual ICollection<Group> Groups { get; set; }
        #endregion
    }
}
