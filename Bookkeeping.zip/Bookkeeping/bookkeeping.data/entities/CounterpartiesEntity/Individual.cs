﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    [EF.Include]
    [EF.AssociationName ("Физлица")]
    public class Individual : Entity, Interface.ICounterparties
    {
        public Individual ()
        {
            Addresses = new HashSet<Address> ();
            Accounts = new HashSet<Account> ();
            Contacts = new HashSet<Contact> ();
            Specifications = new HashSet<Specification> ();
            Processes = new HashSet<Process> ();
            Documents = new HashSet<Document> ();
            Participant = new HashSet<DocumentParticipant> ();
            Groups = new HashSet<Group> ();
        }

        /// <summary>
        /// Individual information column
        /// </summary>
        #region Data individual
        [EF.AssociationName ("Псевдоним", EF.FieldOperation.Search)]
        public string Alias { get; set; }
        [EF.AssociationName ("Имя", EF.FieldOperation.Search)]
        public string Name { get; set; }
        [EF.AssociationName ("Фамилия", EF.FieldOperation.Search)]
        public string SecondName { get; set; }
        [EF.AssociationName ("Отчество", EF.FieldOperation.Search)]
        public string MiddleName { get; set; }
        [EF.AssociationName ("Пол")]
        public Sex Sex { get; set; }
        public DateTime? BirthDate { get; set; }
        public string BirthPlace { get; set; }
        [EF.AssociationName ("Гражданство", EF.FieldOperation.FilterSearch)]
        public string Citizenship { get; set; }
        [EF.AssociationName ("ИНН", EF.FieldOperation.Search)]
        public string INN { get; set; }
        [EF.AssociationName ("Национальность", EF.FieldOperation.FilterSearch)]
        public string Nationality { get; set; }
        [EF.AssociationName ("Информация о работе", EF.FieldOperation.Search)]
        public string InfoWork { get; set; }
        [EF.AssociationName ("Группа крови", EF.FieldOperation.Search)]
        public string BloodGroup { get; set; }
        [EF.AssociationName ("Снилс", EF.FieldOperation.Search)]
        public string Snils { get; set; }
        [EF.AssociationName ("Мед карта", EF.FieldOperation.Search)]
        public string Med { get; set; }
        [EF.AssociationName ("Удаленный")]
        public StateEntity IsDelete { get; set; }
        public byte[] Icon { get; set; }
        [EF.AssociationName ("Заметка", EF.FieldOperation.Search)]
        public string Note { get; set; }
        #endregion

        public decimal IdPartner { get; set; }
        [EF.Include]
        public virtual Partner Partner { get; set; }

        public decimal IdSigning { get; set; }
        [EF.Include]
        public virtual Signing Signing { get; set; }

        public decimal IdFlag { get; set; }
        [EF.Include]
        public virtual Flag Flag { get; set; }

        public decimal IdAccessType { get; set; }
        [EF.Include]
        public virtual AccessType AccessType { get; set; }

         #region Detail information properties
        [EF.AssociationName ("Адреса", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Address> Addresses { get; set; }

        [EF.AssociationName ("Счета", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Account> Accounts { get; set; }

        [EF.AssociationName ("Контакты", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Contact> Contacts { get; set; }

        [EF.AssociationName ("Спецификации", EF.FieldOperation.Search)]
        public virtual ICollection<Specification> Specifications { get; set; }

        [EF.AssociationName ("Процессы", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Process> Processes { get; set; }

        [EF.AssociationName ("Документы", EF.FieldOperation.FilterSearch)]
        public virtual ICollection<Document> Documents { get; set; }

        [EF.AssociationName ("Участник документов")]
        public virtual ICollection<DocumentParticipant> Participant { get; set; }

        [EF.AssociationName ("Группы")]
        public virtual ICollection<Group> Groups { get; set; }
         #endregion
    }
}
