﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Флаги
    /// </summary>
    public class Flag : Entity, Interface.IExtraType
    {
        public Flag ()
        {
            Individuals = new HashSet<Individual> ();
            Entrepreneurs = new HashSet<Entrepreneur> ();
            Partners = new HashSet<Partner> ();

            Addresses = new HashSet<Address> ();
            Accounts = new HashSet<Account> ();
            Contacts = new HashSet<Contact> ();
            Documents = new HashSet<Document> ();
        }

        /// <summary>
        /// название
        /// </summary>
        public string Name { get; set; }
        public string TypeName { get; set; }
        public byte[] TypeImage { get; set; }
        public string TypeColor { get; set; }
        public string FontStyle { get; set; }

        public virtual ICollection<Individual> Individuals { get; set; }
        public virtual ICollection<Entrepreneur> Entrepreneurs { get; set; }
        public virtual ICollection<Partner> Partners { get; set; }
        public virtual ICollection<Address> Addresses { get; set; }
        public virtual ICollection<Account> Accounts { get; set; }
        public virtual ICollection<Contact> Contacts { get; set; }
        public virtual ICollection<Document> Documents { get; set; }
    }
}
