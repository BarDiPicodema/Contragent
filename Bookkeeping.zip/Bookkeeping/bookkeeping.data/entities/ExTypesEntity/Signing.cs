﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Важность
    /// </summary>
    public class Signing : Entity, Interface.IExtraType
    {
        public Signing ()
        {
            Individuals = new HashSet<Individual> ();
            Entrepreneurs = new HashSet<Entrepreneur> ();
            Partners = new HashSet<Partner> ();
        }

        /// <summary>
        /// название
        /// </summary>
        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public string TypeName { get; set; }

        /// <summary>
        /// картинка важности
        /// </summary>
        public byte[] TypeImage { get; set; }

        /// <summary>
        /// цвет текста
        /// </summary>
        public string TypeColor { get; set; }

        /// <summary>
        /// стиль текста
        /// </summary>
        public string FontStyle { get; set; }

        public virtual ICollection<Individual> Individuals { get; set; }
        public virtual ICollection<Entrepreneur> Entrepreneurs { get; set; }
        public virtual ICollection<Partner> Partners { get; set; }
    }
}
