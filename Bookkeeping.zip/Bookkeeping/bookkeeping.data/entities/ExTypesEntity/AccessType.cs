﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Тип поступа
    /// </summary>
    public class AccessType : Entity, Interface.ITypeEntity
    {
        public AccessType ()
        {
            Individuals = new HashSet<Individual> ();
            Entrepreneurs = new HashSet<Entrepreneur> ();
            Partners = new HashSet<Partner> ();

            Addresses = new HashSet<Address> ();
            Accounts = new HashSet<Account> ();
            Contacts = new HashSet<Contact> ();
            Documents = new HashSet<Document> ();
        }

        /// <summary>
        /// Название типа доступа
        /// </summary>
        [EF.AssociationName ("Название", EF.FieldOperation.Filter)]
        public string TypeName { get; set; }

        [EF.Include]
        public decimal? IdUser { get; set; }
        public virtual User User { get; set; }

        [EF.Include]
        public decimal? IdDepartament { get; set; }
        public virtual Departament Departament { get; set; }

        public bool IsPrivate { get; set; }

        public virtual ICollection<Individual> Individuals { get; set; }
        public virtual ICollection<Entrepreneur> Entrepreneurs { get; set; }
        public virtual ICollection<Partner> Partners { get; set; }
        public virtual ICollection<Address> Addresses { get; set; }
        public virtual ICollection<Account> Accounts { get; set; }
        public virtual ICollection<Contact> Contacts { get; set; }
        public virtual ICollection<Document> Documents { get; set; }
    }
}
