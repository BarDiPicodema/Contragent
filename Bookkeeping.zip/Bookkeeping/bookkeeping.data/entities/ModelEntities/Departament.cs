﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bookkeeping.Data.Entities
{
    public class Departament : Entity
    {
        public Departament ()
        {
            Users = new HashSet<User> ();
            AccessTypes = new HashSet<AccessType> ();
        }

        public string NameDepartament { get; set; }

        public virtual ICollection<User> Users { get; set; }
        public virtual ICollection<AccessType> AccessTypes { get; set; }
    }
}
