﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.Entities
{
    [EF.Include]
    public class User : Entity
    {
        public User ()
        {
            AccessTypes = new HashSet<AccessType> ();
            Partners = new HashSet<Partner> ();
        }

        public string Name { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Post { get; set; }
        public StateEntity IsDelete { get; set; }

        public virtual ICollection<AccessType> AccessTypes { get; set; }

        public virtual ICollection<Partner> Partners { get; set; }

        public decimal IdDepartament { get; set; }
        [EF.Include]
        public virtual Departament Departament { get; set; }

        public decimal IdGrant { get; set; }
        [EF.Include]
        public virtual UserGrant UserGrant { get; set; }
    }
}
