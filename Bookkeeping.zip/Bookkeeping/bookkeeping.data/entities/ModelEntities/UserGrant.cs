﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data.Entities
{
    public class UserGrant : Entity
    {
        public UserGrant ()
        {
            Users = new HashSet<User> ();
        }

        /// <summary>
        /// Личное
        /// </summary>
        public GrantType PrivateData { get; set; }

        /// <summary>
        /// Общее
        /// </summary>
        public GrantType OverallData { get; set; }

        /// <summary>
        /// Свое персональное
        /// </summary>
        public GrantType TheirPersonal { get; set; }

        /// <summary>
        /// Своего отдела
        /// </summary>
        public GrantType HisDepartament { get; set; }

        /// <summary>
        /// чужое личное
        /// </summary>
        public GrantType ForeignPrivate { get; set; }

        /// <summary>
        /// чужое персональное по отделу
        /// </summary>
        public GrantType ForeignPersonal { get; set; }

        /// <summary>
        /// задачи по отделу
        /// </summary>
        public GrantType TaskDepartament { get; set; }

        /// <summary>
        /// Персональное других
        /// </summary>
        public GrantType OtherPersonal { get; set; }

        /// <summary>
        /// По другим отделам
        /// </summary>
        public GrantType OtherDepartament { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }

    public enum GrantType
    {
        NotRead,
        Read,
        ReadWrite
    };
}
