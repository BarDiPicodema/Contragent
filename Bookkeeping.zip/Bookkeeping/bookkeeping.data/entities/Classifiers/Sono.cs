﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Система обозначений налоговых органов
    /// </summary>
    public class Sono : Interface.IClassifier
    {
        public Sono ()
        {
            Addresses = new HashSet<Address> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }

        [EF.AssociationName ("Наименование", EF.FieldOperation.FilterSearch)]
        public string Title { get; set; }

        public virtual ICollection<Address> Addresses { get; set; }
    }
}
