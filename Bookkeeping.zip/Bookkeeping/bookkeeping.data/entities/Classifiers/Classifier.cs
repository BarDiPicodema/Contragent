﻿using System.ComponentModel.DataAnnotations;

namespace Bookkeeping.Data.Entities
{
    [EF.Include]
    public class Classifier : Entity
    {
        public decimal IdEntrepreneur { get; set; }
        public virtual Entrepreneur Entrepreneur { get; set; }

        public decimal? IdOksm { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКСМ", EF.FieldOperation.FilterSearch)]
        public virtual Oksm Oksm { get; set; }

        public decimal? IdOkato { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКАТО", EF.FieldOperation.FilterSearch)]
        public virtual Okato Okato { get; set; }

        public decimal? IdOkved { get; set; }
        [EF.Include]
        [EF.AssociationName ("ОКВЭД", EF.FieldOperation.FilterSearch)]
        public virtual Okved Okved { get; set; }
    }
}
