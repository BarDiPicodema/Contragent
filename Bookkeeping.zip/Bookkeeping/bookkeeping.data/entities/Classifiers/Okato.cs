﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Общероссийский классификатор объектов административно-территориального деления 
    /// </summary>
    public class Okato : Interface.IClassifier
    {
        public Okato ()
        {
            Classifiers = new HashSet<Classifier> ();
            Addresses = new HashSet<Address> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }
        [EF.AssociationName ("Регион", EF.FieldOperation.FilterSearch)]
        public string Region { get; set; }
        [EF.AssociationName ("Город", EF.FieldOperation.FilterSearch)]
        public string City { get; set; }
        [EF.AssociationName ("ОКТМО код", EF.FieldOperation.FilterSearch)]
        public decimal OktmoCode { get; set; }
        [EF.AssociationName ("Муниципальная форма")]
        public string MunicipalForm { get; set; }

        public virtual ICollection<Classifier> Classifiers { get; set; }
        public virtual ICollection<Address> Addresses { get; set; }
    }
}
