﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Общероссийский классификатор видов экономической деятельности
    /// </summary>
    public class Okved : Interface.IClassifier
    {
        public Okved ()
        {
            Classifiers = new HashSet<Classifier> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }

        [EF.AssociationName ("Наименование", EF.FieldOperation.FilterSearch)]
        public string Title { get; set; }

        public virtual ICollection<Classifier> Classifiers { get; set; }
    }
}
