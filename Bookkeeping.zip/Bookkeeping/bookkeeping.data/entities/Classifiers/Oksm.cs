﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Общероссийский классификатор стран мира
    /// </summary>
    public class Oksm : Interface.IClassifier
    {
        public Oksm ()
        {
            Classifiers = new HashSet<Classifier> ();
            Addresses = new HashSet<Address> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }

        [EF.AssociationName ("Наименование", EF.FieldOperation.FilterSearch)]
        public string Name { get; set; }
        [EF.AssociationName ("Полное наименование")]
        public string FullName { get; set; }
        [EF.AssociationName ("Код Альфа2", EF.FieldOperation.FilterSearch)]
        public string Alpha2 { get; set; }
        [EF.AssociationName ("Код Альфа3", EF.FieldOperation.FilterSearch)]
        public string Alpha3 { get; set; }

        public virtual ICollection<Classifier> Classifiers { get; set; }
        public virtual ICollection<Address> Addresses { get; set; }
    }
}
