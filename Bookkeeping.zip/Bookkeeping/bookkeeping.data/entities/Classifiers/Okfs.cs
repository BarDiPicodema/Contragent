﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Общероссийский классификатор форм собственности
    /// </summary>
    public class Okfs : Interface.IClassifier
    {
        public Okfs ()
        {
            Entrepreneurs = new HashSet<Entrepreneur> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }

        [EF.AssociationName ("Наименование", EF.FieldOperation.FilterSearch)]
        public string Title { get; set; }

        [EF.AssociationName ("Алгорим сбора")]
        public string CollectionAlgorithm { get; set; }

        public virtual ICollection<Entrepreneur> Entrepreneurs { get; set; }
    }
}
