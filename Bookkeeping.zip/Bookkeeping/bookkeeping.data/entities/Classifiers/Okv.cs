﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Общероссийский классификатор валют
    /// </summary>
    public class Okv : Interface.IClassifier
    {
        public Okv ()
        {
            Accounts = new HashSet<Account> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }

        [EF.AssociationName ("Значение", EF.FieldOperation.FilterSearch)]
        public string CharCode { get; set; }
        [EF.AssociationName ("Наименование", EF.FieldOperation.FilterSearch)]
        public string Name { get; set; }
        [EF.AssociationName ("Страна")]
        public string Countries { get; set; }

        public virtual ICollection<Account> Accounts { get; set; }
    }
}
