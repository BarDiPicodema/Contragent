﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Общероссийский классификатор организационно-правовых форм. 
    /// </summary>
    public class Okopf : Interface.IClassifier
    {
        public Okopf ()
        {
            Entrepreneurs = new HashSet<Entrepreneur> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }

        [EF.AssociationName ("Наименование", EF.FieldOperation.FilterSearch)]
        public string Title { get; set; }

        public virtual ICollection<Entrepreneur> Entrepreneurs { get; set; }
    }
}
