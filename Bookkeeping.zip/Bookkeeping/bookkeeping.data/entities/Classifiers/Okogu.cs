﻿using System.Collections.Generic;

namespace Bookkeeping.Data.Entities
{
    /// <summary>
    /// Общероссийский классификатор органов государственной власти и управления
    /// </summary>
    public class Okogu : Interface.IClassifier
    {
        public Okogu ()
        {
            Entrepreneurs = new HashSet<Entrepreneur> ();
        }

        public decimal Id { get; set; }

        [EF.AssociationName ("Код", EF.FieldOperation.FilterSearch)]
        public string NumberCode { get; set; }

        [EF.AssociationName ("Наименование", EF.FieldOperation.FilterSearch)]
        public string Title { get; set; }
        [EF.AssociationName ("Полное наименование")]
        public string FullName { get; set; }

        public virtual ICollection<Entrepreneur> Entrepreneurs { get; set; }
    }
}
