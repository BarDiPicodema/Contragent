﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.Data
{
    public class AdministratorDefaultCredentials
    {
        public const string Login = "Tester";
        public const string Password = "159";
    }
}
