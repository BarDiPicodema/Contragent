﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using Bookkeeping.Data.Migrations;

namespace Bookkeeping.Data
{
    public class BookkeepingDatabaseInitializer : IDatabaseInitializer<BookkeepingContext>
    {
        public virtual void InitializeDatabase (BookkeepingContext context)
        {
            if ( !context.Database.Exists () )
            {
                context.Database.Create ();
                Configuration.SeedDefaultAdmin (context);
                context.SaveChanges ();
            }
            else
                return;
        }
    }
}
