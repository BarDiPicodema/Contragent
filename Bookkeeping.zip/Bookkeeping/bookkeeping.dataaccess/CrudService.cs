﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.EF;
using Bookkeeping.Data;
using Bookkeeping.Data.Entities;
using Bookkeeping.DataAccess.Interfaces;
using System.Data.Entity;
using System.Linq.Expressions;
using System.Reflection;

namespace Bookkeeping.DataAccess
{
    public class CrudService<TEntity> : ICrudService<TEntity> where TEntity : class, IEntity, new()
    {
        protected virtual BookkeepingContext DataContext { get; private set; }

        public CrudService (BookkeepingContext dataContext)
        {
            DataContext = dataContext;
        }

        protected virtual DbSet<TEntity> BaseSet { get { return DataContext.Set<TEntity> (); } }

        public IList<TEntity> SQLQuery (string query, params object[] parameters)
        {
            var data = DataContext.Database.SqlQuery<TEntity> (query, parameters);
            return data.ToList<TEntity>();
        }

        public IList<TEntity> GetList (Expression<Func<TEntity, bool>> where)
        {
            if ( where == null ) throw new ArgumentNullException ("get list where");

            IQueryable<TEntity> dbQuery = BaseSet.IncludeAll ();
            string name = typeof (TEntity).Name;
            return dbQuery.AsNoTracking ().Where (where).ToList ();
        }

        public IList<TEntity> GetAll ()
        {
            IQueryable<TEntity> dbQuery = BaseSet.IncludeAll();
            return dbQuery.AsNoTracking ().ToList ();
        }

        public TEntity Find (Func<TEntity, bool> where)
        {
            if ( where == null ) throw new ArgumentNullException ("find where");
            IQueryable<TEntity> dbQuery = BaseSet.IncludeAll();
            return dbQuery.AsNoTracking ().FirstOrDefault (where);
        }

        public IQueryable<TEntity> All { get { return BaseSet.IncludeAll(); } }

        public TEntity Create (TEntity entity)
        {
            if (entity == null) return null;
            var result = BaseSet.Add (entity);
            DataContext.Entry (entity).State = EntityState.Added;
            DataContext.SaveChanges ();

            DataContext.Entry (entity).State = EntityState.Detached;
            return result;
        }

        public TEntity Update (TEntity entity)
        {
            if (entity == null) return null;

            var result = BaseSet.Attach (entity);
            DataContext.Entry (entity).State = EntityState.Modified;
            DataContext.SaveChanges ();

            DataContext.Entry (entity).State = EntityState.Detached;
            return result;
        }

        public void Delete (TEntity entity)
        {
            if ( entity == null ) return;
            BaseSet.Attach (entity);
            DataContext.Entry (entity).State = EntityState.Deleted;
            DataContext.SaveChanges ();

            DataContext.Entry (entity).State = EntityState.Detached;
        }
    }
}
