﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data;
using System.Linq.Expressions;

namespace Bookkeeping.DataAccess.Interfaces
{
    public interface ICrudService<T> where T : class, IEntity
    {
        /// <summary>
        /// Получить сущности по запросу 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        IList<T> SQLQuery (string query, params object[] parameters);

        /// <summary>
        /// Получить все сущности по лямбда выражению, включая агрегаты
        /// </summary>
        /// <param name="where">лямбда выражение</param>
        /// <param name="navigationProperties">включаемые сущности</param>
        /// <returns></returns>
        IList<T> GetAll ();

        IList<T> GetList (Expression<Func<T, bool>> where);

        /// <summary>
        /// Получить сущность по лямбда выражению и его агрегаты
        /// </summary>
        /// <param name="where">лямбда выражение</param>
        /// <param name="navigationProperties">включаемые сущности</param>
        /// <returns></returns>
        T Find (Func<T, bool> where);

        /// <summary>
        /// Получить все сущности
        /// </summary>
        IQueryable<T> All {get;}

        /// <summary>
        /// Создает сущность
        /// </summary>
        /// <param name="entity"></param>
        T Create (T entity);

        /// <summary>
        /// Обновляет сущность
        /// </summary>
        /// <param name="entity"></param>
        T Update (T entity);

        /// <summary>
        /// Удалить сущность
        /// </summary>
        /// <param name="?"></param>
        void Delete (T entity);
    }
}
