﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;
using Bookkeeping.DataAccess.Interfaces;

namespace Bookkeeping.DataAccess
{
    public class NomenclatureService
    {
        private IDictionary<Type, object> _dictionary;

        public NomenclatureService ()
        {
            _dictionary = new Dictionary<Type, object> ();
        }

        public void AddCrud<TEntity> (ICrudService<TEntity> crud) where TEntity : class, IEntity
        {
            _dictionary.Add (typeof (TEntity), crud);
        }

        public ICrudService<TEntity> GetCrud<TEntity> () where TEntity : class, IEntity
        {
            var type = typeof(TEntity);
            if ( _dictionary.ContainsKey (type) )
                return _dictionary[type] as ICrudService<TEntity>;
            return null;
        }

        public ICrudService<AccessType> AccessTypes 
        {
            get { return GetCrud<AccessType> (); } 
        }

        public ICrudService<Flag> Flags 
        {
            get {return GetCrud<Flag> ();}
        }

        public ICrudService<Signing> Signing
        {
            get { return GetCrud<Signing>(); }
        }

        public ICrudService<Okato> Okato
        {
            get { return GetCrud<Okato> (); }
        }

        public ICrudService<Okfs> Okfs
        {
            get { return GetCrud<Okfs> (); }
        }

        public ICrudService<Okogu> Okogu
        {
            get { return GetCrud<Okogu> (); }
        }

        public ICrudService<Okopf> Okopf
        {
            get { return GetCrud<Okopf> (); }
        }

        public ICrudService<Oksm> Oksm
        {
            get { return GetCrud<Oksm> (); }
        }

        public ICrudService<Okv> Okv
        {
            get { return GetCrud<Okv> (); }
        }

        public ICrudService<Okved> Okved
        {
            get { return GetCrud<Okved> (); }
        }

        public ICrudService<Sono> Sono
        {
            get { return GetCrud<Sono> (); }
        }

        public ICrudService<User> Users
        {
            get { return GetCrud<User> (); }
        }

        public ICrudService<UserGrant> UserGrants
        {
            get { return GetCrud<UserGrant> (); }
        }

        public ICrudService<Departament> Departaments
        {
            get { return GetCrud<Departament> (); }
        }

        public ICrudService<Partner> Partners
        {
            get { return GetCrud<Partner> (); }
        }

        public ICrudService<Individual> Individuals
        {
            get { return GetCrud<Individual> (); }
        }

        public ICrudService<Entrepreneur> Entrepreneurs
        {
            get { return GetCrud<Entrepreneur> (); }
        }

        public ICrudService<Classifier> Classifiers
        {
            get { return GetCrud<Classifier> (); }
        }

        public ICrudService<Specification> Specifications
        {
            get { return GetCrud<Specification> (); }
        }

        public ICrudService<AccountType> AccountTypes
        {
            get { return GetCrud<AccountType> (); }
        }

        public ICrudService<AccountKind> AccountKinds
        {
            get { return GetCrud<AccountKind> (); }
        }

        public ICrudService<Account> Accounts
        {
            get { return GetCrud<Account> (); }
        }

        public ICrudService<AddressType> AddressTypes
        {
            get { return GetCrud<AddressType> (); }
        }

        public ICrudService<Address> Addresses
        {
            get { return GetCrud<Address> (); }
        }

        public ICrudService<AddressValue> AddressValues
        {
            get { return GetCrud<AddressValue> (); }
        }

        public ICrudService<ContactType> ContactTypes
        {
            get { return GetCrud<ContactType> (); }
        }

        public ICrudService<Contact> Contacts
        {
            get { return GetCrud<Contact> (); }
        }

        public ICrudService<ProcessType> ProcessType
        {
            get { return GetCrud<ProcessType> (); }
        }

        public ICrudService<Process> Processes
        {
            get { return GetCrud<Process> (); }
        }

        public ICrudService<Link> Links
        {
            get { return GetCrud<Link> (); }
        }

        public ICrudService<DocumentType> DocumentTypes
        {
            get { return GetCrud<DocumentType> (); }
        }

        public ICrudService<Document> Documents
        {
            get { return GetCrud<Document> (); }
        }

        public ICrudService<DocumentParticipant> DocumentParicipants
        {
            get { return GetCrud<DocumentParticipant> (); }
        }

        public ICrudService<GroupType> GroupTypes
        {
            get { return GetCrud<GroupType> (); }
        }

        public ICrudService<GroupTypeToType> GroupTypeToTypes
        {
            get { return GetCrud<GroupTypeToType> (); }
        }

        public ICrudService<Group> Groups
        {
            get { return GetCrud<Group> (); }
        }

        public ICrudService<AssociationTable> AssociationTables
        {
            get { return GetCrud<AssociationTable> (); }
        }

        public ICrudService<Filter> Filters
        {
            get { return GetCrud<Filter> (); }
        }

        public ICrudService<QueryNode> QueryNodes 
        {
            get { return GetCrud<QueryNode> (); } 
        }

        public ICrudService<FilterValue> FilterValues
        {
            get { return GetCrud<FilterValue> (); }
        }
    }
}
