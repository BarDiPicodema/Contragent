﻿using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Settings;
using Bookkeeping.ClientApp.View.ClientWindow;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.ClientPresenter
{
    public interface IMainView : Common.IViewParent
    {
        event Action Login;
        event Action ExitToLogin;
        event Action Exit;

        event Action OpenContractors;
        event Action CreateContractor;
        event Action FilterSettings;

        event Action OpenPlaner;
        event Action CreateEvent;

        string StateProgramm { get; set; }
    }

    public class MainPresenter : Common.BasePresenterWindow<IMainView>
    {
        public MainPresenter (IMainView view)
            : base (view)
        {
            View.Login += () => LoginWindowShow ();
            View.Exit += () => ExitEvent ();

            View.OpenContractors += () => ContractorsWindowOpen ();
            View.CreateContractor += () => CreateContractorWindowShow ();
            View.FilterSettings += () => FilterSettingsWindowShow ();

            View.OpenPlaner += () => TestEvent ();
            View.CreateEvent += () => TestEvent ();
        }

        public void Run ()
        {
            Context.MainForm = (Form) View;
            View.Show ();
        }

        public void LoginWindowShow ()
        {
            LoginPresenter presenter = new LoginPresenter (new Bookkeeping.ClientApp.View.LoginWindow (), 
                                                                             new Model.ServiceModel<Data.Entities.User> ());
            presenter.Run ();
            View.ExitToLogin -= () => ExitToLoginEvent ();
            View.Close ();
        }

        public void ContractorsWindowOpen ()
        {
            var presenter = new Counterparties.ContractorPresenter (new View.Counterparties.ContractorsWindow (), new Model.Counterparties.ReportModel.ReportService());
            presenter.Run ();
        }

        public void CreateContractorWindowShow ()
        {
            var presenter = new DialogPresenter (new AddContractorControl (), new DialogWindow ());
            presenter.Run ();
        }

        public void FilterSettingsWindowShow ()
        {
            var presenter = new FilterSettingsPresenter (new View.Counterparties.FilterSettings.FilterSettingsWindow (), 
                                                                        new Model.ServiceModel<Data.EntityHelper.Filter>(), 
                                                                        new Model.DatabaseReflection.FilterReflectionService());
            presenter.Init ();
            presenter.Run ();
        }

        private void TestEvent ()
        {
        }

        private void ExitToLoginEvent ()
        {
        }

        private void ExitEvent ()
        {
            Application.Exit ();
        }
    }
}
