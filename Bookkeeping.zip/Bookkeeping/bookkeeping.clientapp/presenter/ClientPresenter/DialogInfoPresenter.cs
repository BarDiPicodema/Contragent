﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Counterparties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.ClientPresenter
{
    public interface IDialogView : Common.IView
    {
        string Title { get; set; }
        UserControl ContentControl { get; set; }
    }

    public class DialogInfoPresenter<TArgs> : Common.BasePresenterWindow<IDialogView, TArgs>
    {
        public DialogInfoPresenter (View.Common.CUIControl control, IDialogView view) 
            : base (view)
        {
            View.ContentControl = control;
            View.Title = control.NameTitle;
        }

        public override void Init ()
        {
            var control = View.ContentControl as Common.IViewControl;
            var presenter = control.Presenter as Common.IPresenterControl<TArgs>;
            presenter.Init ();
        }

        public override void Run (TArgs args)
        {
            Init ();

            ( (Common.IPresenterControl<TArgs>) ( (Common.IViewControl) View.ContentControl ).Presenter ).Refresh (args);
            this.Show ();
        }

        public void Show ()
        {
            View.Show ();
        }

        public void Hide ()
        {

        }

        public void Close ()
        {
            View.Close ();
        }
    }
}
