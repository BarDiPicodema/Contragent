﻿using Bookkeeping.ClientApp.Presenter.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.ClientPresenter
{
    public class DialogPresenter : Common.BasePresenterWindow<IDialogView>
    {
        public DialogPresenter (View.Common.CUIControl control, IDialogView view)
            : base (view)
        {
            View.ContentControl = control;
            View.Title = control.NameTitle;
        }

        public void Show ()
        {
            View.Show ();
        }

        public void Hide ()
        {

        }

        public void Close ()
        {
            View.Close ();
        }
    }
}
