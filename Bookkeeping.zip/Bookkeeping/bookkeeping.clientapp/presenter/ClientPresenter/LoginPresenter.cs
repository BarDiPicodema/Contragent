﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.ClientPresenter
{
    public interface ILoginView : Common.IView
    {
        List<string> Usernames { get; set; }
        string Username { get; }
        string Password { get; }

        event Action Login;
    }

    public class LoginPresenter : Common.BasePresenterWindow<ILoginView>
    {
        private ServiceModel<User> _service;

        public LoginPresenter (ILoginView view, ServiceModel<User> service)
            : base (view)
        {
            _service = service;
            _service.Init ();

            List<string> logins = new List<string> ();
            _service.GetAll ().ToList ().ForEach (item => logins.Add (item.Login));
            View.Usernames = logins;

            View.Login += () => LoginUser (View.Username, View.Password);
        }

        public void Run ()
        {
            Context.MainForm = (Form) View;
            View.Show ();
        }

        public void LoginUser (string username, string password)
        {
            if ( username == null )
                throw new ArgumentException ("Username error");
            if ( password == null )
                throw new ArgumentException ("Passsword error");

            var user = _service.FindEntity (item => item.Login == username);
            if ( user.Password != password )
                System.Windows.Forms.MessageBox.Show ("Неправильный пароль!");
            else
            {
                CurrentUser.User = user;

                MainPresenter main = new MainPresenter (new Bookkeeping.ClientApp.View.MainWindow ());
                main.Run ();
                View.Close ();
            }
        }
    }
}
