﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.Model.Counterparties.ReportModel;

namespace Bookkeeping.ClientApp.Presenter.Counterparties
{
    public interface IContractorView : Common.IViewChild
    {
        IContractorMenuView MenuView { get; }
        ContractorMenuPresenter MenuPresenter { get; }

        ITemplateGridView<Partner> PartnerGridView { get; }
        PartnerGridPresenter PartnerGridPresenter { get; }

        ITemplateGridView<Contractor> ContractorGridView { get; }
        ContractorGridPresenter ContractorGridPresenter { get; }

        IFilterView FilterView { get; }
        FilterPresenter FilterPresenter { get; }

        IInfoView InfoView { get; }
        InfoPresenter InfoPresenter { get; }
    }

    /// <summary>
    /// TODO presenters and view
    /// </summary>
    public class ContractorPresenter : Common.BasePresenterChildrenWindow<IContractorView>
    {
        public ContractorPresenter (IContractorView view, ReportService reportService) 
            : base (view)
        {
            _service = reportService;

            View.PartnerGridView.SelectedItem += () => PartnerSelectedChanged (View.PartnerGridView.SelectedEntity);
            View.ContractorGridView.SelectedItem += () => ContractorSelectedChanged (View.ContractorGridView.SelectedEntity);

            View.FilterView.CheckedTreeItem += () => FilterSelected ();

            View.MenuView.NewContractor += () => ShowAddContractorControl ();
            View.MenuView.SearchRun += () => SearchRun ();
            View.MenuView.ShowContractor += () => ShowContractor ();

            View.MenuView.PrintPhone += () => PrintContractorContacts ();
            View.MenuView.PrintDataContractor += () => PrintContractorCard ();
        }

        private ReportService _service;

        public void Run ()
        {
            Parent.ShowChildren (View);
            View.Show ();

            View.MenuPresenter.Init ();
            View.PartnerGridPresenter.Init ();
            View.ContractorGridPresenter.Init ();
            View.InfoPresenter.Init ();
            View.FilterPresenter.Init ();

            View.PartnerGridPresenter.Refresh ();
            View.FilterPresenter.Refresh ();
        }

        private void SearchRun ()
        {
            View.MenuView.SearchTreeView.PartnerQuery.ClearValues ();
            View.MenuView.SearchTreeView.PartnerQuery.AddValue (View.MenuView.SearchValue);
            View.PartnerGridPresenter.Search (View.MenuView.SearchTreeView.PartnerQuery);
        }

        private void FilterSelected ()
        {
            View.PartnerGridPresenter.PartnerFilter (View.FilterView.SelectedPartnerFilter.ToArray ());
            View.ContractorGridPresenter.ContractorFilter (View.PartnerGridView.SelectedEntity,
                                                                           View.FilterView.SelectedIndividualFilter.ToArray (),
                                                                           View.FilterView.SelectedEntrepreneurFilter.ToArray ());
        }

        public void PartnerSelectedChanged (Partner partner)
        {
            if ( partner == null )
                return;

            var infoPresenter = View.InfoPresenter;
            infoPresenter.Refresh (partner);

            var contractorGridPresenter = View.ContractorGridPresenter;
            contractorGridPresenter.Refresh (View.PartnerGridView.SelectedEntity);
        }

        public void ContractorSelectedChanged (Contractor contractor)
        {
            if (contractor == null)
                return;

            var presenter = View.InfoPresenter;

            if ( contractor.TypeContractor == ContractorTypes.Individual )
                presenter.Refresh ((Individual) contractor);
            if ( contractor.TypeContractor == ContractorTypes.Entrepreneur )
                presenter.Refresh ((Entrepreneur) contractor);
        }

        /// <summary>
        /// TODO отобразить контрагента фокусированной таблицы, если фокуса нет, то отобразить партнера
        /// </summary>
        private void ShowContractor ()
        {
            View.PartnerGridPresenter.EditPartner (View.PartnerGridView.SelectedEntity);
        }

        private void ShowAddContractorControl ()
        {
            var presenter = new Presenter.ClientPresenter.DialogPresenter (new View.Counterparties.ExtraControls.AddContractorControl (),
                                                                                                 new View.ClientWindow.DialogWindow ());
            presenter.Run ();
        }

        private void PrintContractorCard ()
        {
            var partner = View.PartnerGridView.SelectedEntity;
            var contractor = View.ContractorGridView.SelectedEntity;

            if ( contractor != null )
            {
                _service.GenerateContractorCard (new ContractorCard (), contractor);
            }
            else
            {
                _service.GenerateContractorCard (new ContractorCard (), new Contractor (partner));
            }
        }

        private void PrintContractorContacts ()
        {
            var partner = View.PartnerGridView.SelectedEntity;
            var contractor = View.ContractorGridView.SelectedEntity;

            if ( contractor != null )
            {
                _service.GenerateContractorCard (new ContactCard (), contractor);
            }
            else
            {
                _service.GenerateContractorCard (new ContactCard (), new Contractor (partner));
            }
        }
    }
}
