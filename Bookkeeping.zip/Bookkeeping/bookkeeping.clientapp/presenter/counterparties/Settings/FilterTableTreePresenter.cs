﻿using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator;
using Bookkeeping.ClientApp.Model.DatabaseReflection;
using Bookkeeping.ClientApp.Presenter.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Settings
{
    public interface IFilterTableTreeView : Common.IViewTreeControl
    {
        QueryManager Manager { get; set; }
        event Action AfterCheck;
    }

    public class FilterTableTreePresenter : Common.IPresenterControl
    {
        private IFilterTableTreeView _view;
        private FilterReflectionService _service;

        private List<FilterTableNode> _nodes;

        public FilterTableTreePresenter (IFilterTableTreeView view, FilterReflectionService service)
        {
            _view = view;
            _service = service;

            _view.AfterCheck += () => AfterChecked ();
        }

        public void Init ()
        {
        }

        public void Refresh ()
        {
            ElementNode[] arrayFilterTable = GetInitFilterNode ();
            var partnerNode = ( arrayFilterTable[0].ReadebleName == "Partners" ) ? arrayFilterTable[0] : ( arrayFilterTable[1].ReadebleName == "Partners" ) ? arrayFilterTable[1] : arrayFilterTable[2];
            var individualNode = ( arrayFilterTable[0].ReadebleName == "Individuals" ) ? arrayFilterTable[0] : ( arrayFilterTable[1].ReadebleName == "Individuals" ) ? arrayFilterTable[1] : arrayFilterTable[2];
            var entrepreneurNode = ( arrayFilterTable[0].ReadebleName == "Entrepreneurs" ) ? arrayFilterTable[0] : ( arrayFilterTable[1].ReadebleName == "Entrepreneurs" ) ? arrayFilterTable[1] : arrayFilterTable[2];

            var general = new FilterTableNode (partnerNode, individualNode, entrepreneurNode);
            var partner = new FilterTableNode (partnerNode);
            var individual = new FilterTableNode (individualNode);
            var entrepreneur = new FilterTableNode (entrepreneurNode);

            foreach ( var firstTable in _service.GetElementNodeFilterFromElementNode (partnerNode) )
                foreach ( var secondTable in _service.GetElementNodeFilterFromElementNode (individualNode) )
                    if ( firstTable.ReadebleName.Equals (secondTable.ReadebleName) )
                    {
                        foreach ( var threeTable in _service.GetElementNodeFilterFromElementNode (entrepreneurNode) )
                            if ( secondTable.ReadebleName.Equals (threeTable.ReadebleName) )
                                general.Nodes.Add (FillFilterNodes (firstTable));
                    }

            partner = FillTableNodeFromTreeNode (general, partnerNode, partner);
            individual = FillTableNodeFromTreeNode (general, individualNode, individual);
            entrepreneur = FillTableNodeFromTreeNode (general, entrepreneurNode, entrepreneur);

            _view.Nodes.Add (general);
            _view.Nodes.Add (partner);
            _view.Nodes.Add (individual);
            _view.Nodes.Add (entrepreneur);
        }

        #region Auxiliary method Refresh
        private ElementNode[] GetInitFilterNode ()
        {
            ElementNode[] arrayFilterTable = new ElementNode[3];
            var initTables = _service.GetInitialDataTables ();
            for ( int i = 0; i < initTables.Count; i++ )
            {
                arrayFilterTable[i] = initTables.ElementAt (i);
            }
            return arrayFilterTable;
        }

        private FilterTableNode FillTableNodeFromTreeNode (FilterTableNode general, ElementNode node, FilterTableNode treeNode)
        {
            foreach ( var table in _service.GetElementNodeFilterFromElementNode (node) )
            {
                var type = ( table.TypeProperty == TypeProperty.TableProperty ) ? "Table" : "Column";
                if ( general.Nodes.Find (table.ReadebleName + type, true).Length == 0 )
                    treeNode.Nodes.Add (FillFilterNodes (table));
            }
            return treeNode;
        }

        private FilterTableNode FillFilterNodes (ElementNode node)
        {
            FilterTableNode filterNode = new FilterTableNode (node);
            foreach ( var item in _service.GetElementNodeFilterFromElementNode (node) )
            {
                if ( item.TypeProperty == TypeProperty.ColumnProperty )
                    filterNode.Nodes.Add (new FilterTableNode (item));
                else filterNode.Nodes.Add (FillFilterNodes (item));
            }
            return filterNode;
        }
        #endregion

        private void AfterChecked ()
        {
            _nodes = new List<FilterTableNode> ();
            _view.Manager = new QueryManager (new FilterGenerate (":p"));

            GetCheckedNodes (_view.CheckedItem as TreeNode);
            if ( _nodes.Count < 2 )
                return;

            for (int i = 1; i < _nodes.Count; i ++ )
            {
                var firstNode = _nodes.ElementAt (i);
                var secondNode = _nodes.ElementAt (i - 1);
                if (firstNode.ElementNode != null && secondNode.ElementNode != null)
                    _view.Manager.AddNode (new QueryNodeString (firstNode.ElementNode, secondNode.ElementNode));
                
                if (firstNode.ElementNode == null)
                {
                    _view.Manager.AddNode (new QueryNodeString (firstNode.PartnerNode, secondNode.ElementNode));
                    _view.Manager.AddNode (new QueryNodeString (firstNode.PartnerNode));
                    _view.Manager.AddNode (new QueryNodeString (firstNode.IndividualNode, secondNode.ElementNode));
                    _view.Manager.AddNode (new QueryNodeString (firstNode.IndividualNode));
                    _view.Manager.AddNode (new QueryNodeString (firstNode.EntrepreneurNode, secondNode.ElementNode));
                    _view.Manager.AddNode (new QueryNodeString (firstNode.EntrepreneurNode));
                }
            }
        }

        private void GetCheckedNodes (TreeNode node)
        {
            if ( node != null )
            {
                _nodes.Add (node as FilterTableNode);
                GetCheckedNodes (node.Parent);
            }
        }
    }

    public class FilterTableNode : System.Windows.Forms.TreeNode
    {
        public FilterTableNode (ElementNode node)
        {
            if ( node.ReadebleName == "Partners" )
                PartnerNode = node;
            else if ( node.ReadebleName == "Individuals" )
                IndividualNode = node;
            else if ( node.ReadebleName == "Entrepreneurs" )
                EntrepreneurNode = node;

            ElementNode = node;

            string type = ( node.TypeProperty == TypeProperty.TableProperty ) ? "Table" : "Column";
            Name = node.ReadebleName + type;
            Text = node.ReadebleAssociationName;

            if ( node.TypeProperty == TypeProperty.TableProperty )
                ForeColor = System.Drawing.Color.Red;
            else ForeColor = System.Drawing.Color.Green;
        }
        
        /// <summary>
        /// General
        /// TODO : ахуительное решение
        /// </summary>
        public FilterTableNode (ElementNode nodeOne, ElementNode nodeTwo, ElementNode nodeThree)
        {
            PartnerNode = nodeOne;
            IndividualNode = nodeTwo;
            EntrepreneurNode = nodeThree;

            Name = "General";
            Text = "Общий";

            ForeColor = System.Drawing.Color.Red;
        }

        public ElementNode PartnerNode { get; private set; }
        public ElementNode IndividualNode { get; private set; }
        public ElementNode EntrepreneurNode { get; private set; }

        public ElementNode ElementNode { get; private set; }
    }
}
