﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.DatabaseReflection;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.EntityHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Settings
{
    public interface IFilterSettingsView : Common.IViewChild
    {
        IFilterTableTreeView FilterTableTreeView { get; }
        FilterTableTreePresenter FilterTableTreePresenter { get; }

        string NameFilter { get; set; }
        System.Windows.Forms.CheckedListBox.ObjectCollection Values { get; set; }
        IList<string> SelectedValues { get; }

        event Action SaveFilter;
    }

    public class FilterSettingsPresenter : Common.BasePresenterChildrenWindow<IFilterSettingsView>
    {
        private ServiceModel<Filter> _service;
        private FilterReflectionService _reflectionService;
        private ServiceModel<QueryNode> _serviceQuery;
        private ServiceModel<FilterValue> _serviceValue;

        public FilterSettingsPresenter (IFilterSettingsView view, ServiceModel<Filter> service, FilterReflectionService reflectionFilter) 
            : base (view)
        {
            View.FilterTableTreeView.CheckedTreeItem += () => CheckedNode ();
            View.SaveFilter += () => Save ();

            _reflectionService = reflectionFilter;
            _service = service;
            _serviceValue = new ServiceModel<FilterValue> ();
            _serviceQuery = new ServiceModel<QueryNode> ();
        }

        public void Init ()
        {
            _service.Init ();
            _serviceQuery.Init ();
            _serviceValue.Init ();
        }

        public void Run ()
        {
            Parent.ShowChildren (View);
            View.Show ();

            View.FilterTableTreePresenter.Refresh ();
        }

        private void CheckedNode ()
        {
            View.Values.Clear ();

            FilterTableNode column = View.FilterTableTreeView.CheckedItem as FilterTableNode;
            FilterTableNode table = column.Parent as FilterTableNode;

            foreach (FilterTableNode node in table.Nodes)
                if ( node.Checked == true )
                    column = node;

            if (column != null && column.ElementNode.TypeProperty == Model.DatabaseReflection.TypeProperty.ColumnProperty )
                foreach ( var item in _reflectionService.GetValues (table.ElementNode, column.ElementNode) )
                    View.Values.Add (item);
        }

        private void Save ()
        {
            if (View.NameFilter == "")
            {
                System.Windows.Forms.MessageBox.Show ("Название фильтра не заполнено!");
                return;
            }

            Filter filter = new Filter ();
            filter.NameFilter = View.NameFilter;

            QueryNode node = null;
            foreach ( var item in View.FilterTableTreeView.Manager.Nodes )
            {
                var query = new QueryNode ();
                query.SqlQueryNode = item.Node;
                node = _serviceQuery.AddOrUpdateEntity (query);
                filter.QueryNodes.Add (node);
            }

            _service.AddOrUpdateEntity (filter);

            foreach ( var value in View.SelectedValues )
            {
                var filterValue = new FilterValue () { ValueFilter = value, IdQueryNode = node.Id, QueryNode = node };
                _serviceValue.AddOrUpdateEntity (filterValue);
            }
        }
    }
}
