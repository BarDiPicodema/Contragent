﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo
{
    public interface IContractorTreeView : Common.IViewTreeControl
    {
        event Action ContractorView;

        void Expand ();
    }

    public class ContractorTreePresenter : Common.IPresenterControlInfo
    {
        private IContractorTreeView _view;
        private AccessServiceModel<Partner> _service;
        private ClientServiceModel _serviceClient;

        public ContractorTreePresenter (IContractorTreeView view, AccessServiceModel<Partner> service)
        {
            _view = view;
            _service = service;

            _serviceClient = new ClientServiceModel ();
        }

        public void Init ()
        {
            _service.Init ();
            _serviceClient.Init ();
        }

        public void Refresh (Partner partner)
        {
            _view.Nodes.Clear ();

            if ( partner != null )
            {
                TreeNode parent = new ContractorTreeNode<ICounterparties> () { Entity = partner };
                foreach ( var item in _serviceClient.GetIndividualsFromPartner (partner) )
                    parent.Nodes.Add (new ContractorTreeNode<ICounterparties> () { Entity = item });
                
                var entrepreneurs = _serviceClient.GetEntreprenseursFromPartner (partner);
                if (entrepreneurs != null)
                    foreach ( var item in entrepreneurs )
                        parent.Nodes.Add (new ContractorTreeNode<ICounterparties> () { Entity = item });
                _view.Nodes.Add (parent);
            }

            _view.Expand ();
        }

        public void Refresh (Individual individual)
        {
            _view.Nodes.Clear ();
            
            if ( individual == null )
                return;
                
            var partner = _service.FindEntity (item => item.Id == individual.IdPartner);
            //if ( partner == null )
            //    throw new Exception (string.Format ("Error. Current legal individual: {0} is not a partner!", individual.Alias));

            Refresh (partner);
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            _view.Nodes.Clear ();

            if ( entrepreneur == null )
                return;

            var partner = _service.FindEntity (item => item.Id == entrepreneur.IdPartner);
            //if ( partner == null )
            //    throw new Exception (string.Format ("Error. Current legal entrepreneur: {0} is not a partner!", entrepreneur.Alias));

            Refresh (partner);
        }
    }
}
