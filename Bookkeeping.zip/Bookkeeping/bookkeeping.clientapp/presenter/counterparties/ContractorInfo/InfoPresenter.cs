﻿using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo
{
    public interface IInfoView : Common.IViewControl
    {
        AccountGridPresenter AccountGridPresenter { get; }
        AddressGridPresenter AddressGridPresenter { get; }
        ContactGridPresenter ContactGridPresenter { get; }
        DocumentGridPresenter DocumentGridPresenter { get; }
    }

    public class InfoPresenter : Common.IPresenterControlInfo
    {
        IInfoView _view;

        public InfoPresenter (IInfoView view)
        {
            _view = view;
        }

        private void RunRefresh (Action action)
        {

        }

        public void Refresh (Partner partner)
        {
            Task refreshAccount = new Task (() => _view.AccountGridPresenter.Refresh (partner));
            Task refreshAddress = new Task (() => _view.AddressGridPresenter.Refresh (partner));
            Task refreshContact = new Task (() => _view.ContactGridPresenter.Refresh (partner));
            Task refreshDocument = new Task (() => _view.DocumentGridPresenter.Refresh(partner));

            refreshAccount.Start ();
            refreshAddress.Start ();
            refreshContact.Start ();
            refreshDocument.Start ();
        }

        public void Refresh (Individual individual)
        {
            _view.AccountGridPresenter.Refresh (individual);
            _view.AddressGridPresenter.Refresh (individual);
            _view.ContactGridPresenter.Refresh (individual);
            _view.DocumentGridPresenter.Refresh (individual);
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            _view.AccountGridPresenter.Refresh (entrepreneur);
            _view.AddressGridPresenter.Refresh (entrepreneur);
            _view.ContactGridPresenter.Refresh (entrepreneur);
            _view.DocumentGridPresenter.Refresh (entrepreneur);
        }

        public void Init ()
        {
            _view.AccountGridPresenter.Init ();
            _view.AddressGridPresenter.Init ();
            _view.ContactGridPresenter.Init ();
            _view.DocumentGridPresenter.Init ();
        }
    }
}
