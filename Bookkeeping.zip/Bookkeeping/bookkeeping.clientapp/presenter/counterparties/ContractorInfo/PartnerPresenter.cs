﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo
{
    public interface IPartnerView : Common.IViewContractorInfoControl
    {
        Partner Partner { get; set; }

        IEditorToolView EditorToolView { get; set; }
        
        string Alias { get; set; }
        string Region { get; set; }
        string Activity { get; set; }
        string Process { get; set; }

        StateEntity IsDelete { get; set; }
    }

    public class PartnerPresenter : Common.IPresenterControl<Partner>
    {
        private IPartnerView _view;
        private AccessServiceModel<Partner> _service;

        private Partner _tempPartner;

        public PartnerPresenter (IPartnerView view, AccessServiceModel<Partner> service)
        {
            _view = view;
            _service = service;
        }

        private void AddOnPropertyChanged ()
        {
            _view.EditorToolView.SaveData += () => SaveData ();
            _view.EditorToolView.DeleteData += () => DeleteData ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.SigningView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();

            _view.Signing.Init ();
            _view.Flag.Init ();
            _view.AccessType.Init ();

            AddOnPropertyChanged ();
        }

        public void Refresh (Partner partner)
        {
            _view.Partner = partner;

            _view.Signing.Refresh (partner.Signing);
            _view.Flag.Refresh (partner.Flag);
            _view.AccessType.Refresh (partner.AccessType);

            _view.Alias = partner.Alias;
            _view.Region = partner.Region;
            _view.Activity = partner.Activity;
            _view.IsDelete = partner.IsDelete;
        }

        private void OnPropertyChanged ()
        {
            if ( _tempPartner == null )
                _tempPartner = new Partner ();

            _tempPartner.Id = _view.Partner.Id;
            _tempPartner.Alias = _view.Alias;
            _tempPartner.Region = _view.Region;
            _tempPartner.Activity = _view.Activity;
            _tempPartner.IsDelete = _view.IsDelete;

            if ( _view.SigningView.SelectedEntity != null )
                _tempPartner.IdSigning = ( _view.SigningView.SelectedEntity as Signing ).Id;

            if ( _view.FlagView.SelectedEntity != null )
                _tempPartner.IdFlag = ( _view.FlagView.SelectedEntity as Flag ).Id;

            if ( _view.AccessTypeView.SelectedEntity != null )
                _tempPartner.IdAccessType = ( _view.AccessTypeView.SelectedEntity as AccessType ).Id;
        }

        private void SaveData ()
        {
            if ( _tempPartner != null )
            {
                if ( _tempPartner.IdFlag == 0 || _tempPartner.IdSigning == 0 || _tempPartner.IdAccessType == 0
                    || _tempPartner.Alias == string.Empty )
                {
                    System.Windows.Forms.MessageBox.Show ("Вы не заполнили обязательные поля! См. <*>");
                    return;
                }

                _tempPartner.IdUser = _view.Partner.IdUser;

                if ( _tempPartner != null )
                    _service.AddOrUpdateEntity (_tempPartner);
            }
        }

        private void DeleteData ()
        {
            if (_tempPartner != null)
                _service.RemoveEntity (_view.Partner);
        }
    }
}
