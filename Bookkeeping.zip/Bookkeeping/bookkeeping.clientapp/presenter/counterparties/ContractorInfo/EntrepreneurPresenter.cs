﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo
{
    public interface IEntrepreneurView : Common.IViewContractorInfoControl
    {
        IEditorToolView EditorToolView { get; set; }

        IEntityControlView PartnerView { get; }
        EntityPresenter<Partner> Partner { get; }

        IClassificatorView OkvedView { get; }
        ClassificatorPresenter<Okved> OkvedPresenter { get; }

        IClassificatorView OkopfView { get; }
        ClassificatorPresenter<Okopf> OkopfPresenter { get; }

        IClassificatorView OkfsView { get; }
        ClassificatorPresenter<Okfs> OkfsPresenter { get; }

        IClassificatorView OkoguView { get; }
        ClassificatorPresenter<Okogu> OkoguPresenter { get; }

        string Alias { get; set; }
        string Name { get; set; }
        string Brief { get; set; }
        string Foreign { get; set; }
        DateTime RegistrationDate { get; set; }
        string Ogrn { get; set; }
        string INN { get; set; }
        string KPP { get; set; }
        string Okpo { get; set; }

        Entrepreneur Entrepreneur { get; set; }
    }

    public class EntrepreneurPresenter : Common.IPresenterControl<Entrepreneur>
    {
        private IEntrepreneurView _view;
        private AccessServiceModel<Entrepreneur> _service;

        private Entrepreneur _tempEntrepreneur;

        public EntrepreneurPresenter (IEntrepreneurView view, AccessServiceModel<Entrepreneur> service)
        {
            _view = view;
            _service = service;

        }

        private void AddOnPropertyChanged ()
        {
            _view.EditorToolView.SaveData += () => SaveData ();
            _view.EditorToolView.DeleteData += () => DeleteData ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.PartnerView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.SigningView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();

            _view.OkopfView.OpenClassificator += () => OnPropertyChanged ();
            _view.OkfsView.OpenClassificator += () => OnPropertyChanged ();
            _view.OkoguView.OpenClassificator += () => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();

            _view.Partner.Init ();
            _view.Signing.Init ();
            _view.Flag.Init ();
            _view.AccessType.Init ();
            _view.OkoguPresenter.Init ();
            _view.OkopfPresenter.Init ();
            _view.OkfsPresenter.Init ();

            AddOnPropertyChanged ();
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            _view.Entrepreneur = entrepreneur;

            _view.Partner.Refresh (entrepreneur.Partner);
            _view.Signing.Refresh (entrepreneur.Signing);
            _view.Flag.Refresh (entrepreneur.Flag);
            _view.AccessType.Refresh (entrepreneur.AccessType);

            _view.OkopfPresenter.Refresh (entrepreneur.Okopf);
            _view.OkoguPresenter.Refresh (entrepreneur.Okogu);
            _view.OkfsPresenter.Refresh (entrepreneur.Okfs);

            _view.Name = entrepreneur.Name;
            _view.Alias = entrepreneur.Alias;
            _view.Brief = entrepreneur.BriefName;
            _view.Foreign = entrepreneur.ForeignName;
            _view.RegistrationDate = entrepreneur.RegistrationDate ?? DateTime.Today;
            _view.INN = entrepreneur.INN;
            _view.KPP = entrepreneur.KPP;
            _view.Okpo = entrepreneur.Okpo;
        }

        private void OnPropertyChanged ()
        {
            if ( _tempEntrepreneur == null )
                _tempEntrepreneur = new Entrepreneur ();

            _tempEntrepreneur.Id = _view.Entrepreneur.Id;
            _tempEntrepreneur.Name = _view.Name;
            _tempEntrepreneur.Alias = _view.Alias;
            _tempEntrepreneur.BriefName = _view.Brief;
            _tempEntrepreneur.ForeignName = _view.Foreign;
            //_tempEntrepreneur.RegistrationDate = _view.RegistrationDate ?? null;
            _tempEntrepreneur.INN = _view.INN;
            _tempEntrepreneur.KPP = _view.KPP;
            _tempEntrepreneur.Okpo = _view.Okpo;

            if ( _view.PartnerView.SelectedEntity != null )
                _tempEntrepreneur.IdPartner = ( _view.PartnerView.SelectedEntity as Partner ).Id;

            if ( _view.SigningView.SelectedEntity != null)
                _tempEntrepreneur.IdSigning = (_view.SigningView.SelectedEntity as Signing).Id;

            if ( _view.FlagView.SelectedEntity != null )
                _tempEntrepreneur.IdFlag = ( _view.FlagView.SelectedEntity as Flag ).Id;

            if ( _view.AccessTypeView.SelectedEntity != null )
                _tempEntrepreneur.IdAccessType = ( _view.AccessTypeView.SelectedEntity as AccessType ).Id;

            if ( _view.OkopfView.Classificator != null )
                _tempEntrepreneur.IdOkopf = ( _view.OkopfView.Classificator as Okopf ).Id;

            if ( _view.OkoguView.Classificator != null )
                _tempEntrepreneur.IdOkogu = ( _view.OkoguView.Classificator as Okogu ).Id;

            if ( _view.OkfsView.Classificator != null )
                _tempEntrepreneur.IdOkfs = ( _view.OkfsView.Classificator as Okfs ).Id;
        }

        private void SaveData ()
        {
            if ( _tempEntrepreneur != null )
            {
                if (_tempEntrepreneur.IdFlag == 0 || _tempEntrepreneur.IdSigning == 0 || _tempEntrepreneur.IdAccessType == 0 
                    || _tempEntrepreneur.IdPartner == 0 || _tempEntrepreneur.Alias == string.Empty || _tempEntrepreneur.Name == string.Empty )
                {
                    System.Windows.Forms.MessageBox.Show ("Вы не заполнили обязательные поля! См. <*>");
                    return;
                }

                _service.AddOrUpdateEntity (_tempEntrepreneur);
            }
        }

        private void DeleteData ()
        {
            if (_tempEntrepreneur != null)
                _service.RemoveEntity (_view.Entrepreneur);
        }
    }
}
