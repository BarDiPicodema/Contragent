﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.Data.Interface;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo
{
    public interface IIndividualView : Common.IViewContractorInfoControl
    {
        IEditorToolView EditorToolView { get; set; }

        IEntityControlView PartnerView { get; }
        EntityPresenter<Partner> Partner { get; }

        string Alias { get; set; }
        string FirstName { get; set; }
        string SecondName { get; set; }
        string MiddleName { get; set; }
        Sex Sex { get; set; }
        DateTime BirthDate { get; set; }
        string BirthPlace { get; set; }
        string Citizenship { get; set; }
        string INN { get; set; }
        string Nationality { get; set; }
        string Note { get; set; }
        string InfoWork { get; set; }
        string BloodGroup { get; set; }
        string Snils { get; set; }
        string Med { get; set; }
        StateEntity IsDelete { get; set; }

        Individual Individual { get; set; }
    }

    public class IndividualPresenter : Common.IPresenterControl<Individual>
    {
        private IIndividualView _view;
        private AccessServiceModel<Individual> _service;

        private Individual _tempIndividual;

        public IndividualPresenter (IIndividualView view, AccessServiceModel<Individual> service)
        {
            _view = view;
            _service = service;
        }

        private void AddOnPropertyChanged ()
        {
            _view.EditorToolView.SaveData += () => SaveData ();
            _view.EditorToolView.DeleteData += () => DeleteData ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.PartnerView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.SigningView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();
            _view.Partner.Init ();
            _view.Signing.Init ();
            _view.Flag.Init ();
            _view.AccessType.Init ();

            AddOnPropertyChanged ();
        }

        public void Refresh (Individual individual)
        {
            _view.Individual = individual;

            _view.Partner.Refresh (individual.Partner);
            _view.Signing.Refresh (individual.Signing);
            _view.Flag.Refresh (individual.Flag);
            _view.AccessType.Refresh (individual.AccessType);

            _view.Alias = individual.Alias;
            _view.FirstName = individual.Name;
            _view.SecondName = individual.SecondName;
            _view.MiddleName = individual.MiddleName;
            _view.Sex = individual.Sex;
            _view.BirthDate = individual.BirthDate ?? DateTime.Today;
            _view.BirthPlace = individual.BirthPlace;
            _view.Citizenship = individual.Citizenship;
            _view.INN = individual.INN;
            _view.Nationality = individual.Nationality;
            _view.Note = individual.Note;
            _view.InfoWork = individual.InfoWork;
            _view.BloodGroup = individual.BloodGroup;
            _view.Snils = individual.Snils;
            _view.Med = individual.Med;
            _view.IsDelete = individual.IsDelete;
        }

        private void OnPropertyChanged ()
        {
            if ( _tempIndividual == null )
                _tempIndividual = new Individual ();

            _tempIndividual.Id = _view.Individual.Id;

            _tempIndividual.Alias = _view.Alias;
            _tempIndividual.Name = _view.FirstName;
            _tempIndividual.SecondName = _view.SecondName;
            _tempIndividual.MiddleName = _view.MiddleName;
            _tempIndividual.Sex = _view.Sex;
            _tempIndividual.BirthDate = _view.BirthDate;
            _tempIndividual.BirthPlace = _view.BirthPlace;
            _tempIndividual.Citizenship = _view.Citizenship;
            _tempIndividual.INN = _view.INN;
            _tempIndividual.Nationality = _view.Nationality;
            _tempIndividual.Note = _view.Note;
            _tempIndividual.InfoWork = _view.InfoWork;
            _tempIndividual.BloodGroup = _view.BloodGroup;
            _tempIndividual.Snils = _view.Snils;
            _tempIndividual.Med = _view.Med;
            _tempIndividual.IsDelete = _view.IsDelete;

            if ( _view.PartnerView.SelectedEntity != null )
                _tempIndividual.IdPartner = ( _view.PartnerView.SelectedEntity as Partner ).Id;

            if ( _view.SigningView.SelectedEntity != null )
                _tempIndividual.IdSigning = ( _view.SigningView.SelectedEntity as Signing ).Id;

            if ( _view.FlagView.SelectedEntity != null )
                _tempIndividual.IdFlag = ( _view.FlagView.SelectedEntity as Flag ).Id;

            if ( _view.AccessTypeView.SelectedEntity != null )
                _tempIndividual.IdAccessType = ( _view.AccessTypeView.SelectedEntity as AccessType ).Id;
        }

        private void SaveData ()
        {
            if ( _tempIndividual != null )
            {
                if ( _tempIndividual.IdFlag == 0 || _tempIndividual.IdSigning == 0 || _tempIndividual.IdAccessType == 0
                    || _tempIndividual.IdPartner == 0 || _tempIndividual.Alias == string.Empty || _tempIndividual.Name == string.Empty
                    || _tempIndividual.SecondName == string.Empty )
                {
                    System.Windows.Forms.MessageBox.Show ("Вы не заполнили обязательные поля! См. <*>");
                    return;
                }

                _service.AddOrUpdateEntity (_tempIndividual);
            }
        }

        private void DeleteData ()
        {
            if (_view.Individual != null)
                _service.RemoveEntity (_view.Individual);
        }
    }
}
