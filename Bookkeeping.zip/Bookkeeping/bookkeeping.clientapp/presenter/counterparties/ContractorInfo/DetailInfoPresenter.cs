﻿using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.View.Counterparties.MenuControls;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo
{
    public interface IDetailInfoView : Common.IViewControl
    {
        IAccountView AccountView { get; }
        AccountPresenter AccountPresenter { get; }

        IAddressView AddressView { get; }
        AddressPresenter AddressPresenter { get; }

        IContactView ContactView { get; }
        ContactPresenter ContactPresenter { get; }

        IDocumentView DocumentView { get; }
        DocumentPresenter DocumentPresenter { get; }

        SpecificationPresenter SpecificationPresenter { get; }
        GroupPresenter GroupPresenter { get; }

        ITemplateGridView<Account> AccountGridView { get; }
        ITemplateGridView<Address> AddressGridView { get; }
        ITemplateGridView<Contact> ContactGridView { get; }
        ITemplateGridView<Document> DocumentGridView { get; }
        ISpecificationView SpecificationView { get; }
        IGroupView GroupView { get; }

        AccountGridPresenter AccountGridPresenter { get; }
        AddressGridPresenter AddressGridPresenter { get; }
        ContactGridPresenter ContactGridPresenter { get; }
        DocumentGridPresenter DocumentGridPresenter { get; }
    }

    public class DetailInfoPresenter : Common.IPresenterControlInfo
    {
        IDetailInfoView _view;

        private Contractor _contractor;

        public DetailInfoPresenter (IDetailInfoView view)
        {
            _view = view;

            _view.AccountGridView.SelectedItem += () => SelectedAccount (_view.AccountGridView.SelectedEntity);
            _view.AddressGridView.SelectedItem += () => SelectedAddress (_view.AddressGridView.SelectedEntity);
            _view.ContactGridView.SelectedItem += () => SelectedContact (_view.ContactGridView.SelectedEntity);
            _view.DocumentGridView.SelectedItem += () => SelectedDocument (_view.DocumentGridView.SelectedEntity);

            _view.AccountView.InfoChange += () => AccountInfoChange ();
            _view.AddressView.InfoChange += () => AddressInfoChange ();
            _view.ContactView.InfoChange += () => ContactInfoChange ();
            _view.DocumentView.InfoChange += () => DocumentInfoChange ();
        }

        #region Implementation IPresenterControlInfo

        public void Init ()
        {
            _view.AccountGridPresenter.Init ();
            _view.AddressGridPresenter.Init ();
            _view.ContactGridPresenter.Init ();
            _view.DocumentGridPresenter.Init ();

            _view.AccountPresenter.Init ();
            _view.AddressPresenter.Init ();
            _view.ContactPresenter.Init ();
            _view.DocumentPresenter.Init ();
            _view.SpecificationPresenter.Init ();
            _view.GroupPresenter.Init ();
        }

        public void Refresh (Partner partner)
        {
            if ( partner.Id == 0 )
                return;
            _contractor = new Contractor (partner);

            _view.AccountGridPresenter.Refresh (partner);
            _view.AddressGridPresenter.Refresh (partner);
            _view.ContactGridPresenter.Refresh (partner);
            _view.DocumentGridPresenter.Refresh (partner);
            _view.SpecificationPresenter.Refresh (partner);
            _view.GroupPresenter.Refresh (partner);
        }

        public void Refresh (Individual individual)
        {
            if ( individual.Id == 0 )
                return;
            _contractor = new Contractor (individual);

            _view.AccountGridPresenter.Refresh (individual);
            _view.AddressGridPresenter.Refresh (individual);
            _view.ContactGridPresenter.Refresh (individual);
            _view.DocumentGridPresenter.Refresh (individual);
            _view.SpecificationPresenter.Refresh (individual); 
            _view.GroupPresenter.Refresh (individual);
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            if ( entrepreneur.Id == 0 )
                return;
            _contractor = new Contractor (entrepreneur);

            _view.AccountGridPresenter.Refresh (entrepreneur);
            _view.AddressGridPresenter.Refresh (entrepreneur);
            _view.ContactGridPresenter.Refresh (entrepreneur);
            _view.DocumentGridPresenter.Refresh (entrepreneur);
            _view.SpecificationPresenter.Refresh (entrepreneur);
            _view.GroupPresenter.Refresh (entrepreneur);
        }

        #endregion

        private void SelectedAccount (Account account)
        {
            if ( account == null )
                return;

            _view.AccountPresenter.Refresh (account);
        }

        private void SelectedAddress (Address address)
        {
            if ( address == null )
                return;

            _view.AddressPresenter.Refresh (address);
        }

        private void SelectedContact (Contact contact)
        {
            if ( contact == null )
                return;

            _view.ContactPresenter.Refresh (contact);
        }

        private void SelectedDocument (Document document)
        {
            if ( document == null )
                return;

            _view.DocumentPresenter.Refresh (document);
        }


        private void AddressInfoChange ()
        {
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                _view.AddressGridPresenter.Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                _view.AddressGridPresenter.Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                _view.AddressGridPresenter.Refresh ((Entrepreneur) _contractor);
        }

        private void AccountInfoChange ()
        {
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                _view.AccountGridPresenter.Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                _view.AccountGridPresenter.Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                _view.AccountGridPresenter.Refresh ((Entrepreneur) _contractor);
        }

        private void ContactInfoChange ()
        {
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                _view.ContactGridPresenter.Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                _view.ContactGridPresenter.Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                _view.ContactGridPresenter.Refresh ((Entrepreneur) _contractor);
        }

        private void DocumentInfoChange ()
        {
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                _view.DocumentGridPresenter.Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                _view.DocumentGridPresenter.Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                _view.DocumentGridPresenter.Refresh ((Entrepreneur) _contractor);
        }
    }
}
