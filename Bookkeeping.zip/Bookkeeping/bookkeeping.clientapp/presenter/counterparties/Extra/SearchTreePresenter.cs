﻿using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator;
using Bookkeeping.ClientApp.Model.DatabaseReflection;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface ISearchTreeView : Common.IViewTreeControl
    {
        QueryManager PartnerQuery { get; set; }
        QueryManager EntrepreneurQuery { get; set; }
        QueryManager IndividualQuery { get; set; }
    }

    public class SearchTreePresenter : Common.IPresenterControl
    {
        private ISearchTreeView _view;
        private SearchReflectionService _service;

        public SearchTreePresenter (ISearchTreeView view, SearchReflectionService service)
        {
            _view = view;
            _service = service;

            IBehaviorGeneration searchQueryBehavior = new SearchGenerate (":p0");
            _view.PartnerQuery = new QueryManager (searchQueryBehavior);
            _view.EntrepreneurQuery = new QueryManager (searchQueryBehavior);
            _view.IndividualQuery = new QueryManager (searchQueryBehavior);

            _view.CheckedTreeItem += () => Check ();
        }

        public void Init ()
        {
        }

        /// <summary>
        /// TODO: Ссылки
        /// </summary>
        public void Refresh ()
        {
            #region Заполнение как в фильтрах
           /* ElementNode[] arraySearchTable = GetInitSearchNode ();
            var partnerNode = ( arraySearchTable[0].ReadebleName == "Partners" ) ? arraySearchTable[0] : ( arraySearchTable[1].ReadebleName == "Partners" ) ? arraySearchTable[1] : arraySearchTable[2];
            var individualNode = ( arraySearchTable[0].ReadebleName == "Individuals" ) ? arraySearchTable[0] : ( arraySearchTable[1].ReadebleName == "Individuals" ) ? arraySearchTable[1] : arraySearchTable[2];
            var entrepreneurNode = ( arraySearchTable[0].ReadebleName == "Entrepreneurs" ) ? arraySearchTable[0] : ( arraySearchTable[1].ReadebleName == "Entrepreneurs" ) ? arraySearchTable[1] : arraySearchTable[2];

            var general = new SearchNode (partnerNode, individualNode, entrepreneurNode);
            var partner = new SearchNode (partnerNode);
            var individual = new SearchNode (individualNode);
            var entrepreneur = new SearchNode (entrepreneurNode);

            foreach ( var firstTable in _service.GetElementNodesFromElementNode (partnerNode) )
                foreach ( var secondTable in _service.GetElementNodesFromElementNode (individualNode) )
                    if ( firstTable.ReadebleName.Equals (secondTable.ReadebleName) )
                    {
                        foreach ( var threeTable in _service.GetElementNodesFromElementNode (entrepreneurNode) )
                            if ( secondTable.ReadebleName.Equals (threeTable.ReadebleName) )
                                general.Nodes.Add (FillSearchNodes (firstTable));
                    }

            partner = FillTableNodeFromTreeNode (general, partnerNode, partner);
            individual = FillTableNodeFromTreeNode (general, individualNode, individual);
            entrepreneur = FillTableNodeFromTreeNode (general, entrepreneurNode, entrepreneur);

            _view.Nodes.Add (general);
            _view.Nodes.Add (partner);
            _view.Nodes.Add (individual);
            _view.Nodes.Add (entrepreneur);
            */
            #endregion
            //SearchNode general = new SearchNode ();
            //general.Text = "Общий";

            foreach ( var parent in _service.GetInitialDataTables () )
            {
                SearchNode parentNode = new SearchNode (parent);
                parentNode.Query = new QueryNodeString (parent);
                foreach ( var table in _service.GetElementNodesFromElementNode (parent) )
                {
                    SearchNode tableNode = new SearchNode (table);
                    tableNode.Query = new QueryNodeString (parent, tableNode.Element);
                    if (table.ReadebleAssociationName != null && table.TypeProperty == TypeProperty.TableProperty )
                    {
                        foreach ( var column in _service.GetElementNodesFromElementNode (table) )
                            if ( column.TypeProperty == TypeProperty.ColumnProperty )
                                tableNode.Nodes.Add (new SearchNode (column) { Query = new QueryNodeString (table, column) });
                        parentNode.Nodes.Add (tableNode);
                    }
                    else parentNode.Nodes.Add (tableNode);
                }
                _view.Nodes.Add (parentNode);
            }
        }

        #region Заполнение как в фильтрации
        private ElementNode[] GetInitSearchNode ()
        {
            ElementNode[] arraySearchTable = new ElementNode[3];
            var initTables = _service.GetInitialDataTables ();
            for ( int i = 0; i < initTables.Count; i++ )
            {
                arraySearchTable[i] = initTables.ElementAt (i);
            }
            return arraySearchTable;
        }

        private SearchNode FillTableNodeFromTreeNode (SearchNode general, ElementNode node, SearchNode treeNode)
        {
            foreach ( var table in _service.GetElementNodesFromElementNode (node) )
            {
                var type = ( table.TypeProperty == TypeProperty.TableProperty ) ? "Table" : "Column";
                if ( general.Nodes.Find (table.ReadebleName + type, true).Length == 0 )
                    treeNode.Nodes.Add (FillSearchNodes (table));
            }
            return treeNode;
        }

        private SearchNode FillSearchNodes (ElementNode node)
        {
            SearchNode filterNode = new SearchNode (node);
            if ( _service.GetElementNodesFromElementNode (node) != null )
            {
                foreach ( var item in _service.GetElementNodesFromElementNode (node) )
                {
                    if ( item.TypeProperty == TypeProperty.ColumnProperty )
                        filterNode.Nodes.Add (new SearchNode (new QueryNodeString (node, item)));
                    else filterNode.Nodes.Add (FillSearchNodes (item));
                }
            }
            return filterNode;
        }
        #endregion

        private void Check ()
        {
            _view.PartnerQuery.ClearNodes ();
            _view.IndividualQuery.ClearNodes ();
            _view.EntrepreneurQuery.ClearNodes ();

            _view.PartnerQuery.ClearValues ();
            _view.IndividualQuery.ClearValues ();
            _view.EntrepreneurQuery.ClearValues ();

            foreach ( SearchNode parent in _view.Nodes )
            {
                if ( parent.Element.ReadebleName == "Partners" )
                    ComposeQuery (_view.PartnerQuery, parent);
                else if ( parent.Element.ReadebleName == "Individuals" )
                    ComposeQuery (_view.IndividualQuery, parent);
                else if ( parent.Element.ReadebleName == "Entrepreneurs" )
                    ComposeQuery (_view.EntrepreneurQuery, parent);
            }
        }

        private void ComposeQuery (QueryManager manager, SearchNode child)
        {
            manager.AddNode (child.Query);

            foreach ( SearchNode table in child.Nodes )
                if ( table.Checked == true )
                {
                    manager.AddNode (table.Query);
                    foreach ( SearchNode column in table.Nodes )
                        if ( column.Checked == true )
                            manager.AddNode (column.Query);
                }
        }
    }
}
