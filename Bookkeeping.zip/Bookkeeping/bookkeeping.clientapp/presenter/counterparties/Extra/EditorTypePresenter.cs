﻿using Bookkeeping.ClientApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface ITypeView : Common.IViewEditControl
    {
        Common.IPresenter Presenter { get; set; }

        object TypeEntity { get; set; }

        string TypeName { get; set; }

        event EventHandler PropertyChanged;
    }

    public class TypePresenter<TEntity> : Common.IPresenterControl<TEntity>
        where TEntity :  class, Data.IEntity
    {
        ITypeView _view;
        ServiceModel<TEntity> _service;

        private Data.Interface.ITypeEntity _tempEntity;

        public TypePresenter (ITypeView view, ServiceModel<TEntity> service)
        {
            _view = view;
            _service = service;

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();

            _view.SaveData += () => SaveData ();
            _view.DeleteData += () => DeleteData ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (TEntity entity)
        {
            Data.Interface.ITypeEntity type = entity as Data.Interface.ITypeEntity;
            _tempEntity = type;
            _view.TypeEntity = type;

            _view.TypeName = type.TypeName;
        }

        private void OnPropertyChanged ()
        {
            _tempEntity.TypeName = _view.TypeName;
        }

        private void SaveData ()
        {
            _view.TypeEntity = _service.AddOrUpdateEntity (_tempEntity as TEntity);
        }

        private void DeleteData ()
        {
            _service.RemoveEntity (_view.TypeEntity as TEntity);
        }
    }
}
