﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IExtraTypeView : Common.IViewEditControl
    {
        Common.IPresenter Presenter { get; set; }
        object ExtraType { get; set; }

        string TypeName { get; set; }
        string ExtraTypeName { get; set; }
        Color TypeColor { get; set; }
        Image TypeImage { get; set; }
        FontStyle FontStyleType { get; set; }

        event EventHandler PropertyChanged;

        event Action GetImage;
        event Action GetColor;
    }

    public class ExtraTypePresenter<TEntity> : Common.IPresenterControl<TEntity>
        where TEntity : class, Data.IEntity
    {
        private IExtraTypeView _view;
        private ServiceModel<TEntity> _service;

        Data.Interface.IExtraType _tempEntity;

        public ExtraTypePresenter (IExtraTypeView view, ServiceModel<TEntity> service)
        {
            _view = view;
            _service = service;

            _view.SaveData += () => SaveData ();
            _view.DeleteData += () => DeleteData ();
            _view.GetImage += () => SetImage ();
            _view.GetColor += () => SetColor ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (TEntity entity)
        {
            Data.Interface.IExtraType extra = entity as Data.Interface.IExtraType;
            _tempEntity = extra;
            _view.ExtraType = extra;

            if (typeof (TEntity) == typeof (Flag))
                _view.TypeName = ((Flag) extra).Name;
            _view.ExtraTypeName = extra.TypeName;

            if ( extra.TypeImage != null )
                _view.TypeImage = GetImageFromByte (extra.TypeImage);
            if (extra.TypeColor != null)
                _view.TypeColor = (Color) Enum.Parse (typeof (Color), extra.TypeColor);
            if (extra.FontStyle != null)
                _view.FontStyleType = (FontStyle) Enum.Parse (typeof (FontStyle), extra.FontStyle);
        }

        private void OnPropertyChanged ()
        {
            if (typeof (TEntity) == typeof (Flag))
                ((Flag)_tempEntity).Name = _view.TypeName;
            _tempEntity.TypeName = _view.ExtraTypeName;

            if (_view.TypeImage != null)
                _tempEntity.TypeImage = GetByteImage (_view.TypeImage);
            if (_view.TypeColor != null)
                _tempEntity.TypeColor = _view.TypeColor.Name;
            if (_view.FontStyleType.ToString() != null)
                _tempEntity.FontStyle = _view.FontStyleType.ToString();
        }

        private byte[] GetByteImage (Image image)
        {
            using ( var stream = new System.IO.MemoryStream () )
            {
                image.Save (stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                return stream.ToArray ();
            }
        }

        private Image GetImageFromByte (byte[] bytes)
        {
            using (var stream = new System.IO.MemoryStream (bytes))
            {
                return Image.FromStream (stream);
            }
        }

        private void SetImage ()
        {
            var fileDialog = new OpenFileDialog ();
            fileDialog.Title = "Выберите изображение";
            fileDialog.Filter = "Изображения JPEG|*.jpg; *.jpeg|Изображения PNG|*.png|All files (*.*)|*.*";

            if ( fileDialog.ShowDialog () == DialogResult.OK )
            {
                _view.TypeImage = Image.FromFile (fileDialog.FileName);
                OnPropertyChanged ();
            }
        }

        private void SetColor ()
        {
            var color = new ColorDialog ();
            color.AllowFullOpen = false;
            color.ShowHelp = true;

            if ( color.ShowDialog () == DialogResult.OK )
            {
                _view.TypeColor = color.Color;
                OnPropertyChanged ();
            }
        }

        private void SaveData ()
        {
            _view.ExtraType = _service.AddOrUpdateEntity (_tempEntity as TEntity);
        }

        private void DeleteData ()
        {
            _service.RemoveEntity (_view.ExtraType as TEntity);
        }
    }
}
