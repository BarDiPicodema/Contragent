﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.View.ClientWindow;
using Bookkeeping.ClientApp.View.Common;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using Bookkeeping.Data;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IEntityControlView : Common.IViewControl
    {
        object DataSource { get; set; }
        string DisplayProperty { get; set; }
        object SelectedEntity { get; set; }

        event EventHandler SelectedEntityChanged;
        event Action AddEntity;
        event Action EditEntity;
    }

    public class EntityPresenter<TEntity> : Common.IPresenterBoxControl<TEntity> where TEntity : class, IEntity, new()
    {
        private IEntityControlView _view;
        private IService<TEntity> _service;

        public EntityPresenter (IEntityControlView view, IService<TEntity> service)
        {
            _view = view;
            _service = service;

            _view.AddEntity += () => AddEntity ();
            _view.EditEntity += () => EditEntity ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (TEntity entity)
        {
            var allEntities = _service.GetAll ();
            if ( typeof (TEntity) == typeof (Partner) )
                _view.DataSource = allEntities.OrderBy (i => ( i as Partner ).Alias).ToList ();
            else _view.DataSource = allEntities.ToList ();
            
            if (entity != null && allEntities.Any (item => item.Id == entity.Id) )
            {
                _view.SelectedEntity = entity;
            }
        }

        private void AddEntity ()
        {
            DialogPresenter dialog = null;

            if ( typeof (TEntity).GetInterfaces ().Where (item => item.Equals (typeof (Data.Interface.IExtraType))).Any())
            {
                var extra = new ExtraTypeEditControl ();
                var presenter = new ExtraTypePresenter<TEntity> (extra, new ServiceModel<TEntity> ());
                extra.Presenter = presenter;
                extra.Presenter.Init ();
                presenter.Refresh (new TEntity ());

                //( extra.Presenter as ExtraTypePresenter<TEntity> ).Refresh (new TEntity ());
                dialog = new DialogPresenter (extra, new DialogWindow ());
            }
            else if ( typeof (TEntity).GetInterfaces ().Where (item => item.Equals (typeof (Data.Interface.ITypeEntity))).Any())
            {
                var type = new TypeCreatorControl ();
                var presenter = new TypePresenter<TEntity> (type, new ServiceModel<TEntity> ());
                type.Presenter = presenter;
                type.Presenter.Init ();
                presenter.Refresh (new TEntity ());

                //( type.Presenter as TypePresenter<TEntity> ).Refresh (new TEntity ());
                dialog = new DialogPresenter (type, new DialogWindow ());
            }
            else return;

            dialog.Run ();
            Refresh (null);
        }

        private void EditEntity ()
        {
            DialogPresenter dialog = null;

            if ( typeof (TEntity).GetInterfaces ().Where (item => item.Equals (typeof (Data.Interface.IExtraType))).Any () )
            {
                var extra = new ExtraTypeEditControl ();
                var presenter = new ExtraTypePresenter<TEntity> (extra, new ServiceModel<TEntity> ());
                extra.Presenter = presenter;
                extra.Presenter.Init ();
                presenter.Refresh (_view.SelectedEntity as TEntity);
                
                //( extra.Presenter as ExtraTypePresenter<TEntity> ).Refresh (_view.SelectedEntity as TEntity);
                dialog = new DialogPresenter (extra, new DialogWindow ());
            }
            else if ( typeof (TEntity).GetInterfaces ().Where (item => item.Equals (typeof (Data.Interface.ITypeEntity))).Any () )
            {
                var type = new TypeCreatorControl ();
                var presenter = new TypePresenter<TEntity> (type, new ServiceModel<TEntity> ());
                type.Presenter = presenter;
                type.Presenter.Init ();
                presenter.Refresh (_view.SelectedEntity as TEntity);
                
                //( type.Presenter as TypePresenter<TEntity> ).Refresh (_view.SelectedEntity as TEntity);
                dialog = new DialogPresenter (type, new DialogWindow ());
            }
            else return;

            dialog.Run ();
        }
    }
}
