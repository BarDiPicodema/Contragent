﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IFilterView : Common.IViewTreeControl
    {
        List<AbstractFilter<Partner>> SelectedPartnerFilter { get; }
        List<AbstractFilter<Individual>> SelectedIndividualFilter { get; }
        List<AbstractFilter<Entrepreneur>> SelectedEntrepreneurFilter { get; }
    }

    public class FilterPresenter : Common.IPresenterControl
    {
        private IFilterView _view;
        private FilterModel _service;

        public FilterPresenter (IFilterView view, FilterModel service)
        {
            _view = view;
            _service = service;
        }

        public void Init ()
        {
            _service.LoadProgramFilters ();
            _service.LoadDatabaseFilters ();
        }

        public void Refresh ()
        {
            var generalNode = new TreeNode ("Общие");
            foreach ( AbstractFilter<Partner> partFilter in _service.PartnerFilters )
                foreach ( AbstractFilter<Individual> indiFilter in _service.IndividualFilters )
                    foreach ( AbstractFilter<Entrepreneur> entrFilter in _service.EntrepreneurFilters )
                        if ( partFilter.Name == indiFilter.Name && indiFilter.Name == entrFilter.Name )
                        {
                            var parentNode = new FilterNode (partFilter, indiFilter, entrFilter);
                            generalNode.Nodes.Add (parentNode);
                        }

            var partnerNodes = new TreeNode ("Партнеры");
            foreach ( AbstractFilter<Partner> filter in _service.PartnerFilters )
                if ( !generalNode.Nodes.Cast<TreeNode>().Where (item => item.Text == filter.Name).Any() )
                    partnerNodes.Nodes.Add (new FilterNode (filter));

            var individualNodes = new TreeNode ("Физлица");
            foreach ( AbstractFilter<Individual> filter in _service.IndividualFilters )
                if ( !generalNode.Nodes.Cast<TreeNode>().Where (item => item.Text == filter.Name).Any() )
                    individualNodes.Nodes.Add (new FilterNode (filter));

            var entrepreneurNodes = new TreeNode ("Юрлица");
            foreach ( AbstractFilter<Entrepreneur> filter in _service.EntrepreneurFilters )
                if ( !generalNode.Nodes.Cast<TreeNode> ().Where (item => item.Text == filter.Name).Any () )
                    entrepreneurNodes.Nodes.Add (new FilterNode (filter));

            _view.Nodes.Add (generalNode);
            _view.Nodes.Add (partnerNodes);
            _view.Nodes.Add (individualNodes);
            _view.Nodes.Add (entrepreneurNodes);
        }
    }
}
