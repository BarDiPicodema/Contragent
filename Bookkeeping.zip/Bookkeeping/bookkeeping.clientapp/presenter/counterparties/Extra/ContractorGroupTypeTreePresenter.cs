﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IContractorGroupTypeTreeView : Common.IViewTreeControl
    {
        event Action RemoveGroupType;
    }

    /// <summary>
    /// TODO : GroupTypeOne = groupType.id+1
    /// TODO : Group find elements = null --------- error
    /// </summary>
    public class ContractorGroupTypeTreePresenter : Common.IPresenterControlInfo
    {
        private IContractorGroupTypeTreeView _view;
        private ServiceModel<Group> _service;
        private ServiceModel<GroupTypeToType> _serviceGroupTypeToType;
        
        public ContractorGroupTypeTreePresenter (IContractorGroupTypeTreeView view, ServiceModel<Group> service, ServiceModel<GroupTypeToType> serviceGroupType)
        {
            _view = view;
            _service = service;
            _serviceGroupTypeToType = serviceGroupType;
        }

        private Contractor _contractor;
        ModelClient _model;

        public void Init ()
        {
            _model = ModelClient.Instance;

            _service.Init ();
            _serviceGroupTypeToType.Init ();
        }

        public void Refresh (Partner partner)
        {
            if ( partner == null || partner.Id == 0)
                return;

            _contractor = new Contractor (partner);
            _view.Nodes.Clear ();

            if ( _service.GetEntities (item => item.IdPartner == partner.Id != null) != null )
                foreach ( var group in _service.GetEntities (item => item.IdPartner == partner.Id) )
                    _view.Nodes.Add (AddContractorGroupType (_serviceGroupTypeToType.FindEntity (item => item.Id == group.IdGroupTypeToType)));
        }

        public void Refresh (Individual individual)
        {
            if ( individual == null || individual.Id == 0)
                return;

            _contractor = new Contractor (individual);
            _view.Nodes.Clear ();

            if ( _service.GetEntities (item => item.IdIndividual == individual.Id) != null)
                foreach ( var group in _service.GetEntities (item => item.IdIndividual == individual.Id) )
                    _view.Nodes.Add (AddContractorGroupType (_serviceGroupTypeToType.FindEntity (item => item.Id == group.IdGroupTypeToType)));
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            if ( entrepreneur == null || entrepreneur.Id == 0)
                return;

            _contractor = new Contractor (entrepreneur);
            _view.Nodes.Clear ();

            if ( _service.GetEntities (item => item.IdEntrepreneur == entrepreneur.Id) != null)
                foreach ( var group in _service.GetEntities (item => item.IdEntrepreneur == entrepreneur.Id) )
                    _view.Nodes.Add (AddContractorGroupType (_serviceGroupTypeToType.FindEntity (item => item.Id == group.IdGroupTypeToType)));
        }

        private void Refresh ()
        {
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) _contractor);
        }

        private GroupNode AddContractorGroupType (GroupTypeToType groupType)
        {
            if ( groupType == null )
                return null;

            GroupNode node = new GroupNode (groupType.GroupTypeTwo);

            var group = _serviceGroupTypeToType.FindEntity (item => item.IdGroupTypeTwo == groupType.IdGroupTypeOne);
            if ( group != null )
            {
                if ( _view.Nodes.Find (group.IdGroupTypeOne.ToString (), true).Length > 0 )
                    return _view.Nodes.Find (group.IdGroupTypeOne.ToString (), true)[0] as GroupNode;

                var parent = AddContractorGroupType (group);
                parent.Nodes.Add (node);
                return parent;
            }
            else
            {
                var type = _model.Service.GroupTypes.Find (item => item.Id == groupType.IdGroupTypeOne);
                GroupNode parent = null;

                if ( _view.Nodes.Find (type.TypeName, true).Length > 0 )
                    parent = _view.Nodes.Find (parent.Name, true)[0] as GroupNode;
                else
                {
                    parent = new GroupNode (type);
                    parent.Nodes.Add (node);
                }

                return parent;
            }

            return node;
        }

        private GroupNode CreateStackContractorGroupType (GroupTypeToType groupType)
        {
            GroupNode node = new GroupNode (groupType.GroupTypeTwo);

            var group = _serviceGroupTypeToType.FindEntity (item => item.IdGroupTypeTwo == groupType.IdGroupTypeOne);
            if ( group != null )
            {
                var parent = AddContractorGroupType (group);
                parent.Nodes.Add (node);
                return parent;
            }
            else
            {
                var type = _model.Service.GroupTypes.Find (item => item.Id == groupType.IdGroupTypeOne);
                GroupNode parent = null;

                if ( _view.Nodes.Find (type.TypeName, true).Length > 0 )
                    parent = _view.Nodes.Find (parent.Name, true)[0] as GroupNode;
                else
                {
                    parent = new GroupNode (type);
                    parent.Nodes.Add (node);
                }

                return parent;
            }

            return node;
        }

        Stack<GroupNode> stackNodes = new Stack <GroupNode>();

        private void AddNodeToStack (GroupType type)
        {
            GroupNode node = new GroupNode (type);
            stackNodes.Push (node);
        }
    }
}
