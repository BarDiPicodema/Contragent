﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.View.Counterparties.TableControls;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IClassificatorView : Common.IViewControl
    {
        object Classificator { get; set; }
        string ClassificatorCode { get; set; }

        event Action OpenClassificator;
    }

    public class ClassificatorPresenter<TEntity> : Common.IPresenterControl<TEntity>
        where TEntity : class, Data.Interface.IClassifier, new()
    {
        IClassificatorView _view;
        ServiceModel<TEntity> _service;

        private TEntity _tempEntity;

        public ClassificatorPresenter (IClassificatorView view, ServiceModel<TEntity> service)
        {
            _view = view;
            _service = service;

            _view.OpenClassificator += () => SearchClassificator ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (TEntity entity)
        {
            if ( entity == null )
                return;

            _tempEntity = entity;

            _view.ClassificatorCode = entity.NumberCode.ToString ();
            _view.Classificator = entity;
        }

        private void SearchClassificator ()
        {
            var view = new ClassificatorTable ();
            var presenter = new ClassificatorGridPresenter<TEntity> (view, new ServiceModel<TEntity> ());
            view.Presenter = presenter;
            view.Presenter.Init ();
            TEntity classificator = new TEntity ();
            presenter.Refresh (classificator);

            var dialog = new DialogPresenter (view, new View.ClientWindow.DialogWindow ());
            dialog.Run ();

            if (view.SelectedClassificator != null)
            {
                var id = ( view.SelectedClassificator as DataRowView ).Row.Field<decimal> ("Id");
                _view.Classificator = _service.FindEntity (item => item.Id == id);
                _view.ClassificatorCode = ( _view.Classificator as TEntity).NumberCode;
            }
        }
    }
}
