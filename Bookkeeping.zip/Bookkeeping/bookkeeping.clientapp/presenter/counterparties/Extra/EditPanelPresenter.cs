﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IEditPanelPresenter
    {
        Menu.IEditorToolView EditToolView { get; }
        Menu.EditorToolPresenter EditToolPresenter { get; }
        
        View.Common.CUIControl Control;

        object Entity { get; set; }
    }

    public class EditPanelPresenter<TEntity, TArgs> : Common.IPresenterControl<TArgs>
    {
        public IEditPanelPresenter _view;
        private ServiceModel<TEntity>
    }
}
