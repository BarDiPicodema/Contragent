﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.Data;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface ISearchParticipantView : Common.IViewControl
    {
        string FindValue { get; }
        System.Windows.Forms.BindingSource Source { get; set; }
        string Type { get; }
        object DataSourceType { get; set; }
        object SelectedContractor { get; }

        event Action SearchRun;
        event Action SelectedType;
        event Action Save;
    }

    public class SearchParticipantPresenter : Common.IPresenterControl<DocumentParticipant>
    {
        private ISearchParticipantView _view;
        private ServiceModel<DocumentParticipant> _service;
        private AccessServiceModel<Partner> _partnerService;
        private ClientServiceModel _clientService;
        
        private Dictionary<string, ContractorTypes> _types;
        private DocumentParticipant _document;

        public SearchParticipantPresenter (ISearchParticipantView view, ServiceModel<DocumentParticipant> service, AccessServiceModel<Partner> partnerService, ClientServiceModel clientService)
        {
            _view = view;
            _service = service;
            _partnerService = partnerService;
            _clientService = clientService;

            _view.SearchRun += () => SearchData (_view.FindValue);
            _view.SelectedType += () => SelectedContractorType (_view.Type);
            _view.Save += () => SaveParticipant (_view.SelectedContractor);

            _types = new Dictionary<string, ContractorTypes> ();
        }

        public void Init ()
        {
            _service.Init ();

            _partnerService.Init ();
            _clientService.Init ();
        }

        public void Refresh (DocumentParticipant document)
        {
            if (document == null)
                throw new ArgumentNullException ();

            _document = document;
            _types.Clear ();

            var types = Enum.GetValues (typeof (ContractorTypes));
            foreach ( var item in types )
            {
                var field = typeof (ContractorTypes).GetField (item.ToString ());
                DisplayAttribute attribute = Attribute.GetCustomAttribute (field, typeof (DisplayAttribute)) as DisplayAttribute;
                _types.Add (attribute.Name, (ContractorTypes) item);
            }

            _view.DataSourceType = _types.Keys.ToList ();
        }

        private void SelectedContractorType (string type)
        {
            BindingSource source = new BindingSource ();
            
            if ( _types[type] == ContractorTypes.Partner )
                source.DataSource = ConvertToDataTable<Partner> (_partnerService.GetAll ());
            else if ( _types[type] == ContractorTypes.Individual )
                source.DataSource = ConvertToDataTable<Individual> (_clientService.GetIndividuals ());
            else if ( _types[type] == ContractorTypes.Entrepreneur )
                source.DataSource = ConvertToDataTable<Entrepreneur> (_clientService.GetEntrepreneurs ());

            _view.Source = source;
        }

        private DataTable ConvertToDataTable<T> (IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties (typeof (T));
            DataTable table = new DataTable ();
            foreach ( PropertyDescriptor prop in properties )
                table.Columns.Add (prop.Name, Nullable.GetUnderlyingType (prop.PropertyType) ?? prop.PropertyType);
            foreach ( T item in data )
            {
                DataRow row = table.NewRow ();
                foreach ( PropertyDescriptor prop in properties )
                    row[prop.Name] = prop.GetValue (item) ?? DBNull.Value;
                table.Rows.Add (row);
            }
            return table;
        }

        private void SearchData (string template)
        {
            if ( template == string.Empty )
            {
                SelectedContractorType (_view.Type);
                return;
            }

            string filter = string.Empty;
            filter += string.Format (" CONVERT(Alias, 'System.String') LIKE '%{0}%' ", template);

            _view.Source.Filter = filter;
        }

        private void SaveParticipant (object selectedContractor)
        {
            if (selectedContractor == null)
            {
                System.Windows.Forms.MessageBox.Show ("Контрагент не выбран!");
                return;
            }

            var id = ( selectedContractor as DataRowView ).Row.Field<decimal> ("Id");

            if ( _types[_view.Type] == ContractorTypes.Partner )
            {
                _document.IdPartner = id;
                _service.AddOrUpdateEntity (_document);
            }
            else if ( _types[_view.Type] == ContractorTypes.Individual )
            {
                _document.IdIndividual = id;
                _service.AddOrUpdateEntity (_document);
            }
            else if ( _types[_view.Type] == ContractorTypes.Entrepreneur )
            {
                _document.IdEntrepreneur = id;
                _service.AddOrUpdateEntity (_document);
            }
        }
    }
}
