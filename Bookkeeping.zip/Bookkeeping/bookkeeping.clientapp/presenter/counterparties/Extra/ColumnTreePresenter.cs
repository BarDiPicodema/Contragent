﻿using Bookkeeping.ClientApp.Model.DatabaseReflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IColumnTreeView : Common.IViewTreeControl
    {

    }

    public class ColumnTreePresenter
    {
        private IColumnTreeView _view;
        private SearchReflectionService _service;

        public ColumnTreePresenter (IColumnTreeView view, SearchReflectionService service)
        {
            _view = view;
            _service = service;
        }
    }
}
