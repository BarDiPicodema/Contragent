﻿using Bookkeeping.ClientApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Extra
{
    public interface IEditPanelView
    {
        Menu.IEditorToolView EditorToolView { get; }
        View.Common.CUIControl Control { get; set; }

        event Action SaveData;
    }

    public class EditPanelPresenter<TEntity, TArgs> : Common.IPresenterControl<TArgs>
        where TEntity : class, Data.IEntity, new ()
       where TArgs : class, Data.IEntity
    {
        private IEditPanelView _view;
        private ServiceModel<TEntity> _service;

        public EditPanelPresenter (IEditPanelView view, ServiceModel<TEntity> service)
        {
            _view = view;
            _control = control;
        }

        public void Init ()
        {
        }

        public void Refresh (TArgs args)
        {

        }

        private void SaveData ()
        {
        }
    }
}
