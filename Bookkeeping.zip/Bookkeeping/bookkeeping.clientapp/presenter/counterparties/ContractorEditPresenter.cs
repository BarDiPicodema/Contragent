﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.View;
using Bookkeeping.ClientApp.View.Counterparties.ContactorInfo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;

namespace Bookkeeping.ClientApp.Presenter.Counterparties
{
    public interface IEditContractorView : Common.IViewChild
    {
        View.Common.CUIControl Control { get; set; }

        IContractorTreeView ContractorTreeView { get; }
        ContractorTreePresenter ContractorTreePresenter { get; }

        IEditorToolView EditorToolView { get; }

        DetailInfoPresenter DetailInfoPresenter { get; }
    }

    public class EditContractorPresenter : Common.BasePresenterChildrenWindow<IEditContractorView, Contractor>, Common.IPresenterControlInfo
    {
        Contractor _contractor;

        public EditContractorPresenter (IEditContractorView view) : base (view)
        {
            View.ContractorTreeView.ContractorView += () => Refresh (View.ContractorTreeView.CheckedItem as Partner);
            View.ContractorTreeView.ContractorView += () => Refresh (View.ContractorTreeView.CheckedItem as Individual);
            View.ContractorTreeView.ContractorView += () => Refresh (View.ContractorTreeView.CheckedItem as Entrepreneur);
        }

        public override void Run (Contractor contractor)
        {
            _contractor = contractor;
            Parent.ShowChildren (View);

            View.DetailInfoPresenter.Init ();
            View.ContractorTreePresenter.Init ();

            if ( contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) contractor);
            else if ( contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) contractor);
            else if ( contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) contractor);
        }

        public void Refresh (Partner partner)
        {
            if ( partner == null ) return;
            
            View.ContractorTreePresenter.Refresh (partner);
            var control = new PartnerControl ();
            
            control.EditorToolView = View.EditorToolView;

            control.Presenter.Init ();
            ( (PartnerPresenter) control.Presenter ).Refresh (partner);

            View.Control = control;
            View.DetailInfoPresenter.Refresh (partner);
        }

        public void Refresh (Individual individual)
        {
            if ( individual == null ) return;

            View.ContractorTreePresenter.Refresh (individual);
            var control = new IndividualControl ();
            control.EditorToolView = View.EditorToolView;

            control.Presenter.Init ();
            ( (IndividualPresenter) control.Presenter ).Refresh (individual);

            View.Control = control;
            View.DetailInfoPresenter.Refresh (individual);
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            if ( entrepreneur == null ) return;

            View.ContractorTreePresenter.Refresh (entrepreneur);
            var control = new EntrepreneurControl ();
            control.EditorToolView = View.EditorToolView;

            control.Presenter.Init ();
            ( (EntrepreneurPresenter) control.Presenter ).Refresh (entrepreneur);

            View.Control = control;
            View.DetailInfoPresenter.Refresh (entrepreneur);
        }
    }
}
