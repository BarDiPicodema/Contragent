﻿using Bookkeeping.ClientApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public interface IClassificatorGridView : Common.IViewTableControl
    {
        Form Parent { get; }

        string Filter { get; set; }
        string Column { get; }

        object SelectedClassificator { get; }

        List<string> ColumnNames { get; set; }

        System.Windows.Forms.BindingSource Source { get; set; }

        event Action Search;
    }

    public class ClassificatorGridPresenter<TEntity> : Common.IPresenterControl<TEntity>
        where TEntity : class, Data.Interface.IClassifier
    {
        private IClassificatorGridView _view;
        private ServiceModel<TEntity> _service;

        TEntity _classificator;

        public ClassificatorGridPresenter (IClassificatorGridView view, ServiceModel<TEntity> service)
        {
            _view = view;
            _service = service;

            _view.ColumnNames = new List<string> ();

            _view.SelectedItem += () => SearchData (_view.Filter);
            _view.Search += () => SearchDataFromColumn (_view.Column);

            _view.AddItem += () => SelectAndSave ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (TEntity classificator)
        {
            if ( classificator == null )
                return;
            _classificator = classificator;

            BindingSource source = new BindingSource ();
            var data = _service.GetAll ();

            var table = ConvertToDataTable<TEntity> (data);
            source.DataSource = table;
            _view.Source = source;

            List<string> names = new List<string> ();
            foreach ( var item in typeof (TEntity).GetProperties () )
                names.Add (item.Name);
            _view.ColumnNames = names;
        }

        private DataTable ConvertToDataTable<T> (IList<T> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties (typeof (T));
            DataTable table = new DataTable ();
            foreach ( PropertyDescriptor prop in properties )
                table.Columns.Add (prop.Name, Nullable.GetUnderlyingType (prop.PropertyType) ?? prop.PropertyType);
            foreach ( T item in data )
            {
                DataRow row = table.NewRow ();
                foreach ( PropertyDescriptor prop in properties )
                    row[prop.Name] = prop.GetValue (item) ?? DBNull.Value;
                table.Rows.Add (row);
            }
            return table;
        }

        private void SearchData (string template)
        {
            _view.Source.Filter = string.Format (" CONVERT({0}, 'System.String') LIKE '%{1}%' ", _view.Column, template);
        }

        private void SearchDataFromColumn (string column)
        {
            if ( column == "" )
                column = "NumberCode";
            _view.Source.Filter = string.Format (" CONVERT({0}, 'System.String') LIKE '%{1}%' ", _view.Column, _view.Filter);
        }

        private void SelectAndSave ()
        {
            _view.Parent.Close ();
        }
    }
}
