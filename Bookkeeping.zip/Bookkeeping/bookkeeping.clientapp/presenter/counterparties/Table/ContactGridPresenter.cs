﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Model.Util;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public class ContactGridPresenter : Common.IPresenterControlInfo
    {
        ITemplateGridView<Contact> _view;
        AccessServiceModel<Contact> _service;

        private Contractor _contractor;

        public ContactGridPresenter (ITemplateGridView<Contact> view, AccessServiceModel<Contact> service)
        {
            _view = view;
            _service = service;

            _view.AddItem += () => AddContact ();
            _view.EditItem += () => EditContact (_view.SelectedEntity);

        }

        public void Refresh (Partner partner)
        {
            _contractor = new Contractor (partner);
            var entities = new List<ContactRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdPartner == partner.Id))
                entities.Add (new ContactRow (item));

            _view.DataSource = entities;
        }

        public void Refresh (Individual individual)
        {
            _contractor = new Contractor (individual);
            var entities = new List<ContactRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdIndividual == individual.Id))
                entities.Add (new ContactRow (item));

            _view.DataSource = entities;
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            _contractor = new Contractor (entrepreneur); 
            var entities = new List<ContactRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdEntrepreneur == entrepreneur.Id) )
                entities.Add (new ContactRow (item));

            _view.DataSource = entities;
        }

        public void Init ()
        {
            _service.Init ();
        }

        private void Refresh ()
        {
            if ( _contractor == null )
                return;

            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) _contractor);
        }

        private void EditContact (Contact contact)
        {
            if ( contact == null )
                return;

            var control = new View.Counterparties.InfoControls.ContactControl ();
            var presenter = new DialogInfoPresenter<Contact> (control, new View.ClientWindow.DialogWindow ());
            presenter.Run (contact);
        }

        private void AddContact ()
        {
            if ( _contractor == null )
            {
                System.Windows.Forms.MessageBox.Show ("Вы не выбрали контрагента");
                return;
            }

            var contact = new Contact ();
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
            {
                contact.IdPartner = ( (Partner) _contractor ).Id;
            }
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
            {
                contact.IdIndividual = ( (Individual) _contractor ).Id;
            }
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
            {
                contact.IdEntrepreneur = ( (Entrepreneur) _contractor ).Id;
            }

            var control = new View.Counterparties.InfoControls.ContactControl ();
            var controlPresenter = ( (ContactPresenter) control.Presenter );
            controlPresenter.Init ();
            controlPresenter.Refresh (contact);

            var presenter = new DialogPresenter (control, new View.ClientWindow.DialogWindow ());
            presenter.Run ();

            Refresh ();
        }
    }
}
