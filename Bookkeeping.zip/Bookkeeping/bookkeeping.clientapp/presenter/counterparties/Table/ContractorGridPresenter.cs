﻿using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.View.Counterparties;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public class ContractorGridPresenter : Common.IPresenterControl<Partner>
    {
        ITemplateGridView<Contractor> _view;
        ClientServiceModel _service;

        public ContractorGridPresenter (ITemplateGridView<Contractor> view, ClientServiceModel service)
        {
            _view = view;
            _service = service;

            _view.AddItem += () => AddContractor ();
            _view.EditItem += () => EditContractor (_view.SelectedEntity);
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (Partner partner)
        {
            _view.DataSource = _service.GetContractorsFromPartner (partner);
        }

        public void ContractorSearch (Partner partner)
        {

        }

        public void ContractorFilter (Partner partner, AbstractFilter<Individual>[] filterIndividual, AbstractFilter<Entrepreneur>[] filterEntrepreneur)
        {
            if ( partner == null )
                return;

            IList<Contractor> contractors = new List<Contractor> ();

            IList<Entrepreneur> entrepreneur = Filtred (_service.GetEntreprenseursFromPartner (partner), filterEntrepreneur);
            if (entrepreneur != null)
                foreach ( var item in entrepreneur )
                    contractors.Add (new Contractor (item));

            IList<Individual> individuals = Filtred (_service.GetIndividualsFromPartner (partner), filterIndividual);
            foreach ( var item in individuals )
                contractors.Add (new Contractor (item));

            _view.DataSource = contractors;
        }

        private IList<T> Filtred<T> (IList<T> contractors, params AbstractFilter<T>[] filters) where T : class, Data.IEntity, ICounterparties
        {
            foreach ( AbstractFilter<T> filter in filters )
            {
                filter.Counterparties = contractors;
                filter.Execute ();
                contractors = contractors.Intersect (filter.Counterparties);
            }

            return contractors;
        }

        private void AddContractor ()
        {
            var presenter = new Presenter.ClientPresenter.DialogPresenter (new View.Counterparties.ExtraControls.AddContractorControl (), 
                                                                                                 new View.ClientWindow.DialogWindow ());
            presenter.Run ();
        }

        private void EditContractor (Contractor contractor)
        {
            if ( contractor == null )
                return;

            var editPresenter = new EditContractorPresenter (new EditorWindow ());
            editPresenter.Run (contractor);
        }
    }
}
