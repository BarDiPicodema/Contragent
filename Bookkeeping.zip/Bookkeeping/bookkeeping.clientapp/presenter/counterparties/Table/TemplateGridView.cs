﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.Data;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public interface ITemplateGridView<TEntity> : Common.IViewTableControl 
        where TEntity : class
    {
        TEntity SelectedEntity { get; }
    }
}
