﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Model.Util;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public class AccountGridPresenter : Common.IPresenterControlInfo
    {
        ITemplateGridView<Account> _view;
        AccessServiceModel<Account> _service;

        private Contractor _contractor;

        public AccountGridPresenter (ITemplateGridView<Account> view, AccessServiceModel<Account> service)
        {
            _view = view;
            _service = service;

            _view.AddItem += () => AddAccount ();
            _view.EditItem += () => SelectedAccount (_view.SelectedEntity);
            _view.SelectedItem += () => SelectedAccount (_view.SelectedEntity);
        }

        public void Refresh (Partner partner)
        {
            _contractor = new Contractor (partner);
            var accounts = new List<AccountRow> ();
            foreach (var item in _service.GetEntities (item => item.IdPartner == partner.Id))
                accounts.Add (new AccountRow (item));

            _view.DataSource = accounts;
        }

        public void Refresh (Individual individual)
        {
            _contractor = new Contractor (individual);
            var accounts = new List<AccountRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdIndividual == individual.Id))
                accounts.Add (new AccountRow (item));

            _view.DataSource = accounts;
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            _contractor = new Contractor (entrepreneur);
            var accounts = new List<AccountRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdEntrepreneur == entrepreneur.Id) )
                accounts.Add (new AccountRow (item));

            _view.DataSource = accounts;
        }

        private void Refresh ()
        {
            if ( _contractor == null )
                return;

            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) _contractor);
        }

        public void Init ()
        {
            _service.Init ();
        }

        private void SelectedAccount (Account account)
        {
            if ( account == null )
                return;

            var control = new View.Counterparties.InfoControls.AccountControl ();
            var presenter = new DialogInfoPresenter<Account> (control, new View.ClientWindow.DialogWindow ());
            presenter.Run (account);
        }

        private void AddAccount ()
        {
            if ( _contractor == null )
            {
                System.Windows.Forms.MessageBox.Show ("Вы не выбрали контрагента");
                return;
            }

            var account = new Account ();
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                account.IdPartner = ( (Partner) _contractor ).Id;
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                account.IdIndividual = ( (Individual) _contractor ).Id;
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                account.IdEntrepreneur = ( (Entrepreneur) _contractor ).Id;

            var control = new View.Counterparties.InfoControls.AccountControl ();
            var controlPresenter = ( (AccountPresenter) control.Presenter );
            controlPresenter.Init ();
            controlPresenter.Refresh (account);

            var presenter = new DialogPresenter (control, new View.ClientWindow.DialogWindow ());
            presenter.Run ();

            this.Refresh ();
        }
    }
}
