﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.View.Counterparties;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public class PartnerGridPresenter : Common.IPresenterControl
    {
        public InfoPresenter InfoPresenter;

        private ITemplateGridView<Partner> _view;
        private AccessServiceModel<Partner> _service;

        public PartnerGridPresenter (ITemplateGridView<Partner> view, AccessServiceModel<Partner> service)
        {
            _view = view;
            _service = service;

            _view.AddItem += () => AddContractor ();
            _view.EditItem += () => EditPartner (_view.SelectedEntity);
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh ()
        {
            _view.DataSource = _service.GetAll ();
        }

        public void Search (QueryManager query)
        {
            var result = _service.GetEntitiesFromSQLQuery (query.GenerateSQLQuery (), query.Values);
            if (result == null)
            {
                System.Windows.Forms.MessageBox.Show ("Поиск не дал результатов");
                return;
            }

            _view.DataSource = result;
        }

        public void PartnerFilter (params AbstractFilter<Partner>[] filters)
        {
            IList<Partner> partnerFiltred = _service.GetAll ();

            foreach ( AbstractFilter<Partner> filter in filters )
            {
                filter.Counterparties = partnerFiltred;
                filter.Execute ();
                partnerFiltred = partnerFiltred.Intersect (filter.Counterparties);
            }

            _view.DataSource = partnerFiltred;
        }

        private void AddContractor ()
        {
            var presenter = new Presenter.ClientPresenter.DialogPresenter (new View.Counterparties.ExtraControls.AddContractorControl (),
                                                                                                 new View.ClientWindow.DialogWindow ());
            presenter.Run ();
        }

        public void EditPartner (Partner partner)
        {
            if ( partner == null )
                return;

            var editPresenter = new EditContractorPresenter (new EditorWindow ());
            editPresenter.Run (new Contractor (partner));
        }
    }
}
