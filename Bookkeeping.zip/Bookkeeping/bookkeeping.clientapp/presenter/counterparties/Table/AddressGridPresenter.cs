﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Model.Util;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public class AddressGridPresenter : Common.IPresenterControlInfo
    {
        ITemplateGridView<Address> _view;
        AccessServiceModel<Address> _service;

        private Contractor _contractor;

        public AddressGridPresenter (ITemplateGridView<Address> view, AccessServiceModel<Address> service)
        {
            _view = view;
            _service = service;

            _view.AddItem += () => AddAddress ();
            _view.EditItem += () => EditAddress (_view.SelectedEntity);
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (Partner partner)
        {
            _contractor = new Contractor (partner);
            var addresses = new List<AddressRow> ();
            foreach (var item in  _service.GetEntities (item => item.IdPartner == partner.Id))
                addresses.Add (new AddressRow (item));

            _view.DataSource = addresses;
        }

        public void Refresh (Individual individual)
        {
            _contractor = new Contractor (individual);
            var addresses = new List<AddressRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdIndividual == individual.Id) )
                addresses.Add (new AddressRow (item));

            _view.DataSource = addresses;
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            _contractor = new Contractor (entrepreneur);
            var addresses = new List<AddressRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdEntrepreneur == entrepreneur.Id) )
                addresses.Add (new AddressRow (item));

            _view.DataSource = addresses;
        }

        private void Refresh ()
        {
            if ( _contractor == null )
                return;

            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) _contractor);
        }

        public void EditAddress (Address address)
        {
            if ( address == null )
                return;

            var control = new View.Counterparties.InfoControls.AddressControl ();
            var presenter = new DialogInfoPresenter<Address> (control, new View.ClientWindow.DialogWindow ());
            presenter.Run (address);
        }

        public void AddAddress ()
        {
            if ( _contractor == null )
            {
                System.Windows.Forms.MessageBox.Show ("Вы не выбрали контрагента");
                return;
            }

            var address = new Address ();
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
            {
                address.IdPartner = ( (Partner) _contractor ).Id;
            }
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
            {
                address.IdIndividual = ( (Individual) _contractor ).Id;
            }
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
            {
                address.IdEntrepreneur = ( (Entrepreneur) _contractor ).Id;
            }

            var control = new View.Counterparties.InfoControls.AddressControl ();
            var controlPresenter = ( (AddressPresenter) control.Presenter );
            controlPresenter.Init ();
            controlPresenter.Refresh (address);

            var presenter = new DialogPresenter (control, new View.ClientWindow.DialogWindow ());
            presenter.Run ();

            Refresh ();
        }
    }
}
