﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Model.Util;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Table
{
    public interface IDocumentGridView : Common.IViewTableControl
    {
        Document SelectedEntity { get; }
    }

    public class DocumentGridPresenter : Common.IPresenterControlInfo
    {
        ITemplateGridView<Document> _view;
        AccessServiceModel<Document> _service;

        private Contractor _contractor;

        public DocumentGridPresenter (ITemplateGridView<Document> view, AccessServiceModel<Document> service)
        {
            _view = view;
            _service = service;

            _view.AddItem += () => AddDocument ();
            _view.EditItem += () => EditDocument (_view.SelectedEntity);
        }

        public void Refresh (Partner partner)
        {
            _contractor = new Contractor (partner);
            var entities = new List<DocumentRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdPartner == partner.Id) )
                entities.Add (new DocumentRow (item));

            _view.DataSource = entities;
        }

        public void Refresh (Individual individual)
        {
            _contractor = new Contractor (individual);
            var entities = new List<DocumentRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdIndividual == individual.Id) )
                entities.Add (new DocumentRow (item));

            _view.DataSource = entities;
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            _contractor = new Contractor (entrepreneur);
            var entities = new List<DocumentRow> ();
            foreach ( var item in _service.GetEntities (item => item.IdEntrepreneur == entrepreneur.Id) )
                entities.Add (new DocumentRow (item));

            _view.DataSource = entities;
        }

        public void Init ()
        {
            _service.Init ();
        }

        private void Refresh ()
        {
            if ( _contractor == null )
                return;

            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) _contractor);
        }

        private void EditDocument (Document document)
        {
            if ( document == null )
                return;

            var control = new View.Counterparties.InfoControls.DocumentControl ();
            var presenter = new DialogInfoPresenter<Document> (control, new View.ClientWindow.DialogWindow ());
            presenter.Run (document);
        }

        private void AddDocument ()
        {
            if ( _contractor == null )
            {
                System.Windows.Forms.MessageBox.Show ("Вы не выбрали контрагента");
                return;
            }

            var document = new Document ();
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                document.IdPartner = ( (Partner) _contractor ).Id;
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                document.IdIndividual = ( (Individual) _contractor ).Id;
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                document.IdEntrepreneur = ( (Entrepreneur) _contractor ).Id;

            var control = new View.Counterparties.InfoControls.DocumentControl ();
            var controlPresenter = ( (DocumentPresenter) control.Presenter );
            controlPresenter.Init ();
            controlPresenter.Refresh (document);

            var presenter = new DialogPresenter (control, new View.ClientWindow.DialogWindow ());
            presenter.Run ();

            Refresh ();
        }
    }
}
