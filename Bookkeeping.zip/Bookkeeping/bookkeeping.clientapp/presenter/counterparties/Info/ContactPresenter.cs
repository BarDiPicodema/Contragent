﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info
{
    public interface IContactView : Common.IViewInfoControl
    {
        IEditorToolView ToolView { get; }

        IEntityControlView ContactTypeView { get; }
        EntityPresenter<ContactType> ContactType { get; }

        string ContactText { get; set; }
        string ContactName { get; set; }
        string Post { get; set; }
        string Sub { get; set; }
        string Note { get; set; }

        Contact Contact { get; set; }
    }

    public class ContactPresenter : Common.IPresenterControl<Contact>
    {
        private IContactView _view;
        private AccessServiceModel<Contact> _service;

        private Contact _tempContact;

        public ContactPresenter (IContactView view, AccessServiceModel<Contact> service)
        {
            _view = view;
            _service = service;

            _view.ToolView.SaveData += () => SaveData ();
            _view.ToolView.DeleteData += () => DeleteData ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.ContactTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
        }

        private void AddOnPropertyChanged ()
        {
            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.ContactTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();

            _view.ContactType.Init ();
            _view.AccessType.Init ();
            _view.Flag.Init ();
        }

        public void Refresh (Contact contact)
        {
            _view.Contact = contact;

            _view.ContactType.Refresh (contact.ContactType);
            _view.Flag.Refresh (contact.Flag);
            _view.AccessType.Refresh (contact.AccessType);

            _view.ContactText = contact.ContactText;
            _view.ContactName = contact.Name;
            _view.Post = contact.Post;
            _view.Sub = contact.Sub;
            _view.Note = contact.Description;
        }

        private void OnPropertyChanged ()
        {
            if ( _view.Contact == null )
                return;

            if ( _tempContact == null )
                _tempContact = new Contact ();

            _tempContact.Id = _view.Contact.Id;
            _tempContact.ContactText = _view.ContactText;
            _tempContact.Name = _view.ContactName;
            _tempContact.Post = _view.Post;
            _tempContact.Sub = _view.Sub;
            _tempContact.Description = _view.Note;

            if ( _view.ContactTypeView.SelectedEntity != null )
                _tempContact.IdContactType = ( _view.ContactTypeView.SelectedEntity as ContactType ).Id;

            if ( _view.FlagView.SelectedEntity != null )
                _tempContact.IdFlag = ( _view.FlagView.SelectedEntity as Flag ).Id;

            if ( _view.AccessTypeView.SelectedEntity != null )
                _tempContact.IdAccessType = ( _view.AccessTypeView.SelectedEntity as AccessType ).Id;
        }

        private void SaveData ()
        {
            if ( _tempContact != null )
            {
                if ( _tempContact.IdFlag == 0 || _tempContact.IdContactType == 0 || _tempContact.IdAccessType == 0 
                    || _tempContact.ContactText == string.Empty || _tempContact.Name == string.Empty)
                {
                    System.Windows.Forms.MessageBox.Show ("Вы не заполнили обязательные поля! См. <*>");
                    return;
                }

                _tempContact.IdPartner = _view.Contact.IdPartner ?? null;
                _tempContact.IdIndividual = _view.Contact.IdIndividual ?? null;
                _tempContact.IdEntrepreneur = _view.Contact.IdEntrepreneur ?? null;

                Refresh (_service.AddOrUpdateEntity (_tempContact));
            }
        }

        private void DeleteData ()
        {
            if (_view.Contact != null)
                _service.RemoveEntity (_view.Contact);
        }
    }
}
