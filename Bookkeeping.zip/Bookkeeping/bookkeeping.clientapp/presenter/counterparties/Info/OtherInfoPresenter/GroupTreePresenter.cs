﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.View.ClientWindow;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;
using Bookkeeping.Data.Entities;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter
{
    public interface IGroupTreeView : Common.IViewTreeControl
    {
        GroupType SelectedType { get; set; }

        void ExpandAll ();

        event Action AddGroupType;
        event Action UpdateGroupType;
        event Action RemoveGroupType;
    }

    public class GroupTreePresenter : Common.IPresenterControl
    {
        private IGroupTreeView _view;
        private ServiceModel<GroupType> _service;
        private ServiceModel<GroupTypeToType> _serviceGroupToGroup;
        
        public GroupTreePresenter (IGroupTreeView view, ServiceModel<GroupType> service)
        {
            _view = view;
            _service = service;
            _serviceGroupToGroup = new ServiceModel<GroupTypeToType> ();

            _view.AddGroupType += () => AddGroupType ();
            _view.UpdateGroupType += () => UpdateGroupType ();
            _view.RemoveGroupType += () => RemoveGroupType ();
        }

        private ContextMenu ItemMenu { get; set; }

        private void CreateContextMenuItem ()
        {
            var add = new MenuItem ();
            add.Click += (sender, args) => AddGroupType ();
            var update = new MenuItem ();
            update.Click += (sender, args) => UpdateGroupType ();
            var remove = new MenuItem ();
            remove.Click += (sender, args) => RemoveGroupType ();
            ItemMenu = new System.Windows.Forms.ContextMenu (new MenuItem[] { add, update, remove });
        }

        public void Init ()
        {
            _service.Init ();
            _serviceGroupToGroup.Init ();
        }

        public void Refresh ()
        {
            _view.Nodes.Clear ();
            var main = new GroupNode ("Группы");
            main.ContextMenu = ItemMenu;

            foreach ( var parent in _service.GetAll () )
            {
                var grouptypes = _serviceGroupToGroup.GetEntities (item => item.IdGroupTypeOne == parent.Id);
                if ( grouptypes == null )
                    return;

                if ( grouptypes.Count > 0 )
                {
                    GroupNode parentNode = AddNewGroup (parent);
                    foreach ( var group in grouptypes )
                    {
                        parentNode.Nodes.Add (AddNewGroup (group.GroupTypeTwo));
                    }
                    main.Nodes.Add (parentNode);
                }
            }

            foreach ( var parent in _service.GetAll () )
            {
                if ( main.Nodes.Find (parent.Id.ToString (), true).Length <= 0 )
                    main.Nodes.Add (new GroupNode (parent));
            }

            _view.Nodes.Add (main);

            _view.ExpandAll ();
        }

        private GroupNode AddNewGroup (GroupType type)
        {
            if ( _view.Nodes.Find (type.Id.ToString (), true).Length <= 0 )
            {
                var group = new GroupNode (type);
                group.ContextMenu = ItemMenu;
                return group;
            }
            else return _view.Nodes.Find (type.Id.ToString (), true)[0] as GroupNode;
        }


        private void AddGroupType ()
        {
            var group = new GroupType ();
            if (_view.SelectedType != null)
                ShowDialog (group);
        }

        private void UpdateGroupType ()
        {
            ShowDialog (_view.SelectedType);
        }

        private void ShowDialog (GroupType groupType)
        {
            var type = new TypeCreatorControl ();
            type.Presenter = new TypePresenter<GroupType> (type, new ServiceModel<GroupType> ());
            type.Presenter.Init ();
            ( type.Presenter as TypePresenter<GroupType> ).Refresh (groupType);
            var dialog = new DialogPresenter (type, new DialogWindow ());
            dialog.Show ();

            Refresh ();
        }

        private void RemoveGroupType ()
        {
            var messageBox = System.Windows.Forms.MessageBox.Show ("Вы действительно хотите уладить тип группы < "+_view.SelectedType.TypeName+" >?", 
                                                                                                "Внимание", System.Windows.Forms.MessageBoxButtons.YesNo);

            if (messageBox == System.Windows.Forms.DialogResult.Yes)
            {
                _service.RemoveEntity (_view.SelectedType);
                Refresh ();
            }
        }
    }
}
