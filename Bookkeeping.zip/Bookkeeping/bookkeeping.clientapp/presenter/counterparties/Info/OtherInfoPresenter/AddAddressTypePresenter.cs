﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter
{
    public interface IAddAddressTypeView : Common.IViewControl
    {
        IEditorToolView ToolView { get; }

        IEntityControlView AddressTypeView { get; }
        EntityPresenter<AddressType> AddressType { get; }

        AddressValue AddressValue { get; set; }
    }

    public class AddAddressTypePresenter : Common.IPresenterControl<AddressValue>
    {
        private IAddAddressTypeView _view;
        private ServiceModel<AddressValue> _service;

        public AddAddressTypePresenter (IAddAddressTypeView view, ServiceModel<AddressValue> service)
        {
            _view = view;
            _service = service;

            _view.ToolView.SaveData += () => SaveData ();
        }

        public void Init ()
        {
            _service.Init ();

            _view.AddressType.Init ();
        }

        public void Refresh (AddressValue value)
        {
            if ( value == null )
                throw new ArgumentNullException ();

            _view.AddressValue = value;

            _view.AddressType.Refresh (value.AddressType);
        }

        private void SaveData ()
        {
            if (_view.AddressValue != null && _view.AddressTypeView.SelectedEntity != null )
            {
                _view.AddressValue.IdAddressType = ( _view.AddressTypeView.SelectedEntity as AddressType ).Id;
                _service.AddOrUpdateEntity (_view.AddressValue);
            }
        }
    }
}
