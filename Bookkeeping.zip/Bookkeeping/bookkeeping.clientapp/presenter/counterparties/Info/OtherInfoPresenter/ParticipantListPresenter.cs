﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter
{
    public interface IParticipantListView : Common.IViewControl
    {
        object DataSource { get; set; }

        DocumentParticipant SelectedItem { get; }

        event Action AddParticipant;
        event Action RemoveParticipant;
    }

    public class ParticipantListPresenter : Common.IPresenterControl<Document>
    {
        private IParticipantListView _view;
        private ServiceModel<DocumentParticipant> _service;

        private Document _tempDocument;

        public ParticipantListPresenter (IParticipantListView view, ServiceModel<DocumentParticipant> service)
        {
            _view = view;
            _service = service;

            _view.AddParticipant += () => AddParticipant ();
            _view.RemoveParticipant += () => RemoveParticipant ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (Document document)
        {
            if ( document == null )
                throw new ArgumentNullException ("Participant nullable");

            _tempDocument = document;
            _view.DataSource = _service.GetEntities (item => item.IdDocument == document.Id);
        }

        private void AddParticipant ()
        {
            if ( _tempDocument == null )
            {
                System.Windows.Forms.MessageBox.Show ("Вы не можете добавить участника в несуществующий документ. Пожалуйста сохраните документ и попробуйте ещё раз!");
                return;
            }

            var control = new AddParticipantControl ();
            var participant = new DocumentParticipant () { IdDocument = _tempDocument.Id };

            var dialog = new DialogInfoPresenter<DocumentParticipant> (control, new View.ClientWindow.DialogWindow ());
            dialog.Init ();
            dialog.Run (participant);
        }

        private void RemoveParticipant ()
        {
            if ( _view.SelectedItem != null )
            {
                _service.RemoveEntity (_view.SelectedItem);
                Refresh (_tempDocument);
            }
        }
    }
}
