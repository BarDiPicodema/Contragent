﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter
{
    public interface ILinkListView : Common.IViewControl
    {
        object DataSource { get; set; }

        Link SelectedItem { get; }

        event Action AddLink;
        event Action RemoveLink;
    }

    public class LinkListPresenter : Common.IPresenterControl<Document>
    {
        private ILinkListView _view;
        private ServiceModel<Link> _service;

        private Document _tempDocument;

        public LinkListPresenter (ILinkListView view, ServiceModel<Link> service)
        {
            _view = view;
            _service = service;

            _view.AddLink += () => AddLinkDocument ();
            _view.RemoveLink += () => RemoveLinkDocument ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (Document document)
        {
            if ( document == null )
                throw new ArgumentNullException ("document nullable");

            _tempDocument = document;
            _view.DataSource = _service.GetEntities (item => item.IdDocument == document.Id);
        }

        private void AddLinkDocument ()
        {
            if ( _tempDocument == null )
            {
                System.Windows.Forms.MessageBox.Show ("Вы не можете добавить ссылку в несуществующий документ. Пожалуйста сохраните документ и попробуйте ещё раз!");
                return;
            }

            var control = new AddLinkDocumentControl ();
            var linkValue = new Link () { IdDocument = _tempDocument.Id };

            var dialog = new DialogInfoPresenter<Link> (control, new View.ClientWindow.DialogWindow ());
            dialog.Init ();
            dialog.Run (linkValue);
        }

        private void RemoveLinkDocument ()
        {
            _service.RemoveEntity (_view.SelectedItem);
            Refresh (_tempDocument);
        }
    }
}
