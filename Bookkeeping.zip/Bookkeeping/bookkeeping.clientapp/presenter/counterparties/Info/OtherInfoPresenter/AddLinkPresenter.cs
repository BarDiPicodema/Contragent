﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter
{
    public interface IAddLinkView : Common.IViewControl
    {
        string LinkText { get; set; }
        string NoteLink { get; set; }

        Link Link { get; set; }

        event Action Save;
        event Action Find;

        event EventHandler PropertyChanged;
    }

    public class AddLinkPresenter : Common.IPresenterControl<Link>
    {
        private IAddLinkView _view;
        private ServiceModel<Link> _service;

        private Link _link;

        public AddLinkPresenter (IAddLinkView view, ServiceModel<Link> service)
        {
            _view = view;
            _service = service;

            _view.Save += () => SaveLink ();
            _view.Find += () => FindDocument ();
            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (Link link)
        {
            _view.Link = link;
            _view.LinkText = link.UriLink;
            _view.NoteLink = link.Description;
        }

        public void OnPropertyChanged ()
        {
            if ( _link == null )
                _link = new Link ();

            _link.Id = _view.Link.Id;
            _link.UriLink = _view.LinkText;
            _link.Description = _view.NoteLink;
        }

        public void SaveLink ()
        {
            if ( _link.UriLink == string.Empty )
            {
                System.Windows.Forms.MessageBox.Show ("Вы не добавили ссылку на документ!");
                return;
            }

            _service.AddOrUpdateEntity (_link);
        }

        public void FindDocument ()
        {
            FileDialog dialog = new OpenFileDialog ();
            dialog.ShowDialog ();
            _view.LinkText = dialog.FileName;
        }
    }
}
