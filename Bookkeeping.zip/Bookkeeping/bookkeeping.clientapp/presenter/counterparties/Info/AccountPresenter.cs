﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info
{
    public interface IAccountView : Common.IViewInfoControl
    {
        IEditorToolView ToolView { get; }

        IEntityControlView AccountTypeView { get; }
        EntityPresenter<AccountType> AccountType { get; }
        IEntityControlView AccountKindView { get; }
        EntityPresenter<AccountKind> AccountKind { get; }

        IClassificatorView OkvView { get; }
        ClassificatorPresenter<Okv> OkvPresenter { get; }

        string AccountName { get; set; }
        string NumberAccount { get; set; }
        string Recipient { get; set; }
        string Bic { get; set; }
        string Iban { get; set; }
        string Bank { get; set; }
        string AddressBank { get; set; }
        string CorAccount { get; set; }
        string CorBank { get; set; }
        string Description { get; set; }

        Account Account { get; set; }
    }

    public class AccountPresenter : Common.IPresenterControl<Account>
    {
        private IAccountView _view;
        private AccessServiceModel<Account> _service;

        private Account _tempAccount;

        public AccountPresenter (IAccountView view, AccessServiceModel<Account> service)
        {
            _view = view;
            _service = service;

            _view.ToolView.SaveData += () => SaveData ();
            _view.ToolView.DeleteData += () => DeleteData ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.AccountKindView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccountTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();

            _view.OkvView.OpenClassificator += () => OnPropertyChanged ();
        }

        private void AddOnPropertyChanged ()
        {
            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.AccountKindView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccountTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();

            _view.AccountKind.Init ();
            _view.AccountType.Init ();
            _view.AccessType.Init ();
            _view.Flag.Init ();
            _view.OkvPresenter.Init ();
        }

        public void Refresh (Account account)
        {
            _view.Account = account;

            _view.AccountType.Refresh (account.AccountType);
            _view.AccountKind.Refresh (account.AccountKind);
            _view.Flag.Refresh (account.Flag);
            _view.AccessType.Refresh (account.AccessType);
            _view.OkvPresenter.Refresh (account.Okv);

            _view.AccountName = account.Name;
            _view.NumberAccount = account.AccountNumber;
            _view.Bic = account.Bic;
            _view.Iban = account.IbanNumber;
            _view.Recipient = account.Recipient;
            _view.AddressBank = account.Settlement;
            _view.CorAccount = account.CorrespondentAccount;
            _view.CorBank = account.CorrespondentBank;
            _view.Description = account.Description;
        }

        private void OnPropertyChanged ()
        {
            if ( _view.Account == null )
                return;

            if ( _tempAccount == null )
                _tempAccount = new Account ();

            _tempAccount.Id = _view.Account.Id;
            _tempAccount.Name = _view.AccountName;
            _tempAccount.AccountNumber = _view.NumberAccount;
            _tempAccount.Bic = _view.Bic;
            _tempAccount.IbanNumber = _view.Iban;
            _tempAccount.Recipient = _view.Recipient;
            _tempAccount.Bank = _view.AddressBank;
            _tempAccount.CorrespondentAccount = _view.CorAccount;
            _tempAccount.CorrespondentBank = _view.CorBank;
            _tempAccount.Description = _view.Description;

            if ( _view.AccountTypeView.SelectedEntity != null )
                _tempAccount.IdAccountType = ( _view.AccountTypeView.SelectedEntity as AccountType ).Id;

            if ( _view.AccountKindView.SelectedEntity != null )
                _tempAccount.IdAccountKind = ( _view.AccountKindView.SelectedEntity as AccountKind ).Id;

            if ( _view.FlagView.SelectedEntity != null )
                _tempAccount.IdFlag = ( _view.FlagView.SelectedEntity as Flag ).Id;

            if ( _view.AccessTypeView.SelectedEntity != null )
                _tempAccount.IdAccessType = ( _view.AccessTypeView.SelectedEntity as AccessType ).Id;

            if ( _view.OkvView.Classificator != null )
                _tempAccount.IdOkv = ( _view.OkvView.Classificator as Okv ).Id;
        }

        private void SaveData ()
        {
            if ( _tempAccount != null )
            {
                if ( _tempAccount.IdFlag == 0 || _tempAccount.IdAccountType == 0 || _tempAccount.IdAccountKind == 0 
                    || _tempAccount.IdAccessType == 0 || _tempAccount.Name == string.Empty || _tempAccount.AccountNumber == string.Empty
                    || _tempAccount.Recipient == string.Empty )
                {
                    System.Windows.Forms.MessageBox.Show ("Вы не заполнили обязательные поля! См. <*>");
                    return;
                }

                _tempAccount.IdPartner = _view.Account.IdPartner ?? null;
                _tempAccount.IdIndividual = _view.Account.IdIndividual ?? null;
                _tempAccount.IdEntrepreneur = _view.Account.IdEntrepreneur ?? null;

                Refresh (_service.AddOrUpdateEntity (_tempAccount));
            }
        }

        private void DeleteData ()
        {
            if (_view.Account != null)
                _service.RemoveEntity (_view.Account);
        }
    }
}
