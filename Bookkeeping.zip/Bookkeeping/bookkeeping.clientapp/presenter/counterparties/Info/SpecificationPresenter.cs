﻿
using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info
{
    public interface ISpecificationView : Common.IViewControl
    {
        Specification Specification { get; set; }

        bool ReadOnly { get; set; }
        string RtfText { get; set; }
        string TextSpecification { get; set; }

        event Action PropertyChanged;
        event Action SaveData;
    }

    public class SpecificationPresenter : Common.IPresenterControlInfo
    {
        private ISpecificationView _view;
        private ServiceModel<Specification> _service;

        private Specification _tempSpecification;
        private Contractor _contractor;

        public SpecificationPresenter (ISpecificationView view, ServiceModel<Specification> service)
        {
            _view = view;
            _service = service;

            _view.SaveData += () => SaveData ();

            _view.PropertyChanged += () => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (Partner partner)
        {
            var specification = _service.FindEntity (item => item.IdPartner == partner.Id);
            if ( specification == null )
                _tempSpecification = new Specification () {IdPartner = partner.Id };
            else
            {
                _view.RtfText = System.Text.Encoding.UTF8.GetString (specification.SpecificationTextStyle);
                _view.TextSpecification = specification.SpecificationText;
            }
        }

        public void Refresh (Individual individual)
        {
            var specification = _service.FindEntity (item => item.IdIndividual == individual.Id);
            if ( specification == null )
                _tempSpecification = new Specification () {IdIndividual = individual.Id };
            else
            {
                _view.RtfText = System.Text.Encoding.UTF8.GetString (specification.SpecificationTextStyle);
                _view.TextSpecification = specification.SpecificationText;
            }
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            var specification = _service.FindEntity (item => item.IdEntrepreneur == entrepreneur.Id);
            if ( specification == null )
                _tempSpecification = new Specification () { IdEntrepreneur = entrepreneur.Id };
            else
            {
                _view.RtfText = System.Text.Encoding.UTF8.GetString (specification.SpecificationTextStyle);
                _view.TextSpecification = specification.SpecificationText;
            }
        }

        private void Refresh ()
        {
            if ( _contractor == null )
                return;

            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) _contractor);
        }

        private void OnPropertyChanged ()
        {
            if ( _tempSpecification == null )
                _tempSpecification = new Specification ();

            _tempSpecification.SpecificationTextStyle = System.Text.Encoding.UTF8.GetBytes (_view.RtfText);
            _tempSpecification.SpecificationText = _view.TextSpecification;
        }

        private void SaveData ()
        {
            if ( _tempSpecification != null )
            {
                _service.AddOrUpdateEntity (_tempSpecification);
                Refresh ();
            }
        }

        /// <summary>
        /// Not using
        /// </summary>
        private void DeleteData ()
        {
            if (_view.Specification != null)
                _service.RemoveEntity (_view.Specification);
        }
    }
}
