﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.View.Common;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info
{
    public interface IGroupView : Common.IViewControl
    {
        IEditorToolView ToolView { get; }

        IGroupTreeView GroupTreeView { get; }
        GroupTreePresenter GroupTreePresenter { get; }

        IContractorGroupTypeTreeView ContractorGroupTypeView { get; }
        ContractorGroupTypeTreePresenter ContractorGroupTypePresenter { get; }

        event Action AddGroup;
        event Action RemoveGroup;
    }

    public class GroupPresenter : Common.IPresenterControlInfo
    {
        private IGroupView _view;
        private ServiceModel<Group> _service;
        private ServiceModel<GroupTypeToType> _serviceGroup;

        private Contractor _contractor;

        public GroupPresenter (IGroupView view, ServiceModel<Group> service)
        {
            _view = view;
            _service = service;
            _serviceGroup = new ServiceModel<GroupTypeToType> ();

            _view.AddGroup += () => AddGroupTypeToContractor ();
            _view.RemoveGroup += () => RemoveGroupTypeToContractor ();
            _view.ContractorGroupTypeView.RemoveGroupType += () => RemoveGroupTypeToContractor ();
        }

        public void Init ()
        {
            _service.Init ();
            _serviceGroup.Init ();

            _view.GroupTreePresenter.Init ();
            _view.ContractorGroupTypePresenter.Init ();
        }

        public void Refresh (Partner partner)
        {
            if ( partner == null )
                return;

            _contractor = new Contractor (partner);
            _view.GroupTreePresenter.Refresh ();
            _view.ContractorGroupTypePresenter.Refresh (partner);
        }

        public void Refresh (Individual individual)
        {
            if ( individual == null )
                return;

            _contractor = new Contractor (individual);
            _view.GroupTreePresenter.Refresh ();
            _view.ContractorGroupTypePresenter.Refresh (individual);
        }

        public void Refresh (Entrepreneur entrepreneur)
        {
            if ( entrepreneur == null )
                return;

            _contractor = new Contractor (entrepreneur);
            _view.GroupTreePresenter.Refresh ();
            _view.ContractorGroupTypePresenter.Refresh (entrepreneur);
        }

        private void Refresh ()
        {
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                Refresh ((Partner) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                Refresh ((Individual) _contractor);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                Refresh ((Entrepreneur) _contractor);
        }

        private void AddGroupTypeToContractor ()
        {
            var checkedTreeNode = _view.GroupTreeView.CheckedItem as GroupNode;
            var groupTypeTwo = checkedTreeNode.GroupType;

            GroupType groupTypeOne = null;
            if ( checkedTreeNode.Parent != null )
                groupTypeOne = ( checkedTreeNode.Parent as GroupNode ).GroupType;
            else groupTypeOne = groupTypeTwo;
            
            var groupTypeToType = _serviceGroup.FindEntity (item => item.IdGroupTypeTwo == groupTypeTwo.Id && item.IdGroupTypeOne == groupTypeOne.Id);
            
            Group group = new Group();
            if ( groupTypeToType == null )
                throw new Exception ("Связки групп не существует!");

            group.IdGroupTypeToType = groupTypeToType.Id;

            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                group.IdPartner = _contractor.Id;
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                group.IdIndividual = _contractor.Id;
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                group.IdEntrepreneur = _contractor.Id;

            _service.AddOrUpdateEntity (group);

            Refresh ();
        }

        private void RemoveGroupTypeToContractor ()
        {
            var groupNode = ( _view.ContractorGroupTypeView.CheckedItem as GroupNode ).GroupType;
            IList<Group> groups = new List<Group>();
            if ( _contractor.TypeContractor == ContractorTypes.Partner )
                groups = _service.GetEntities (item => item.IdPartner == _contractor.Id);
            else if ( _contractor.TypeContractor == ContractorTypes.Individual )
                groups = _service.GetEntities (item => item.IdIndividual == _contractor.Id);
            else if ( _contractor.TypeContractor == ContractorTypes.Entrepreneur )
                groups = _service.GetEntities (item => item.IdEntrepreneur == _contractor.Id);

            foreach (var group in groups)
                if (group.GroupTypeToType.IdGroupTypeTwo == groupNode.Id)
                    _serviceGroup.RemoveEntity (group.GroupTypeToType);

            Refresh ();
        }
    }
}
