﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info
{
    public interface IDocumentView : Common.IViewInfoControl
    {
        IEditorToolView ToolView { get; }

        IEntityControlView DocumentTypeView { get; }
        EntityPresenter<DocumentType> DocumentType { get; }

        IParticipantListView ParticipantListView { get; }
        ParticipantListPresenter ParticipantListPresenter { get; }

        ILinkListView LinkListView { get; }
        LinkListPresenter LinkListPresenter { get; }

        string Appointment { get; set; }
        string DocumentName { get; set; }
        string Series { get; set; }
        string Number { get; set; }
        DateTime DocumentDate { get; set; }
        string DocumentPlace { get; set; }
        string SubdivisionCode { get; set; }
        DateTime ExpDate { get; set; }
        string Renew { get; set; }
        string Issues { get; set; }
        string Note { get; set; }

        bool ParticipantsEnable { get; set; }
        bool LinksEnable { get; set; }

        Document Document { get; set; }
    }

    public class DocumentPresenter : Common.IPresenterControl<Document>
    {
        private IDocumentView _view;
        private AccessServiceModel<Document> _service;

        private Document _tempDocument;

        public DocumentPresenter (IDocumentView view, AccessServiceModel<Document> service)
        {
            _view = view;
            _service = service;

            _view.ToolView.SaveData += () => SaveData ();
            _view.ToolView.DeleteData += () => DeleteData ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.DocumentTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
        }

        private void AddOnPropertyChanged ()
        {
            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.DocumentTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();

            _view.DocumentType.Init ();
            _view.AccessType.Init ();
            _view.Flag.Init ();
            _view.ParticipantListPresenter.Init ();
            _view.LinkListPresenter.Init ();
        }

        public void Refresh (Document document)
        {
            _view.Document = document;

            _view.DocumentType.Refresh (document.DocumentType);
            _view.Flag.Refresh (document.Flag);
            _view.AccessType.Refresh (document.AccessType);
            _view.ParticipantListPresenter.Refresh (document);
            _view.LinkListPresenter.Refresh (document);

            _view.Appointment = document.Appointment;
            _view.DocumentName = document.Name;
            _view.Series = document.Series;
            _view.Number =document.DocumentNumber;
            _view.DocumentDate = document.DocumentDate ?? DateTime.Today;
            _view.DocumentPlace = document.DocumentPlace;
            _view.SubdivisionCode = document.SubdividionCode;
            _view.ExpDate = document.ExpDate ?? DateTime.Today;
            _view.Renew = document.Renew;
            _view.Issues = document.Issuer;
            _view.Note = document.Description;
        }

        private void OnPropertyChanged ()
        {
            if ( _view.Document == null )
                return;

            if ( _tempDocument == null )
                _tempDocument = new Document ();

            _tempDocument.Id = _view.Document.Id;
            _tempDocument.Appointment = _view.Appointment;
            _tempDocument.Name = _view.DocumentName;
            _tempDocument.Series = _view.Series;
            _tempDocument.DocumentNumber = _view.Number;
            _tempDocument.DocumentDate = _view.DocumentDate;
            _tempDocument.DocumentPlace = _view.DocumentPlace;
            _tempDocument.SubdividionCode = _view.SubdivisionCode;
            _tempDocument.ExpDate = _view.ExpDate;
            _tempDocument.Renew = _view.Renew;
            _tempDocument.Issuer = _view.Issues;
            _tempDocument.Description = _view.Note;

            if ( _view.DocumentTypeView.SelectedEntity != null )
                _tempDocument.IdDocumentType = ( _view.DocumentTypeView.SelectedEntity as DocumentType ).Id;

            if ( _view.FlagView.SelectedEntity != null )
                _tempDocument.IdFlag = ( _view.FlagView.SelectedEntity as Flag ).Id;

            if ( _view.AccessTypeView.SelectedEntity != null )
                _tempDocument.IdAccessType = ( _view.AccessTypeView.SelectedEntity as AccessType ).Id;

            if ( _tempDocument.Id == 0 )
            {
                _view.ParticipantsEnable = false;
                _view.LinksEnable = false;
            }
            else
            {
                _view.ParticipantsEnable = true;
                _view.LinksEnable = true;
            }
        }

        private void SaveData ()
        {
            if ( _tempDocument != null )
            {
                if ( _tempDocument.IdAccessType == 0 || _tempDocument.IdFlag == 0 || _tempDocument.IdDocumentType == 0 
                    || _tempDocument.Name == string.Empty || _tempDocument.Series == string.Empty || _tempDocument.DocumentNumber == string.Empty)
                {
                    System.Windows.Forms.MessageBox.Show ("Вы не заполнили обязательные поля! См. <*>");
                    return;
                }

                _tempDocument.IdPartner = _view.Document.IdPartner ?? null;
                _tempDocument.IdIndividual = _view.Document.IdIndividual ?? null;
                _tempDocument.IdEntrepreneur = _view.Document.IdEntrepreneur ?? null;

                Refresh ( _service.AddOrUpdateEntity (_tempDocument));
            }
        }

        private void DeleteData ()
        {
            if (_view.Document != null)
                _service.RemoveEntity (_view.Document);
            
        }
    }
}
