﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info
{
    public interface IAddressTypeListView : Common.IViewControl
    {
        object DataSource { get; set; }

        AddressType SelectedItem { get; }

        event Action AddAddressType;
        event Action RemoveAddressType;
    }

    public class AddressTypesPresenter : Common.IPresenterControl<Address>
    {
        private IAddressTypeListView _view;
        private ServiceModel<AddressValue> _service;

        private Address _tempAddress;

        public AddressTypesPresenter (IAddressTypeListView view, ServiceModel<AddressValue> service)
        {
            _view = view;
            _service = service;

            _view.AddAddressType += () => AddType ();
            _view.RemoveAddressType += () => RemoveType ();
        }

        public void Init ()
        {
            _service.Init ();
        }

        public void Refresh (Address address)
        {
            if ( address == null )
                System.Windows.Forms.MessageBox.Show ("Вы не можете добавить тип адреса в несуществующий адрес. Пожалуйста сохраните адрес и попробуйте ещё раз!");

            _tempAddress = address;
            
            var types = new List<AddressType> ();
            foreach ( var item in _service.GetEntities (item => item.IdAddress == address.Id) )
                types.Add (item.AddressType);

            _view.DataSource = types;
        }

        private void AddType ()
        {
            if ( _tempAddress == null || _tempAddress.Id == 0 )
            {
                System.Windows.Forms.MessageBox.Show ("Вам необходимо заполнить необходимые поля адреса и сохранить его, прежде чем добавлять в него типы");
                return;
            }

            var control = new AddAddressTypeControl ();
            var addressValue = new AddressValue() { IdAddress = _tempAddress.Id };

            var dialog = new DialogInfoPresenter<AddressValue> (control, new View.ClientWindow.DialogWindow ());
            dialog.Run (addressValue);
        }

        private void RemoveType ()
        {
            if ( _view.SelectedItem == null )
                return;

            var value = _service.FindEntity (item => item.IdAddress == _tempAddress.Id && item.IdAddressType == _view.SelectedItem.Id);
            if ( value != null )
            {
                _service.RemoveEntity (value);
                Refresh (_tempAddress);
            }
        }
    }
}
