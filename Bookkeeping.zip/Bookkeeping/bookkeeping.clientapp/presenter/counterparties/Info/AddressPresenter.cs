﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using Bookkeeping.ClientApp.View.ClientWindow;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Info
{
    public interface IAddressView : Common.IViewInfoControl
    {
        IEditorToolView ToolView { get; }

        IEntityControlView AddressTypeView { get; }
        EntityPresenter<AddressType> AddressType { get; }

        IAddressTypeListView AddressTypeListView { get; }
        AddressTypesPresenter AddressTypeListPresenter { get; }

        IClassificatorView OkatoView { get; }
        ClassificatorPresenter<Okato> OkatoPresenter { get; }

        IClassificatorView OktmoView { get; }
        ClassificatorPresenter<Okato> OktmoPresenter { get; }

        IClassificatorView SonoView { get; }
        ClassificatorPresenter<Sono> SonoPresenter { get; }

        string AddressName { get; set; }
        string Land { get; set; }
        string Area { get; set; }
        string City { get; set; }
        string Settlement { get; set; }
        string Index { get; set; }
        string Street { get; set; }
        string House { get; set; }
        string Structure { get; set; }
        string Office { get; set; }
        string Description { get; set; }

        bool AddressTypesEnable { get; set; }

        Address Address { get; set; }
    }

    public class AddressPresenter : Common.IPresenterControl<Address>
    {
        private IAddressView _view;
        private AccessServiceModel<Address> _service;

        private Address _tempAddress;

        public AddressPresenter (IAddressView view, AccessServiceModel<Address> service)
        {
            _view = view;
            _service = service;

            _view.ToolView.SaveData += () => SaveData ();
            _view.ToolView.DeleteData += () => DeleteData ();

            _view.PropertyChanged += (sender, args) => OnPropertyChanged ();
            _view.AddressTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.FlagView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();
            _view.AccessTypeView.SelectedEntityChanged += (sender, args) => OnPropertyChanged ();

            _view.OkatoView.OpenClassificator += () => OnPropertyChanged ();
            _view.OktmoView.OpenClassificator += () => OnPropertyChanged ();
            _view.SonoView.OpenClassificator += () => OnPropertyChanged ();
        }

        public void Init ()
        {
            _service.Init ();

            _view.AddressTypeListPresenter.Init ();
            _view.AddressType.Init ();
            _view.AccessType.Init ();
            _view.Flag.Init ();
        }

        public void Refresh (Address address)
        {
            _view.Address = address;

            _view.AddressTypeListPresenter.Refresh (address);
            _view.AddressType.Refresh (address.AddressType);
            _view.Flag.Refresh (address.Flag);
            _view.AccessType.Refresh (address.AccessType);

            _view.AddressName = address.Name;
            _view.Land = address.Land;
            _view.Area = address.Area;
            _view.City = address.City;
            _view.Settlement = address.Settlement;
            _view.Index = address.PostIndex;
            _view.Street = address.Street;
            _view.House = address.House;
            _view.Structure = address.Structure;
            _view.Office = address.Office;
            _view.Description = address.Description;
        }

        private void OnPropertyChanged ()
        {
            if ( _tempAddress == null )
                _tempAddress = new Address ();

            _tempAddress.Id = _view.Address.Id;
            _tempAddress.Name = _view.AddressName;
            _tempAddress.Land = _view.Land;
            _tempAddress.Area = _view.Area;
            _tempAddress.City = _view.City;
            _tempAddress.Settlement = _view.Settlement;
            _tempAddress.PostIndex = _view.Index;
            _tempAddress.Street = _view.Street;
            _tempAddress.House = _view.House;
            _tempAddress.Structure = _view.Structure;
            _tempAddress.Office = _view.Office;
            _tempAddress.Description = _view.Description;

            if ( _view.AddressTypeView.SelectedEntity != null )
                _tempAddress.IdAddressType = ( _view.AddressTypeView.SelectedEntity as AddressType ).Id;

            if ( _view.FlagView.SelectedEntity != null )
                _tempAddress.IdFlag = ( _view.FlagView.SelectedEntity as Flag ).Id;

            if ( _view.AccessTypeView.SelectedEntity != null )
                _tempAddress.IdAccessType = ( _view.AccessTypeView.SelectedEntity as AccessType ).Id;

            if ( _tempAddress.Id == 0 )
                _view.AddressTypesEnable = false;
            else _view.AddressTypesEnable = true;
        }

        private void SaveData ()
        {
            if ( _tempAddress != null )
            {
                if ( _tempAddress.IdFlag == 0 || _tempAddress.IdAddressType == 0 || _tempAddress.IdAccessType == 0 
                    || _tempAddress.Name == string.Empty || _tempAddress.City == string.Empty || _tempAddress.Street == string.Empty
                    || _tempAddress.House == string.Empty)
                {
                    System.Windows.Forms.MessageBox.Show ("Вы не заполнили обязательные поля! См. <*>");
                    return;
                }

                _tempAddress.IdPartner = _view.Address.IdPartner ?? null;
                _tempAddress.IdIndividual = _view.Address.IdIndividual ?? null;
                _tempAddress.IdEntrepreneur = _view.Address.IdEntrepreneur ?? null;

                Refresh (_service.AddOrUpdateEntity (_tempAddress));
            }
        }

        private void DeleteData ()
        {
            if (_view.Address != null)
                _service.RemoveEntity (_view.Address);
        }
    }
}
