﻿using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Menu
{
    public interface IContractorMenuView
    {
        IPresenter Presenter { get; set; }
        ISearchTreeView SearchTreeView { get; }
        SearchTreePresenter SearchTreePresenter { get; }
        string SearchValue { get; }

        event Action NewContractor;
        event Action ShowContractor;
        event Action PrintPhone;
        event Action PrintDataContractor;
        event Action SearchRun;
    }

    public class ContractorMenuPresenter : Common.IPresenter
    {
        IContractorMenuView _view;

        public ContractorMenuPresenter (IContractorMenuView view)
        {
            _view = view;

            _view.NewContractor += () => AddNewContractor ();
            
        }

        public void Init ()
        {
            _view.SearchTreePresenter.Init ();
            _view.SearchTreePresenter.Refresh ();
        }

        private void AddNewContractor ()
        {
            var presenter = new Presenter.ClientPresenter.DialogPresenter (new View.Counterparties.ExtraControls.AddContractorControl (),
                                                                                                 new View.ClientWindow.DialogWindow ());
            presenter.Run ();
        }
    }
}
