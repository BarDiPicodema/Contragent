﻿using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Menu
{
    public interface IAddContractorView : Common.IViewControl
    {
        List<string> Contractors { get; set; }
        string SelectedContractor { get; }
        Form Parent { get; }

        event Action Create;
    }

    public class AddContractorPresenter : Common.IPresenterControl
    {
        IAddContractorView _view;
        Dictionary<string, ContractorTypes> _service;

        public AddContractorPresenter (IAddContractorView view)
        {
            _view = view;
            _service = new Dictionary<string, ContractorTypes> ();

            Refresh ();

            _view.Create += () => CreateContractor (_view.SelectedContractor);
        }

        public void Init ()
        {
        }

        public void Refresh ()
        {
            _service.Clear ();
            _view.Contractors.Clear ();

            var types = Enum.GetValues (typeof (ContractorTypes));
            foreach ( var item in types )
            {
                var field = typeof (ContractorTypes).GetField (item.ToString ());
                DisplayAttribute attribute = Attribute.GetCustomAttribute (field, typeof (DisplayAttribute)) as DisplayAttribute;
                _service.Add (attribute.Name, (ContractorTypes) item);
            }

            _view.Contractors = _service.Keys.ToList ();
        }

        public void CreateContractor (string type)
        {
            var presenterEditor = new EditContractorPresenter (new Bookkeeping.ClientApp.View.Counterparties.EditorWindow ());
            Contractor contractor = null;

            if ( _service[type] == ContractorTypes.Partner )
            {
                var partner = new Partner ();
                partner.IdUser = Model.CurrentUser.User.Id;
                contractor = new Contractor (partner);
            }
            else if ( _service[type] == ContractorTypes.Individual )
            {
                var individual = new Individual ();
                contractor = new Contractor (individual);
            }
            else if ( _service[type] == ContractorTypes.Entrepreneur )
            {
                var entrepreneur = new Entrepreneur ();
                contractor = new Contractor (entrepreneur);
            }

            presenterEditor.Run (contractor);

            _view.Parent.Close ();
        }
    }
}
