﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Counterparties.Menu
{
    public interface IEditorToolView : Common.IViewEditControl
    {
    }

    /// <summary>
    /// Панель добавления и удаления
    /// </summary>
    public class EditorToolPresenter : Common.IPresenterControl
    {
        private IEditorToolView _view;

        public EditorToolPresenter (IEditorToolView view)
        {
            _view = view;
        }

        public void Init ()
        {

        }

        public void Refresh ()
        {

        }
    }
}
