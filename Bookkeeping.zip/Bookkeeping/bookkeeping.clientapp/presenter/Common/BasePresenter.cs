﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Common
{
    public abstract class BasePresenterWindow<TView> : IPresenterWindow where TView : IView
    {
        protected ApplicationContext Context { get; private set; }
        protected TView View { get; private set; }

        public BasePresenterWindow (TView view)
        {
            Context = Bookkeeping.ClientApp.Model.ModelClient.Instance.ClientContext;
            View = view;
        }

        public void Init ()
        {

        }

        public void Run ()
        {
            View.Show ();
        }
    }

    public abstract class BasePresenterWindow<TView, TArgs> : IPresenterWindow<TArgs> where TView : IView
    {
        protected ApplicationContext Context { get; private set; }
        protected TView View { get; private set; }

        protected BasePresenterWindow (TView view)
        {
            Context = Bookkeeping.ClientApp.Model.ModelClient.Instance.ClientContext;
            View = view;
        }

        public abstract void Init ();

        public abstract void Run (TArgs args);
    }


    public abstract class BasePresenterChildrenWindow<TView> : IPresenterWindow where TView : IViewChild
    {
        protected TView View { get; private set; }
        protected IViewParent Parent { get; private set; }

        protected BasePresenterChildrenWindow (TView view)
        {
            View = view;
            Parent = (IViewParent) Model.ModelClient.Instance.ClientContext.MainForm;
        }

        public void Init ()
        {

        }

        public void Run ()
        {
            Parent.ShowChildren (View);
        }
    }

    public abstract class BasePresenterChildrenWindow<TView, TArgs> : IPresenterWindow<TArgs> where TView : IViewChild
    {
        protected TView View { get; private set; }
        protected IViewParent Parent { get; private set; }

        protected BasePresenterChildrenWindow (TView view)
        {
            View = view;
            Parent = (IViewParent) Model.ModelClient.Instance.ClientContext.MainForm;
        }

        public void Init ()
        {

        }

        public abstract void Run (TArgs args);
    }
}
