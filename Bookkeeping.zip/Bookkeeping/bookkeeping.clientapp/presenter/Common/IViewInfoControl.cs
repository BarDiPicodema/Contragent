﻿using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Common
{
    /// <summary>
    /// Интерфейс с событиями сохранить и удалить 
    /// </summary>
    public interface IViewEditControl
    {
        event Action SaveData;
        event Action DeleteData;
    }

    /// <summary>
    /// Интерфейс для вывода данных по адресам, документам и т.п.
    /// </summary>
    public interface IViewInfoControl : IViewControl
    {
        IEntityControlView AccessTypeView { get; }
        EntityPresenter<AccessType> AccessType { get; }
        IEntityControlView FlagView { get; }
        EntityPresenter<Flag> Flag { get; }

        event EventHandler PropertyChanged;
        event Action InfoChange;
    }

    /// <summary>
    /// Интерфейс с полем важность
    /// </summary>
    public interface IViewContractorInfoControl : IViewInfoControl
    {
        IEntityControlView SigningView { get; }
        EntityPresenter<Signing> Signing { get; }
    }

    /// <summary>
    /// Интерфейс для таблиц
    /// </summary>
    public interface IViewTableControl
    {
        IPresenter Presenter { get; set; }

        object DataSource { get; set; }

        event Action SelectedItem;
        event Action AddItem;
        event Action EditItem;
    }


    public interface IViewTreeControl : IViewControl
    {
        object CheckedItem { get; }

        event Action CheckedTreeItem;
        TreeNodeCollection Nodes { get; }
    }
}
