﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Common
{
    /// <summary>
    /// Инициализация для презентеров
    /// </summary>
    public interface IPresenter
    {
        void Init ();
    }

    /// <summary>
    /// Запуск окна
    /// </summary>
    public interface IPresenterWindow : IPresenter
    {
        void Run ();
    }

    /// <summary>
    /// Запуск окна с атрибутом
    /// </summary>
    /// <typeparam name="TArgs"></typeparam>
    public interface IPresenterWindow<TArgs> : IPresenter
    {
        void Run (TArgs args);
    }


    /// <summary>
    /// С методом для обновления данных
    /// </summary>
    public interface IPresenterControl : IPresenter
    {
        void Refresh ();
    }

    /// <summary>
    /// С методом для обновления данных по атрибуту
    /// </summary>
    /// <typeparam name="TArgs"></typeparam>
    public interface IPresenterControl<TArgs> : IPresenter
    {
        void Refresh (TArgs args);
    }

    /// <summary>
    /// Обновление для разных видов контрагентов
    /// </summary>
    public interface IPresenterControlInfo : IPresenter
    {
        void Refresh (Partner partner);
        void Refresh (Individual individual);
        void Refresh (Entrepreneur entrepreneur);
    }


    public interface IPresenterBoxControl<TArgs> : IPresenterControl<TArgs>
    {
        //void SetDisplayProperty (string name);
    }
}
