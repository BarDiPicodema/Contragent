﻿using Bookkeeping.ClientApp.Model.PermissionModel;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Common
{
    public interface IControlPermissionChange
    {
        bool IsEnable { get; set; }

        AccessType AccessType { get; set; }

        event Action SetAccessType;
    }

    public class ControlPermissionChange
    {
        private IControlPermissionChange _view;
        private AccessWritePermission _service;

        public ControlPermissionChange (IControlPermissionChange view, AccessWritePermission service)
        {
            _view = view;
            _service = service;

            _view.SetAccessType += () => SetPermissionWrite (_view.AccessType);
        }

        private void SetPermissionWrite (AccessType access)
        {
            _view.IsEnable = _service.GetPermission (access);
        }
    }
}
