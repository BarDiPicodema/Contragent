﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Presenter.Common
{
    public class Bind<TEntity>
    {
        public TEntity Entity { get; private set; }
        
        public Bind ( TEntity entity)
        {

        }
    }

    public class BindingProperty
    {

        public BindingProperty ()
        {

        }

        public void UpdateProperty ()
        {

        }
    }
}
