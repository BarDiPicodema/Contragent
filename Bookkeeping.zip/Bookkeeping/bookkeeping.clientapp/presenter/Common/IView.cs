﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Presenter.Common
{
    public interface IView
    {
        void Show ();
        void Hide ();
        void Close ();
    }

    public interface IViewParent : IView
    {
        void ShowChildren (IViewChild view);
    }

    public interface IViewChild : IView
    {
    }

    /// <summary>
    /// Контрол со своим Презентером
    /// </summary>
    public interface IViewControl
    {
        IPresenter Presenter { get; set; }
    }
}
