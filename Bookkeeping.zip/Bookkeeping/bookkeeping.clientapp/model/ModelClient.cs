﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data;
using Bookkeeping.DataAccess;
using Bookkeeping.ClientApp.Model.Common;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.Model
{
    public class ModelClient
    {
        private static ModelClient _instance;
        public static ModelClient Instance
        {
            get
            {
                if ( _instance == null )
                    _instance = new ModelClient ();
                return _instance;
            }
        }

        private CrudLoader _loader;

        public readonly ApplicationContext ClientContext;
        public readonly BookkeepingContext DataContext;

        private ModelClient ()
        {
            ClientContext = new ApplicationContext ();
            DataContext = new BookkeepingContext ("Bookkeeping");
            Bookkeeping.Data.EF.IncludeDataHelper.Init (typeof (BookkeepingContext).Assembly);
        }

        public NomenclatureService Service 
        { 
            get 
            { 
                if (_loader == null)
                    _loader = new CrudLoader (DataContext);
                return _loader.Service; 
            } 
        }
    }
}
