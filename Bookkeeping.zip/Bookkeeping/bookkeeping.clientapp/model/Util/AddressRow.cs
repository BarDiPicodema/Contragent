﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using System.Drawing;
using System.ComponentModel;

namespace Bookkeeping.ClientApp.Model.Util
{
    public class AddressRow
    {
        public AddressRow (Address address)
        {
            _address = address;
        }

        private Address _address;
        public Address Address { get { return _address; } }

       // public Bitmap FlagImage { get { return (_address.Flag.TypeImage) ? (Bitmap) TypeDescriptor.GetConverter (typeof (Bitmap)).ConvertFrom (_address.Flag.TypeImage) : null; } }
        public string TypeName { get { return _address.AccessType.TypeName; } }
        public string PostIndex { get { return _address.PostIndex; } }
        public string Land { get { return _address.Land; } }
        public string City { get { return _address.City; } }
        public string Settlement { get { return _address.Settlement; } }
        public string Street { get { return _address.Street; } }
        public string House { get { return _address.House; } }
        public string Structure { get { return _address.Structure; } }
        public string Porch { get { return _address.Porch; } }
        public string Office { get { return _address.Office; } }
        public string Note { get { return _address.Description; } }
    }
}
