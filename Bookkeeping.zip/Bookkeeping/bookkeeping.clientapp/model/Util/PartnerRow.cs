﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Util
{
    public class PartnerRow
    {
        public PartnerRow (Partner partner)
        {
            _partner = partner;
        }

        private Partner _partner;
        public Partner Partner { get { return _partner; } }


    }
}
