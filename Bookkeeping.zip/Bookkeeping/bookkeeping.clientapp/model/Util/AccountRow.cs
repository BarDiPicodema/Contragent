﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using System.Drawing;
using System.ComponentModel;

namespace Bookkeeping.ClientApp.Model.Util
{
    public class AccountRow
    {
        public AccountRow (Account account)
        {
            _account = account;
        }

        private Account _account;
        public Account Account { get { return _account; } }

       // public Bitmap FlagImage { get { return ( _account.Flag.TypeImage ) ? (Bitmap) TypeDescriptor.GetConverter (typeof (Bitmap)).ConvertFrom (_account.Flag.TypeImage) : null; } }
        public string TypeName { get { return _account.AccountType.TypeName;} }
        public string KindName { get { return _account.AccountKind.TypeName; } }
        public string AccountNumber { get { return _account.AccountNumber; } }
        public string OkvName { get { return _account.Okv.CharCode; } }
        public string Note { get { return _account.Description; } }
    }
}
