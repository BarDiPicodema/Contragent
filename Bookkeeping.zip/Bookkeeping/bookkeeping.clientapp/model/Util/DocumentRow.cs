﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using System.Drawing;
using System.ComponentModel;

namespace Bookkeeping.ClientApp.Model.Util
{
    public class DocumentRow
    {
        public DocumentRow (Document document)
        {
            _document = document;
        }

        private Document _document;
        public Document Document { get { return _document; } }

        //public Bitmap FlagImage { get { return ( _document.Flag.TypeImage ) ? (Bitmap) TypeDescriptor.GetConverter (typeof (Bitmap)).ConvertFrom (_document.Flag.TypeImage) : null; } }
        public string TypeName { get { return _document.DocumentType.TypeName; } }
        public string DocumentName { get { return _document.Name; } }
        public string Note { get { return _document.Description; } }
    }
}
