﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using System.Drawing;
using System.ComponentModel;

namespace Bookkeeping.ClientApp.Model.Util
{
    public class ContactRow
    {
        public ContactRow (Contact contact)
        {
            _contact = contact;
        }

        private Contact _contact;
        public Contact Contact { get { return _contact; } }

        //public Bitmap FlagImage { get { return ( _contact.Flag.TypeImage ) ? (Bitmap) TypeDescriptor.GetConverter (typeof (Bitmap)).ConvertFrom (_contact.Flag.TypeImage) : null; } }
        public string TypeName { get { return _contact.ContactType.TypeName; } }
        public string ContactText { get { return _contact.ContactText; } }
        public string ContactName { get { return _contact.Name; } }
        public string Sub { get { return _contact.Sub; } }
        public string Post { get { return _contact.Post; } }
        public string Note { get { return _contact.Description; } }
    }
}
