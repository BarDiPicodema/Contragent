﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model
{
    public static class CurrentUser
    {
        private static User _user;
        public static User User
        {
            get { return _user; }
            set
            {
                _user = value;
                AccessTypes = GetAccessTypes ();
            }
        }

        public static Departament Departament { get { return _user.Departament; } }
        public static UserGrant Grant { get { return _user.UserGrant; } }
        public static IList<AccessType> AccessTypes { get; set; }

        private static List<AccessType> GetAccessTypes ()
        {
            List<AccessType> accessTypes = new List<AccessType> ();
            var accessCrud = new Bookkeeping.ClientApp.Model.PermissionModel.AccessTypeService ();
            accessTypes.Add (GetOverallAccessType (accessCrud.Service));
            accessTypes.Add (GetPrivateAccessType (accessCrud.Service));
            accessTypes.Add (GetPersonAccessType (accessCrud.Service));
            accessTypes.Add (GetDepartamentAccessType (accessCrud.Service));
            accessTypes.AddRange (accessCrud.GetAccessTypeFromUser (_user));
            return accessTypes;
        }

        private static AccessType GetOverallAccessType (ServiceModel<AccessType> accessCrud)
        {
            var accessOverall = accessCrud.FindEntity (item => item.TypeName == "Всем");
            if ( accessOverall == null )
                accessOverall = accessCrud.AddOrUpdateEntity (new AccessType () { TypeName = "Всем" });
            return accessOverall;
        }

        private static AccessType GetPrivateAccessType (ServiceModel<AccessType> accessCrud)
        {
            var accessOverall = accessCrud.FindEntity (item => item.TypeName == "Личное" + " (" + _user.Name + ")" && item.IdUser == _user.Id && item.IsPrivate == true);
            if ( accessOverall == null )
                accessOverall = accessCrud.AddOrUpdateEntity (new AccessType () { TypeName = "Личное" + " (" + _user.Name + ")", IdUser = _user.Id, IsPrivate = true, IdDepartament = Departament.Id });
            return accessOverall;
        }

        private static AccessType GetPersonAccessType (ServiceModel<AccessType> accessCrud)
        {
            var accessOverall = accessCrud.FindEntity (item => item.TypeName == "Персональное" + " (" + _user.Name + ")" && item.IdUser == _user.Id && item.IdDepartament == Departament.Id && item.IsPrivate == false);
            if ( accessOverall == null )
                accessOverall = accessCrud.AddOrUpdateEntity (new AccessType () { TypeName = "Персональное" + " (" + _user.Name + ")", IdUser = _user.Id, IdDepartament = Departament.Id, IsPrivate = false });
            return accessOverall;
        }

        private static AccessType GetDepartamentAccessType (ServiceModel<AccessType> accessCrud)
        {
            var accessOverall = accessCrud.FindEntity (item => item.TypeName == "По отделу" + " (" + Departament.NameDepartament + ")" && item.IdDepartament == Departament.Id);
            if ( accessOverall == null )
                accessCrud.AddOrUpdateEntity (new AccessType () { TypeName = "По отделу" + " (" + Departament.NameDepartament + ")", IdDepartament = Departament.Id });
            return accessOverall;
        }
    }
}
