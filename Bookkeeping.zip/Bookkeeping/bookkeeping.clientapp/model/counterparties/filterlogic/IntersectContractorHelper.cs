﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic
{
    public static class IntersectContractorHelper
    {
        public static IList<TEntity> Intersect<TEntity> (this IList<TEntity> contractorsOne, IList<TEntity> contractorsTwo)
            where TEntity : Data.IEntity, Data.Interface.ICounterparties
        {
            var result = new List<TEntity> ();

            foreach (var contractor in contractorsOne)
                foreach (var item in contractorsTwo)
                    if (item.Id == contractor.Id)
                    {
                        result.Add (contractor);
                    }

            return result;
        }
    }
}
