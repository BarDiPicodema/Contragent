﻿using Bookkeeping.ClientApp.Model.DatabaseReflection;
using Bookkeeping.Data.EntityHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic
{
    public enum QueryType
    {
        QuerySelect,
        QueryJoin,
        QueryWhere
    }

    public class QueryNodeString : ICloneable
    {
        public string Node { get; set; }
        public QueryType TypeQuery { get; private set; }
        
        private string _firstColumn;
        private string _secondColumn;
        
        public string RelationField { get; private set; }
        
        /// <summary>
        /// Example: SELECT table.* FROM table
        /// </summary>
        /// <param name="table"></param>
        public QueryNodeString (ElementNode table)
        {
            Node = " SELECT " + table.ReadebleName.ToUpper() + ".* FROM " + table.ReadebleName.ToUpper() +" ";
            TypeQuery = QueryType.QuerySelect;
        }

        /// <summary>
        /// Example: SELECT table.* FROM table
        /// </summary>
        /// <param name="table"></param>
        public QueryNodeString (string table)
        {
            Node = " SELECT " + table.ToUpper () + ".* FROM " + table.ToUpper()+" ";
            TypeQuery = QueryType.QuerySelect;
        }

        public QueryNodeString (ElementNode firstNode, ElementNode secondNode)
        {
            if ( firstNode.TypeProperty == TypeProperty.TableProperty && secondNode.TypeProperty == TypeProperty.TableProperty )
            {
                CreateRelation (firstNode.Property, secondNode.Property);

                if ( _firstColumn == null || _secondColumn == null )
                    return;

                Node = " INNER JOIN " + NameColumnUpdate(secondNode.ReadebleName) + " ON " + NameColumnUpdate (_firstColumn)
                                                + " = " + NameColumnUpdate (_secondColumn)+" ";

                TypeQuery = QueryType.QueryJoin;
            }
            else if ( firstNode.TypeProperty == TypeProperty.TableProperty && secondNode.TypeProperty == TypeProperty.ColumnProperty )
            {
                if (firstNode.ReadebleName == null)
                {
                    throw new NullReferenceException ("Значение первого узла равно null");
                }
                else if ( secondNode.ReadebleName == null )
                {
                    throw new NullReferenceException ("Значение второго узла равно null");
                }

                RelationField = NameColumnUpdate (firstNode.ReadebleName) + "." + NameColumnUpdate (secondNode.ReadebleName);
                Node = " WHERE UPPER(" + RelationField + ") = {0}";
                TypeQuery = QueryType.QueryWhere;
            }
        }

        public QueryNodeString (QueryNode query)
        {
            if ( query.SqlQueryNode.Contains ("WHERE") == true )
                TypeQuery = QueryType.QueryWhere;
            else if ( query.SqlQueryNode.Contains ("SELECT") == true )
                TypeQuery = QueryType.QuerySelect;
            else if ( query.SqlQueryNode.Contains ("JOIN") == true )
                TypeQuery = QueryType.QueryJoin;

            Node = query.SqlQueryNode;
        }

        private void CreateRelation (PropertyInfo firstTable, PropertyInfo secondTable)
        {
            var firstTableName = GetType (firstTable);
            var secondTableName = GetType (secondTable);
            var relation = GetRelation (firstTable, secondTable);
            if ( relation == null )
                relation = GetRelation (secondTable, firstTable);
            if ( relation != null )
                RelationField = relation.Name;
        }

        private Type GetType (PropertyInfo property)
        {
            if (property.PropertyType.IsGenericType)
                return property.PropertyType.GetGenericArguments ().Single();
            return null;
        }

        private string NameColumnUpdate (string property)
        {
            return property.ToUpper ();
        }

        private PropertyInfo GetRelation (PropertyInfo first, PropertyInfo second)
        {
            string primaryKey = "Id";

            var generic = second.PropertyType.GetGenericArguments();
            if ( generic.Any () )
                primaryKey += generic.Single ().Name;

            var property = first.PropertyType.GetGenericArguments().Single().GetProperty(primaryKey);
            if ( property != null )
            {
                _firstColumn = first.Name + "." + primaryKey;
                _secondColumn = second.Name + "." + "id";
                return property;
            }
            else return null;
        }


        public object Clone ()
        {
            return this.MemberwiseClone ();
        }
    }
}
