﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters
{
    public class FilterProgram<TEntity> : AbstractFilter<TEntity>
        where TEntity : class, Data.IEntity, Data.Interface.ICounterparties
    {
        private IFilterRule _rule;

        public FilterProgram (IFilterRule rule)
        {
            _rule = rule;
            Name = _rule.NameRule;

            Counterparties = new List<TEntity> ();
            Values = new List<AbstractFilterValue> ();
        }

        public override void Execute ()
        {
            Counterparties = _rule.Filter<TEntity> (Counterparties, SelectedValues);
        }
    }
}
