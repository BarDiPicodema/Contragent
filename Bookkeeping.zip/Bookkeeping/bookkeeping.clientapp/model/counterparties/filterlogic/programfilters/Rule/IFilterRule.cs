﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters
{
    /// <summary>
    /// Интерфейс с операцией выполнения фильтрации
    /// </summary>
    public interface IFilterRule
    {
        string NameRule { get; }

        IList<TEntity> Filter<TEntity> (IList<TEntity> counterparties, IList<AbstractFilterValue> values)
            where TEntity : class, Data.IEntity, ICounterparties;
    }
}
