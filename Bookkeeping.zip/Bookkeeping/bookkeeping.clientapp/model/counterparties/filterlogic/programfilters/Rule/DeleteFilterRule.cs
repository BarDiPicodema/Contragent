﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Rule
{
    public class DeleteFilterRule : IFilterRule
    {
        public DeleteFilterRule ()
        {
        }

        public string NameRule { get { return "По удаленным"; } }

        public IList<TEntity> Filter<TEntity> (IList<TEntity> counterparties, IList<AbstractFilterValue> values)
            where TEntity : class, Data.IEntity, ICounterparties
        {
            if ( counterparties == null && counterparties.Any () || values == null )
                return counterparties;

            IList<TEntity> temp = new List<TEntity> ();
            foreach ( var entity in counterparties )
                foreach ( var value in values )
                {
                    if ( entity.IsDelete == ( value as DeleteValue ).GetValue () )
                        temp.Add ((TEntity) entity);
                }
            return temp;
        }
    }
}
