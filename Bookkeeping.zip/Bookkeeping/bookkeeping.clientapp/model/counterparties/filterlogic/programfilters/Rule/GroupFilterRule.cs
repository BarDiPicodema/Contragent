﻿using Bookkeeping.Data.Entities;
using Bookkeeping.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Rule
{
    public class GroupFilterRule : IFilterRule
    {
        public GroupFilterRule (ICrudService<Group> group, ICrudService<GroupTypeToType> groupTypeToType)
        {
            _groupService = group;
            _groupTypeToTypeService = groupTypeToType;
        }

        private ICrudService<Group> _groupService;
        private ICrudService<GroupTypeToType> _groupTypeToTypeService;

        public string NameRule { get { return "По группам"; } }


        private IList<Group> GetGroupFromContractor<TEntity> (TEntity entity) where TEntity : class, Data.IEntity, Data.Interface.ICounterparties
        {
            IList<Group> groups = new List<Group> ();

            if ( typeof (TEntity) == typeof (Partner) )
                groups = _groupService.GetList (item => item.IdPartner == entity.Id);
            else if ( typeof (TEntity) == typeof (Individual) )
                groups = _groupService.GetList (item => item.IdIndividual == entity.Id);
            else if ( typeof (TEntity) == typeof (Entrepreneur) )
                groups = _groupService.GetList (item => item.IdEntrepreneur == entity.Id);

            return groups;
        }

        private bool IsGroupTypeFromContractor (GroupTypeToType typeToType, GroupType type)
        {
            if ( typeToType == null || type == null )
                throw new ArgumentNullException ();

            if ( typeToType.IdGroupTypeOne == type.Id )
                return true;
            else
            {
                var parentTypeToType = _groupTypeToTypeService.Find (item => item.IdGroupTypeTwo == typeToType.IdGroupTypeOne);
                if ( parentTypeToType != null )
                    return IsGroupTypeFromContractor (parentTypeToType, type);
            }
            return false;
        }

        public IList<TEntity> Filter<TEntity> (IList<TEntity> counterparties, IList<AbstractFilterValue> values) 
            where TEntity : class, Data.IEntity, Data.Interface.ICounterparties
        {
            if ( counterparties == null && counterparties.Any () || values == null )
                return counterparties;

            IList<TEntity> temp = new List<TEntity> ();
            foreach ( TEntity entity in counterparties )
            {
                var groups = GetGroupFromContractor<TEntity> (entity);
                foreach ( var group in groups )
                {
                    var groupTypeToType = _groupTypeToTypeService.Find (item => item.Id == group.IdGroupTypeToType);
                    foreach ( var value in values )
                    {
                        var type = ( value.Value as GroupType );
                        if ( groupTypeToType.IdGroupTypeTwo == type.Id || IsGroupTypeFromContractor (groupTypeToType, type) )
                            temp.Add (entity);
                    }
                }
            }
            return temp;
        }
    }
}
