﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Rule
{
    public class CuratorFilterRule : IFilterRule
    {
        public CuratorFilterRule ()
        {
        }

        public string NameRule { get { return "По куратору"; } }

        public IList<TEntity> Filter<TEntity> (IList<TEntity> counterparties, IList<AbstractFilterValue> values)
            where TEntity : class, Data.IEntity, Data.Interface.ICounterparties
        {
            if ( counterparties == null && counterparties.Any () || values == null )
                return counterparties;

            IList<TEntity> temp = new List<TEntity> ();
            foreach ( TEntity item in counterparties )
                foreach ( var value in values )
                {
                    var partner = item as Partner;
                    if ( partner != null )
                        if ( partner.IdUser == ( value.Value as User ).Id )
                            temp.Add (item);
                }
            return temp;
        }
    }
}
