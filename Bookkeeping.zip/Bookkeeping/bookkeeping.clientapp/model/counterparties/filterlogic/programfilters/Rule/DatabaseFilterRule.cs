﻿using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Value;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Rule
{
    public class DatabaseFilterRule<TEntity> : IFilterRule 
        where TEntity : class, Data.IEntity, Data.Interface.ICounterparties
    {
        public DatabaseFilterRule (AccessServiceModel<TEntity> service, Filter filter)
        {
            _service = service;
            _service.Init ();

            _filter = filter;
        }

        private AccessServiceModel<TEntity> _service;
        private Filter _filter;

        public string NameRule { get { return _filter.NameFilter; } }

        public IList<TEntity> Filter<TEntity> (IList<TEntity> counterparties, IList<AbstractFilterValue> values)
            where TEntity : class, Data.IEntity, Data.Interface.ICounterparties
        {
            var generator = new QueryManager (new FilterGenerate (":p"));
            foreach ( var item in _filter.QueryNodes )
            {
                if ( typeof (TEntity) == typeof (Partner) && item.SqlQueryNode.Contains ("PARTNERS"))
                    generator.AddNode (item);
                else if ( typeof (TEntity) == typeof (Individual) && item.SqlQueryNode.Contains ("INDIVIDUALS") )
                    generator.AddNode (item);
                else if (typeof (TEntity) == typeof (Entrepreneur) && item.SqlQueryNode.Contains ("ENTREPRENEURS"))
                    generator.AddNode (item);

                if ( !item.SqlQueryNode.Contains ("PARTNERS") && !item.SqlQueryNode.Contains ("INDIVIDUALS") && !item.SqlQueryNode.Contains ("ENTREPRENEURS") )
                    generator.AddNode (item);
            }

            IList<TEntity> temp = new List<TEntity> ();
            var query = generator.GenerateSQLQuery ();

            foreach ( DatabaseValue value in values )
                foreach ( var item in _service.GetEntitiesFromSQLQuery (query, value.Value) )
                    temp.Add (item as TEntity);

            return temp;
        }
    }
}
