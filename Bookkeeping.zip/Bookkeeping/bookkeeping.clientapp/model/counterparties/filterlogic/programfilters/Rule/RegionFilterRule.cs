﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Rule
{
    public class RegionFilterRule : IFilterRule
    {
        public RegionFilterRule ()
        {
        }

        public string NameRule { get { return "По регионам"; } }

        public IList<TEntity> Filter<TEntity> (IList<TEntity> counterparties, IList<AbstractFilterValue> values)
            where TEntity : class, Data.IEntity, Data.Interface.ICounterparties
        {
            IList<TEntity> temp = new List<TEntity> ();
            foreach ( var item in counterparties )
                foreach ( var value in values )
                    foreach ( var address in item.Addresses )
                        if ( address.IdOkato == ( value.Value as Okato ).Id )
                            temp.Add (item);
            return temp;
        }
    }
}
