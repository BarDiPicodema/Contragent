﻿using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Rule
{
    public class SigningFilterRule : IFilterRule
    {
        public SigningFilterRule ()
        {
        }

        public string NameRule { get { return "По важности"; } }

        public IList<TEntity> Filter<TEntity> (IList<TEntity> counterparties, IList<AbstractFilterValue> values)
            where TEntity : class, Data.IEntity, ICounterparties
        {
            if ( counterparties == null || values == null )
                return null;

            IList<TEntity> temp = new List<TEntity> ();
            foreach ( TEntity entity in counterparties )
                foreach ( var value in values )
                    if ( entity.IdSigning == ( value as SigningValue ).GetValue().Id )
                        temp.Add (entity);
            return temp;
        }
    }
}
