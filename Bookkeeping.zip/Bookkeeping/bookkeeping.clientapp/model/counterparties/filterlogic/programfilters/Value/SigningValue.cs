﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters
{
    public class SigningValue : AbstractFilterValue
    {
        public SigningValue (Signing value)
        {
            if ( value == null )
                return;

            _value = value;
            Name = value.TypeName;
        }

        public Signing GetValue ()
        {
            return _value as Signing;
        }
    }
}
