﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Value
{
    public class GroupValue : AbstractFilterValue
    {
        public GroupValue (GroupType value)
        {
            _value = value;
            Name = value.TypeName;
        }

        public GroupType GetValue ()
        {
            return (GroupType) _value;
        }
    }
}
