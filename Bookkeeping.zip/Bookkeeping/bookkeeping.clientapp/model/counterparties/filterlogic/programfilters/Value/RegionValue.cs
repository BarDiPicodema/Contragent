﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters
{
    public class RegionValue : AbstractFilterValue
    {
        public RegionValue (Okato value)
        {
            if ( value == null )
                return;

            _value = value;
            Name = value.Region;
        }

        public Okato GetValue ()
        {
            return _value as Okato;
        }
    }
}
