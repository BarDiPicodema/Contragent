﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters
{
    public class DeleteValue : AbstractFilterValue
    {
        public DeleteValue (StateEntity isDelete)
        {
            if ( isDelete == null )
                return;

            _value = isDelete;

            var field = typeof (StateEntity).GetField (isDelete.ToString ());
            DisplayAttribute attribute = Attribute.GetCustomAttribute (field, typeof (DisplayAttribute)) as DisplayAttribute;
            if ( attribute != null )
                Name = attribute.Name;
        }

        public StateEntity GetValue ()
        {
            return (StateEntity) _value;
        }
    }
}
