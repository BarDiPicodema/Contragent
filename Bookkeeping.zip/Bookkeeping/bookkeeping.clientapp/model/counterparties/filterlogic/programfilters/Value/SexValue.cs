﻿using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters
{
    public class SexValue : AbstractFilterValue
    {
        public SexValue (Sex sex)
        {
            _value = sex;

            var field = typeof (Sex).GetField (sex.ToString ());
            DisplayAttribute attribute = Attribute.GetCustomAttribute (field, typeof (DisplayAttribute)) as DisplayAttribute;
            if ( attribute != null )
                Name = attribute.Name;
        }

        public Sex GetValue ()
        {
            return (Sex) _value;
        }
    }
}
