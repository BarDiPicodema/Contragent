﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Value
{
    public class DatabaseValue : AbstractFilterValue
    {
        public DatabaseValue (string value)
        {
            _value = value;
            Name = value;
        }

        public string GetValue ()
        {
            return _value as string;
        }
    }
}
