﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters
{
    public class CuratorValue : AbstractFilterValue
    {
        public CuratorValue (User value)
        {
            if ( value == null )
                return;

            _value = value;
            Name = value.Login;
        }
    }
}
