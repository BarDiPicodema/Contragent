﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator
{
    public class SearchGenerate : IBehaviorGeneration
    {
        private string _parameter;

        /// <summary>
        /// Генератор поисковых запросов
        /// </summary>
        /// <param name="parameter"> sql параметр entity framework</param>
        public SearchGenerate (string parameter)
        {
            _parameter = parameter;
        }

        /// <summary>
        /// разбавляет запрос where оператором Like('%:p0%')
        /// приводит его параметры в пригодное для EF состояние
        /// </summary>
        /// <param name="whereCommands"></param>
        /// <returns></returns>
        public IList<QueryNodeString> WhereCommandCompile (IList<QueryNodeString> whereCommands)
        {
            IList<QueryNodeString> commandPartWhere = new List<QueryNodeString> ();

            for ( int i = 0, count = whereCommands.Count; i < count; i++ )
            {
                var temp = whereCommands.ElementAt (i).Clone () as QueryNodeString;

                temp.Node = string.Format (temp.Node + " OR UPPER({1}) LIKE ('%{2}%') ", _parameter, temp.RelationField, "{0}");
                if ( i != 0 )
                    temp.Node = temp.Node.Replace ("WHERE", " OR ") + string.Format (" OR UPPER({1}) LIKE('%{2}%') ", _parameter, temp.RelationField, "{0}");

                commandPartWhere.Add (temp);
            }

            return commandPartWhere;
        }
    }
}
