﻿using Bookkeeping.Data.EntityHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator
{
    public class QueryManager
    {
        private IBehaviorGeneration _generate;

        public IList<QueryNodeString> Nodes { get; private set; }
        IList<object> _values;
        public object[] Values { get { return _values.ToArray (); } }

        public bool Any () 
        {
            if (Nodes.Any () && _values.Any ()) 
                return true;
            return false;
        }

        public QueryManager (IBehaviorGeneration generate)
        {
            _generate = generate;
            Nodes = new List<QueryNodeString> ();
            _values = new List<object> ();
        }

        public void AddNode (QueryNode node)
        {
            Nodes.Add (new QueryNodeString (node));
        }

        public void AddNode (params QueryNodeString[] queries)
        {
            foreach (var query in queries)
                Nodes.Add (query);
        }

        public void AddValue (params object[] values)
        {
            foreach (var value in values)
                _values.Add (value);
        }

        public void ClearNodes ()
        {
            Nodes.Clear ();
        }

        public void ClearValues ()
        {
            _values.Clear ();
        }

        public string GenerateSQLQuery ()
        {
            var nodes = Nodes;

            var commandSorted = GetCommandsFromType (QueryType.QuerySelect, ref nodes).ToList();
            commandSorted.AddRange (GetCommandsFromType (QueryType.QueryJoin, ref nodes).ToList());
            var whereCommand = GetCommandsFromType (QueryType.QueryWhere, ref nodes).ToList();

            commandSorted.AddRange( _generate.WhereCommandCompile (whereCommand));

            string command = " ";
            foreach ( var item in commandSorted )
                command += item.Node;
            return command;
        }

        protected ICollection<QueryNodeString> GetCommandsFromType (QueryType type, ref IList<QueryNodeString> nodes)
        {
            var commands = new HashSet<QueryNodeString> ();
            foreach ( var item in nodes )
                if ( item.TypeQuery == type )
                    commands.Add (item);
            
            if ( type == QueryType.QueryJoin )
                return commands.Reverse ().ToList ();

            return commands;
        }
    }
}
