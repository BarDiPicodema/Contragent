﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator
{
    public class FilterGenerate : IBehaviorGeneration
    {
        private string _parameter;

        /// <summary>
        /// Генератор фильтр-запросов
        /// </summary>
        /// <param name="parameter">sql параметр entity framework</param>
        public FilterGenerate (string parameter)
        {
            _parameter = parameter;
        }

        public IList<QueryNodeString> WhereCommandCompile (IList<QueryNodeString> whereCommands)
        {
            IList<QueryNodeString> commandPartWhere = new List<QueryNodeString> ();

            for ( int i = 0, count = whereCommands.Count; i < count; i++ )
            {
                var temp = whereCommands.ElementAt (i);
                temp.Node = string.Format (temp.Node, _parameter+i.ToString());

                if ( i != 0 )
                {
                    temp.Node = temp.Node.Replace ("WHERE", " AND ");
                }

                commandPartWhere.Add (temp);
            }

            return commandPartWhere;
        }
    }
}
