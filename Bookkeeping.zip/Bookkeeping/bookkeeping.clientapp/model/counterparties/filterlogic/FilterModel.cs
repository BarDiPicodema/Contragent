﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;
using Bookkeeping.DataAccess.Interfaces;
using Bookkeeping.Data.Interface;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic
{
    public class FilterModel
    {
        public FilterModel ()
        {
            PartnerFilters = new FilterManager<Partner> ();
            EntrepreneurFilters = new FilterManager<Entrepreneur> ();
            IndividualFilters = new FilterManager<Individual> ();
        }

        public FilterManager<Partner> PartnerFilters { get; private set; }
        public FilterManager<Entrepreneur> EntrepreneurFilters { get; private set; }
        public FilterManager<Individual> IndividualFilters { get; private set; }

        public ICrudService<Filter> Filters { get { return ModelClient.Instance.Service.Filters; } }
        public ICrudService<QueryNode> QueryNodes { get { return ModelClient.Instance.Service.QueryNodes; } }
        public ICrudService<FilterValue> FilterValues { get { return ModelClient.Instance.Service.FilterValues; } }

        /// <summary>
        /// Загрузка стандартных фильтров
        /// </summary>
        public void LoadProgramFilters ()
        {
            PartnerFilters.InitFilter<Partner> ();
            EntrepreneurFilters.InitFilter<Entrepreneur> ();
            IndividualFilters.InitFilter<Individual> ();
        }

        /// <summary>
        /// Загрузка дополнительных фильтров
        /// </summary>
        public void LoadDatabaseFilters ()
        {
            var partnerService = new AccessServiceModel<Partner> ();
            var individualService = new AccessServiceModel<Individual> ();
            var entrepreneurService = new AccessServiceModel<Entrepreneur> ();

            foreach ( var filter in Filters.All )
            {
                List<FilterValue> values = new List<FilterValue> ();
                List<QueryNode> nodes = new List<QueryNode> ();
                foreach (var node in filter.QueryNodes)
                {
                    var temp = QueryNodes.Find (item => item.Id == node.Id);
                    nodes.Add (temp);
                    var value = FilterValues.GetList (item => item.IdQueryNode == temp.Id);
                    values.AddRange (value);
                }

                switch ( filter.Table )
                {
                    case "Partners":
                        PartnerFilters.InitializeDatabaseFilters<Partner> (partnerService, filter, values.ToArray ());
                        break;
                    case "Individuals":
                        IndividualFilters.InitializeDatabaseFilters<Individual> (individualService, filter, values.ToArray ());
                        break;
                    case "Entrepreneurs":
                        EntrepreneurFilters.InitializeDatabaseFilters<Entrepreneur> (entrepreneurService, filter, values.ToArray ());
                        break;
                    default :
                        PartnerFilters.InitializeDatabaseFilters<Partner> (partnerService, filter, values.ToArray ());
                        IndividualFilters.InitializeDatabaseFilters<Individual> (individualService, filter, values.ToArray ());
                        EntrepreneurFilters.InitializeDatabaseFilters<Entrepreneur> (entrepreneurService, filter, values.ToArray ());
                        break;
                }
            }
        }
    }
}
