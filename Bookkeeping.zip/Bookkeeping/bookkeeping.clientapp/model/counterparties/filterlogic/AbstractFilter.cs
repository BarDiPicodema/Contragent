﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Interface;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic
{
    public abstract class AbstractFilter<TEntity> where TEntity : class, Data.IEntity, ICounterparties
    {
        public string Name { get; set; }

        public IList<TEntity> Counterparties { get; set; }
        public IList<AbstractFilterValue> Values { get; set; }

        protected IList<AbstractFilterValue> SelectedValues { get; set; }

        public AbstractFilter ()
        {
            Counterparties = new List<TEntity> ();
            Values = new List<AbstractFilterValue> ();
        }

        public virtual void SetValue (params AbstractFilterValue[] values)
        {
            SelectedValues = values.ToList ();
        }

        public abstract void Execute ();
    }
}
