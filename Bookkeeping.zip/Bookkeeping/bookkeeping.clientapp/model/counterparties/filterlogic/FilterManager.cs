﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Interface;
using System.Collections;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic
{
    public class FilterManager<TEntity> where TEntity : class, Data.IEntity, ICounterparties
    {
        private IDictionary<string, AbstractFilter<TEntity>> _filterDictionary;

        public FilterManager ()
        {
            _filterDictionary = new Dictionary<string, AbstractFilter<TEntity>> ();
        }

        public void AddFilter (AbstractFilter<TEntity> filter)
        {
            _filterDictionary.Add (filter.Name, filter);
        }

        public AbstractFilter<TEntity> GetFilter (string key)
        {
            if ( _filterDictionary.ContainsKey (key) )
                return _filterDictionary[key];
            return null;
        }

        public IList<AbstractFilter<TEntity>> GetFilters ()
        {
            IList<AbstractFilter<TEntity>> filters = new List<AbstractFilter<TEntity>> ();
            foreach ( var item in _filterDictionary.Keys )
                filters.Add (_filterDictionary[item]);
            return filters;
        }

        public IList<AbstractFilter<TEntity>> GetFiltersDatabase ()
        {
            IList<AbstractFilter<TEntity>> filters = new List<AbstractFilter<TEntity>> ();
            foreach ( var item in _filterDictionary.Keys )
                filters.Add (_filterDictionary[item]);
            return filters;
        }

        public IEnumerator<AbstractFilter<TEntity>> GetEnumerator ()
        {
            return _filterDictionary.Values.GetEnumerator ();
        }
    }
}
