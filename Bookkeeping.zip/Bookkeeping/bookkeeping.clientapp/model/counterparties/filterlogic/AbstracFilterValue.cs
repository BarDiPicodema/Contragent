﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic
{
    public abstract class AbstractFilterValue
    {
        protected object _value;
        public object Value { get { return _value; } }
        public string Name { get; protected set; }

        public AbstractFilterValue ()
        {

        }
    }
}
