﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;
using Bookkeeping.DataAccess;
using Bookkeeping.Data.Interface;
using Bookkeeping.DataAccess.Interfaces;
using Bookkeeping.Data;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Rule;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.ProgramFilters.Value;

namespace Bookkeeping.ClientApp.Model.Counterparties.FilterLogic
{
    public static class FilterInitializer 
    {
        private static NomenclatureService _services = ModelClient.Instance.Service;

        public static FilterManager<TEntity> InitFilter<TEntity> (this FilterManager<TEntity> manager) where TEntity : class, Data.IEntity, ICounterparties
        {
            InitializedProgramFilters<TEntity> (manager);

            if ( typeof (TEntity) == typeof (Partner) )
                InitializePartnerFilters<TEntity> (manager);
            if ( typeof (TEntity) == typeof (Individual) )
                InitializeIndividualFilters<TEntity> (manager);
            return manager;
        }

        /// <summary>
        /// Инициализация фильтров программы
        /// </summary>
        private static void InitializedProgramFilters<TEntity> (FilterManager<TEntity> manager) where TEntity : class, Data.IEntity, ICounterparties 
        {
            var access = new FilterProgram<TEntity> (new AccessFilterRule ());
            foreach ( var item in CurrentUser.AccessTypes )
                access.Values.Add (new AccessValue (item));
            manager.AddFilter (access);

            var delete = new FilterProgram<TEntity> (new DeleteFilterRule ());
            foreach ( var item in Enum.GetValues (typeof (StateEntity)).Cast<StateEntity> () )
                delete.Values.Add (new DeleteValue (item));
            manager.AddFilter (delete);

            var signing = new FilterProgram<TEntity> (new SigningFilterRule ());
            foreach ( var item in _services.Signing.All )
                signing.Values.Add (new SigningValue (item));
            manager.AddFilter (signing);

            var region = new FilterProgram<TEntity> (new RegionFilterRule ());
            foreach ( var item in _services.Okato.All )
                region.Values.Add (new RegionValue (item));
            manager.AddFilter (region);

            //var group = new FilterProgram<TEntity> (new GroupFilterRule (_services.Groups, _services.GroupTypeToTypes));
            //foreach ( var item in _services.GroupTypes.All)
            //    group.Values.Add (new GroupValue (item));
            //manager.AddFilter (group);
        }

        /// <summary>
        /// Инициализация дополнительных фильтров для партнера
        /// </summary>
        private static void InitializePartnerFilters<TEntity> (FilterManager<TEntity> manager) where TEntity : class, Data.IEntity, ICounterparties
        {
            //var curator = new FilterProgram<TEntity> (new CuratorFilterRule());
           // foreach ( var item in _services.Users.All )
           //     curator.Values.Add (new CuratorValue (item));
           // manager.AddFilter (curator);
        }

        /// <summary>
        /// Инициализация дополнительных фильтров для физлица
        /// </summary>
        private static void InitializeIndividualFilters<TEntity> (FilterManager<TEntity> manager) where TEntity : class, Data.IEntity, ICounterparties
        {
            var sex = new FilterProgram<TEntity> (new SexFilterRule());
            foreach ( var item in Enum.GetValues (typeof (Sex)).Cast<Sex> () )
                sex.Values.Add (new SexValue (item));
            manager.AddFilter (sex);
        }

        /// <summary>
        /// Инициализация фильтров базы данных.
        /// </summary>
        public static void InitializeDatabaseFilters<TEntity> (this FilterManager<TEntity> manager, AccessServiceModel<TEntity> service, Filter filterEntity, params FilterValue[] values) 
            where TEntity : class, IEntity, ICounterparties 
        {
            var filter = new FilterProgram<TEntity> (new DatabaseFilterRule<TEntity> (service, filterEntity));
            foreach ( var item in values )
                filter.Values.Add (new DatabaseValue (item.ValueFilter));
            manager.AddFilter (filter);
        }
    }
}
