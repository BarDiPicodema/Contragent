﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties
{
    public enum ContractorTypes : int
    {
        [Display (Name = "Партнер")]
        Partner = 0,

        [Display (Name = "Физическое лицо")]
        Individual = 1,

        [Display (Name = "Юридическое лицо")]
        Entrepreneur = 2
    }
}
