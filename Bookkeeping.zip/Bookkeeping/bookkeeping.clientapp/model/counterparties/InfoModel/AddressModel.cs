﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties.InfoModel
{
    public class AddressModel
    {
        private AccessServiceModel<Address> _address;
        private ServiceModel<AddressType> _type;
        private ServiceModel<AddressValue> _value;

        public AddressModel ()
        {
            _address = new AccessServiceModel<Address> ();
            _type = new ServiceModel<AddressType> ();
            _value = new ServiceModel<AddressValue> ();

            _address.Init ();
            _type.Init ();
            _value.Init ();
        }

        #region Events
        public event Action AddAddress;
        public event Action RemoveAddress;
        
        public event Action AddAddressType;
        public event Action RemoveAddressType;

        public event Action AddAddressValue;
        public event Action RemoveAddressValue;
        #endregion

        #region Add Update Remove
        public Address AddOrUpdate (Address address)
        {
            return _address.AddOrUpdateEntity (address);
        }

        public void Remove (Address address)
        {
            _address.RemoveEntity (address);
        }

        public void AddOrUpdate (AddressType type)
        {
            _type.AddOrUpdateEntity (type);
        }

        public void Remove (AddressType type)
        {
            _type.RemoveEntity (type);
        }

        public void AddOrUpdate (AddressValue value)
        {
            _value.AddOrUpdateEntity (value);
        }

        public void Remove (AddressValue value)
        {
            _type.RemoveEntity (value);
        }

        public void Remove (Address address, AddressType type)
        {
        }
        #endregion

        public List<Address> GetAddresses ()
        {
            return _address.GetAll ();
        }

        public List<AddressValue> GetAddressValueFromAddress (Address address)
        {
            return _value.GetEntities (item => item.IdAddress == address.Id);
        }
    }
}
