﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Counterparties
{
    public class Contractor
    {
        private Object _contractor;

        public ContractorTypes TypeContractor { get; private set; }
        public decimal Id { get; private set; }
        public string Alias { get; set; }
        public string Name { get; set; }
        public string Activity { get; set; }
        public string Process { get; set; }
        public Flag Flag { get; set; }
        public Signing Signing { get; set; }
        public Data.Interface.StateEntity IsDeleted { get; set; }

        public Contractor (Partner partner)
        {
            _contractor = partner;
            TypeContractor = ContractorTypes.Partner;

            Id = partner.Id;
            Alias = partner.Alias;
            Name = "";
            Activity = partner.Activity;
            var lastProcess = Model.ModelClient.Instance.Service.Processes.GetList (item => item.IdPartner == partner.Id);
            if ( lastProcess.Any () )
                Process = lastProcess.Last ().ProcessType.TypeName;
            Flag = partner.Flag;
            Signing = partner.Signing;
            IsDeleted = partner.IsDelete;
        }

        public Contractor (Individual individual)
        {
            _contractor = individual;
            TypeContractor = ContractorTypes.Individual;

            Id = individual.Id;
            Alias = individual.Alias;
            Name = individual.Name + " " + individual.SecondName + " " + individual.MiddleName;
            Activity = individual.Note;
            var lastProgress = Model.ModelClient.Instance.Service.Processes.GetList (item => item.IdIndividual == individual.Id);
            if ( lastProgress.Any () )
                Process = lastProgress.Last ().ProcessType.TypeName;

            Flag = individual.Flag;
            Signing = individual.Signing;
            IsDeleted = individual.IsDelete;
        }

        public Contractor (Entrepreneur entrepreneur)
        {
            _contractor = entrepreneur;
            TypeContractor = ContractorTypes.Entrepreneur;

            Id = entrepreneur.Id;
            Alias = entrepreneur.Alias;
            Name = entrepreneur.Name;

            /* var classificator = BookkepingModel.Instance.Service.Classifiers.GetList (item => item.IdEntrepreneur == entrepreneur.Id);
             if ( classificator != null )
             {
                 var okved = BookkepingModel.Instance.Service.Okved.Find (item => item.Id == classificator.IdOkved);
                 if (okved != null)
                    Activity = okved.Title;
            }*/

            var lastProgress = Model.ModelClient.Instance.Service.Processes.GetList (item => item.IdEntrepreneur == entrepreneur.Id);
            if ( lastProgress.Any () )
                Process = lastProgress.Last ().ProcessType.TypeName;

            Flag = entrepreneur.Flag;
            Signing = entrepreneur.Signing;
            IsDeleted = entrepreneur.IsDelete;
        }

        public static explicit operator Partner (Contractor contractor)
        {
            return contractor._contractor as Partner;
        }

        public static explicit operator Individual (Contractor contractor)
        {
            return contractor._contractor as Individual;
        }

        public static explicit operator Entrepreneur (Contractor contractor)
        {
            return contractor._contractor as Entrepreneur;
        }
    }
}
