﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator;

namespace Bookkeeping.ClientApp.Model.Counterparties
{
    /// <summary>
    /// TODO: Add parallel find contactors
    /// </summary>
    public class ClientServiceModel
    {
        private IService<Individual> _individualModel;
        public IService<Individual> IndividualService { get { return _individualModel; } }

        private IService<Entrepreneur> _entrepreneurModel;
        public IService<Entrepreneur> EntrepreneurService { get { return _entrepreneurModel; } }

        public ClientServiceModel ()
        {
            _individualModel = new AccessServiceModel<Individual> ();
            _entrepreneurModel = new AccessServiceModel<Entrepreneur> ();
        }

        public void Init ()
        {
            _individualModel.Init ();
            _entrepreneurModel.Init ();
        }

        public void AddOrUpdateContractor (Contractor contractor)
        {
            if ( contractor.TypeContractor == ContractorTypes.Individual )
                _individualModel.AddOrUpdateEntity ((Individual) contractor);
            else if ( contractor.TypeContractor == ContractorTypes.Entrepreneur )
                _entrepreneurModel.AddOrUpdateEntity ((Entrepreneur) contractor);
        }

        public void RemoveContractor (Contractor contractor)
        {
            if ( contractor.TypeContractor == ContractorTypes.Individual )
            {
                Individual individual = (Individual) contractor;
                individual.IsDelete = StateEntity.DeleteEntity;
                _individualModel.AddOrUpdateEntity (individual);
            }
            else if ( contractor.TypeContractor == ContractorTypes.Entrepreneur )
            {
                Entrepreneur entrepreneur = (Entrepreneur) contractor;
                entrepreneur.IsDelete = StateEntity.DeleteEntity;
                _entrepreneurModel.AddOrUpdateEntity (entrepreneur);
            }
        }

        public IList<Contractor> GetContractorsFromPartner (Partner partner)
        {
            List<Contractor> contractors = new List<Contractor> ();

            var individuals = _individualModel.GetEntities (item => item.IdPartner == partner.Id);
            if (individuals != null)
                foreach ( var individual in  individuals)
                    contractors.Add (new Contractor (individual));

            var entrepreneurs = _entrepreneurModel.GetEntities (item => item.IdPartner == partner.Id);
            if (entrepreneurs != null)
                foreach ( var entrepreneur in  entrepreneurs)
                    contractors.Add (new Contractor (entrepreneur));

            return contractors;
        }

        public IList<Contractor> IntersectClients (IList<Contractor> contractors, IList<Contractor> secondContractor)
        {
            IList<Contractor> newContractorList = new List<Contractor> ();
            foreach ( var contractor in secondContractor )
                foreach ( var item in contractors )
                    if ( contractor.TypeContractor == item.TypeContractor && item.TypeContractor == ContractorTypes.Individual )
                    {
                        if ( ( (Individual) contractor ).Id == ( (Individual) item ).Id )
                            newContractorList.Add (item);
                    }
                    else if ( contractor.TypeContractor == item.TypeContractor && item.TypeContractor == ContractorTypes.Entrepreneur )
                    {
                        if ( ( (Entrepreneur) contractor ).Id == ( (Entrepreneur) item ).Id )
                            newContractorList.Add (item);
                    }
                    else if ( contractor.TypeContractor == item.TypeContractor && item.TypeContractor == ContractorTypes.Partner )
                        if ( ( (Partner) contractor ).Id == ( (Partner) item ).Id )
                            newContractorList.Add (item);
            return newContractorList;
        }

        public IList<Individual> GetIndividualsFromPartner (Partner partner)
        {
            return _individualModel.GetEntities (item => item.IdPartner == partner.Id);
        }

        public IList<Entrepreneur> GetEntreprenseursFromPartner (Partner partner)
        {
            return _entrepreneurModel.GetEntities (item => item.IdPartner == partner.Id);
        }

        public IList<Individual> GetIndividuals ()
        {
            return _individualModel.GetAll ();
        }

        public IList<Entrepreneur> GetEntrepreneurs ()
        {
            return _entrepreneurModel.GetAll ();
        }

        public IList<Contractor> GetIndividualFiltred (Partner partner, params AbstractFilter<Individual>[] filters)
        {
            IList<Individual> individualFiltred = _individualModel.GetAll ();

            foreach ( AbstractFilter<Individual> filter in filters )
            {
                filter.Counterparties = individualFiltred;
                filter.Execute ();
                individualFiltred = individualFiltred.Intersect (filter.Counterparties).ToList ();
            }

            IList<Contractor> entities = new List<Contractor> ();
            foreach ( var item in individualFiltred )
                if ( partner != null )
                {
                    if ( partner.Id == item.IdPartner )
                        entities.Add (new Contractor (item));
                }
                else entities.Add (new Contractor (item));
            return entities;
        }

        public IList<Contractor> GetEntrepreneurFiltred (Partner partner, params AbstractFilter<Entrepreneur>[] filters)
        {
            IList<Entrepreneur> entrepreneurs = _entrepreneurModel.GetAll ();

            foreach ( AbstractFilter<Entrepreneur> filter in filters )
            {
                filter.Counterparties = entrepreneurs;
                filter.Execute ();
                entrepreneurs = entrepreneurs.Intersect (filter.Counterparties).ToList ();
            }

            IList<Contractor> entities = new List<Contractor> ();
            foreach ( var item in entrepreneurs )
                if ( partner != null )
                {
                    if ( partner.Id == item.IdPartner )
                        entities.Add (new Contractor (item));
                }
                else entities.Add (new Contractor (item));
            return entities;
        }


        public IList<Contractor> GetIndividualSearch (Partner partner, QueryManager query)
        {
            IList<Contractor> contractors = new List<Contractor> ();
            
            foreach ( Individual item in _individualModel.GetEntitiesFromSQLQuery (query.GenerateSQLQuery (), query.Values) )
                if (item.IdPartner == partner.Id)
                    contractors.Add (new Contractor (item));
            return contractors;
        }

        public IList<Contractor> GetEntrepreneurSearch (Partner partner, QueryManager query)
        {
            IList<Contractor> contractors = new List<Contractor> ();
            foreach ( Entrepreneur item in _entrepreneurModel.GetEntitiesFromSQLQuery (query.GenerateSQLQuery (), query.Values) )
                if (item.IdPartner == partner.Id)
                    contractors.Add (new Contractor (item));
            return contractors;
        }
    }
}
