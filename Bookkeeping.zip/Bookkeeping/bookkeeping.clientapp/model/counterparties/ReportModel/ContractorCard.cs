﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Word = Microsoft.Office.Interop.Word;

using WordDocument = Microsoft.Office.Interop.Word.Document;

namespace Bookkeeping.ClientApp.Model.Counterparties.ReportModel
{
    /// <summary>
    /// TODO
    /// </summary>
    public sealed class ContractorCard : AbstractReport
    {
        public ContractorCard ()
            : base ()
        {
            _contactService = new AccessServiceModel<Contact> ();
            _contactService.Init ();

            _document.Content.SetRange (0, 0);
        }

        private readonly string Phone = "Телефон";
        private readonly string Web = "Web";
        private readonly string Email = "E-Mail";

        private AccessServiceModel<Contact> _contactService;

        public WordDocument ReportWorkbook { get { return _document; } }

        private void Header (string alias)
        {
            foreach ( Word.Section section in _document.Sections )
            {
                Word.Range headerRange = section.Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                headerRange.Fields.Add (headerRange, Word.WdFieldType.wdFieldPage);
                headerRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                headerRange.Font.ColorIndex = Word.WdColorIndex.wdBlack;
                headerRange.Font.Bold = 1;
                headerRange.Font.Size = 16;
                headerRange.Text = "ПСЕВДОНИМ: " + alias.ToUpper () + Environment.NewLine;
            }
        }

        private void SetWebAndEMail (Contact web, Contact email)
        {
            if ( web == null && email == null )
                return;

            foreach ( Word.Section section in _document.Sections )
            {
                Word.Range headerRange = section.Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                headerRange.Fields.Add (headerRange, Word.WdFieldType.wdFieldPage);
                headerRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                headerRange.Font.ColorIndex = Word.WdColorIndex.wdBlack;
                headerRange.Font.Bold = 1;
                headerRange.Font.Size = 14;

                headerRange.Text = "Web: ";
                if ( web != null )
                    headerRange.Text += web.ContactText + Environment.NewLine;

                headerRange.Text = "E-Mail: ";
                if ( email != null )
                    headerRange.Text += email.ContactText;
            }
        }

        private void SetData (string name, string inn, string kpp, DateTime? date, string process, List<Contact> contacts)
        {
            string datePlace = string.Empty;

            var paragraph = _document.Content.Paragraphs.Add (ref _missing);
            object styleHeading2 = "Заголовок 2";
            paragraph.Range.set_Style (styleHeading2);
            paragraph.Range.Text = string.Format ("ИМЯ: {1}, {0}ИНН: {2}, КПП: {3}{0}ДАТА: {4}, ПРОЦЕССЫ: {5}",
                                                                                Environment.NewLine, name, inn, kpp, datePlace, process);
            paragraph.Range.InsertParagraphAfter ();

            int row = contacts.Count > 0 ? contacts.Count + 1 : 2;

            Word.Table table = _document.Tables.Add (paragraph.Range, 1, 4, ref _missing, ref _missing);
            table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleDouble;
            table.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;

            SetCell (table, 1, 1, "№", 1, 10);
            SetCell (table, 1, 2, "Телефон", 1, 10);
            SetCell (table, 1, 3, "ФИО", 1, 10);
            SetCell (table, 1, 4, "Подразделение/должность", 1, 10);

            foreach ( var contact in contacts )
            {
                table.Rows.Add (ref _missing);

                table.Rows[row].Cells[1].Range.Text = contact.Id.ToString ();
                table.Rows[row].Cells[2].Range.Text = contact.ContactText;
                table.Rows[row].Cells[3].Range.Text = contact.Name;
                table.Rows[row].Cells[4].Range.Text = contact.Sub;

                row++;
            }

            _application.Visible = true;
        }

        public override void SetContractorData (params Contractor[] contractors)
        {
            for ( int i = 0; i < contractors.Count (); i++ )
            {
                var contractor = contractors.ElementAt (i);
                if ( contractor.TypeContractor == ContractorTypes.Partner )
                {
                    var temp = _service.GetContractorsFromPartner ((Data.Entities.Partner) contractor);
                    for ( int j = 0; j < temp.Count; j++ )
                    {
                        GenerateDocument (temp.ElementAt (i));
                        if ( i != temp.Count () - 1 )
                            _application.Selection.InsertNewPage ();
                    }
                }
                else
                {
                    GenerateDocument (contractor);
                    if ( i != contractors.Count () - 1 )
                        _application.Selection.InsertNewPage ();
                }
            }
        }

        protected override void GenerateDocument (Contractor contractor)
        {
            Header (contractor.Alias);
            List<Contact> contacts = new List<Contact> ();
            Contact web = null;
            Contact email = null;

            if ( contractor.TypeContractor == ContractorTypes.Individual )
            {
                var contactIndividual = _contactService.GetEntities (item => item.IdIndividual == contractor.Id);
                contacts.AddRange (contactIndividual.Where (item => item.ContactType.TypeName.Contains (Phone)));
                if (contactIndividual.Where (item => item.ContactType.TypeName.Contains (Web)).Any())
                    web = contactIndividual.Where (item => item.ContactType.TypeName.Contains (Web)).ElementAt(0);
                if (contactIndividual.Where (item => item.ContactType.TypeName.Contains (Email)).Any())
                    email = contactIndividual.Where (item => item.ContactType.TypeName.Contains (Email)).ElementAt (0);
            }
            if ( contractor.TypeContractor == ContractorTypes.Entrepreneur )
            {
                var contactEntrepreneur = _contactService.GetEntities (item => item.IdEntrepreneur == contractor.Id);
                contacts.AddRange (contactEntrepreneur.Where (item => item.ContactType.TypeName.Contains (Phone)));
                if ( contactEntrepreneur.Where (item => item.ContactType.TypeName.Contains (Web)).Any () )
                    web = contactEntrepreneur.Where (item => item.ContactType.TypeName.Contains (Web)).ElementAt (0);
                if ( contactEntrepreneur.Where (item => item.ContactType.TypeName.Contains (Email)).Any () )
                    email = contactEntrepreneur.Where (item => item.ContactType.TypeName.Contains (Email)).ElementAt (0);
            }

            SetWebAndEMail (web, email);

            if ( contractor.TypeContractor == ContractorTypes.Individual )
            {
                var individuals = (Individual) contractor;
                SetData (string.Format ("{0} {1} {2}", individuals.SecondName, individuals.Name, individuals.MiddleName),
                                individuals.INN, "", individuals.BirthDate, contractor.Process, contacts);
            }

            if ( contractor.TypeContractor == ContractorTypes.Entrepreneur )
            {
                var entrepreneur = (Entrepreneur) contractor;
                SetData (entrepreneur.Name, entrepreneur.INN, entrepreneur.KPP, entrepreneur.RegistrationDate, null, contacts);
            }
        }
    }
}
