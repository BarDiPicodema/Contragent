﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Word = Microsoft.Office.Interop.Word;

using WordDocument = Microsoft.Office.Interop.Word.Document;

namespace Bookkeeping.ClientApp.Model.Counterparties.ReportModel
{
    public sealed class ContactCard : AbstractReport
    {
        public ContactCard ()
            : base ()
        {
            _contactService = new AccessServiceModel<Contact> ();
            _contactService.Init ();

            _document.Content.SetRange (0, 0);
        }

        private readonly string Phone = "Телефон";

        private AccessServiceModel<Contact> _contactService;

        private void SetData ( Word.Paragraph paragraph, Contractor contractor)
        {
            IList<Contact> contacts = new List<Contact> ();
            if ( contractor.TypeContractor == ContractorTypes.Individual )
                contacts = _contactService.GetEntities (item => item.IdIndividual == contractor.Id);
            if ( contractor.TypeContractor == ContractorTypes.Entrepreneur )
                contacts = _contactService.GetEntities (item => item.IdEntrepreneur == contractor.Id);
            var row = contacts.Count > 0 ? contacts.Count + 1 : 1;

            var table = _document.Tables.Add (paragraph.Range, 1, 2, ref _missing, ref _missing);
            table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleDouble;
            table.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;

            SetCell (table, 1, 1, "Название", 1, 10);
            SetCell (table, 1, 2, "Телефон", 1, 10);

            foreach ( var contact in contacts )
            {
                table.Rows.Add (ref _missing);
                table.Rows[row].Cells[1].Range.Text = contractor.Name;
                table.Rows[row].Cells[2].Range.Text = contact.ContactText;

                row++;
            }
            paragraph.Range.InsertParagraphAfter ();
        }

        public override void SetContractorData (params Contractor[] contractors)
        {
            var paragraph = _document.Paragraphs.Add (ref _missing);

            for ( int i = 0; i < contractors.Count (); i++ )
            {
                var contractor = contractors.ElementAt (i);
                if ( contractor.TypeContractor == ContractorTypes.Partner )
                {
                    var temp = _service.GetContractorsFromPartner ((Data.Entities.Partner) contractor);
                    foreach ( var item in temp )
                    {
                        SetData (paragraph, item);
                    }
                }
                else SetData (paragraph, contractor);
            }
            _application.Visible = true;
        }

        protected override void GenerateDocument (Contractor contractor)
        {

        }
    }
}
