﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.Entities;
using Word = Microsoft.Office.Interop.Word;

using WordDocument = Microsoft.Office.Interop.Word.Document;


namespace Bookkeeping.ClientApp.Model.Counterparties.ReportModel
{
    public class ReportService
    {
        public ReportService ()
        {

        }

        public void GenerateContractorCard (AbstractReport report, params Contractor[] contractors)
        {
            report.SetContractorData (contractors);
            //report.SaveDocument ();
        }
    }
}
