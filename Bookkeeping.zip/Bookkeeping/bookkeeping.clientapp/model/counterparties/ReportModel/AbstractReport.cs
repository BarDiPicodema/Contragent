﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using Word = Microsoft.Office.Interop.Word;

using WordDocument = Microsoft.Office.Interop.Word.Document;

namespace Bookkeeping.ClientApp.Model.Counterparties.ReportModel
{
    public abstract class AbstractReport
    {
        

        public AbstractReport ()
        {
            _service = new ClientServiceModel ();
            _service.Init ();

            _application = new Microsoft.Office.Interop.Word.Application ();

            _missing = System.Reflection.Missing.Value;
            _document = _application.Documents.Add (ref _missing, ref _missing, ref _missing, ref _missing);
        }

        private string _documentPath = Environment.GetFolderPath (Environment.SpecialFolder.MyDocuments);

        protected ClientServiceModel _service;
        protected Microsoft.Office.Interop.Word.Application _application;
        protected WordDocument _document;
        protected object _missing;

        public virtual void SetContractorData (params Contractor[] contractors)
        {
            foreach ( var item in contractors )
                GenerateDocument (item);
        }

        protected abstract void GenerateDocument (Contractor contractor);

        protected void SetCell (Word.Table table, int row, int column, string text, int bold = 0, int fontSize = 8, Word.WdColor color = Word.WdColor.wdColorWhite)
        {
            table.Cell (row, column).Range.Font.Name = "verdana";
            table.Cell (row, column).Shading.BackgroundPatternColor = color;
            table.Cell (row, column).Range.Font.Size = fontSize;
            table.Cell (row, column).Range.Bold = bold;
            table.Cell (row, column).Range.Text = text;
        }

        protected void SetCellData (Word.Table table, int row, int column, string text, int fontSize = 8, Word.WdColor color = Word.WdColor.wdColorWhite)
        {
            table.Rows[row].Cells[column].Range.Font.Name = "verdana";
            table.Rows[row].Cells[column].Range.Font.Size = fontSize;
            table.Rows[row].Cells[column].Range.Text = text;
        }

        public void SaveDocument ()
        {
            var save = new System.Windows.Forms.SaveFileDialog();
            save.InitialDirectory = _documentPath;
            if ( save.ShowDialog () == System.Windows.Forms.DialogResult.OK )
            {
                string documentName = save.FileName;
                if ( documentName.Length > 0 )
                {
                    object filename = (object) documentName;
                    _document.SaveAs (ref filename);
                    _application.Visible = true;
                }
            }

            Dispose ();
        }

        private void Dispose ()
        {
            _document.Close (ref _missing, ref _missing, ref _missing);
            _document = null;

            _application.Quit (ref _missing, ref _missing, ref _missing);
            _application = null;
        }
    }
}
