﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data;

namespace Bookkeeping.ClientApp.Model
{
    public interface IService<TEntity> where TEntity : class, IEntity
    {
        void Init ();

        TEntity AddOrUpdateEntity (TEntity entity);
        void RemoveEntity (TEntity entity);

        IList<TEntity> GetAll ();
        IList<TEntity> GetEntities (Expression<Func<TEntity, bool>> where);
        IList<TEntity> GetEntitiesFromSQLQuery (string query, params object[] parameters);
        TEntity FindEntity (Func<TEntity, bool> where);
    }
}
