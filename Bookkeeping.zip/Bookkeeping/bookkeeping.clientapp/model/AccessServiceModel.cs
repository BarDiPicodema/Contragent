﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data;
using Bookkeeping.Data.Interface;
using Bookkeeping.DataAccess.Interfaces;
using System.Linq.Expressions;
using Bookkeeping.ClientApp.Model.PermissionModel;

namespace Bookkeeping.ClientApp.Model
{
    public class AccessServiceModel<TEntity> : IService<TEntity> where TEntity : class, IEntity, IAccessData
    {
        private ICrudService<TEntity> _crud;
        private AccessReadExpression<TEntity> _read;

        public AccessServiceModel ()
        {

        }

        public void Init ()
        {
            _crud = ModelClient.Instance.Service.GetCrud<TEntity> ();
            _read = new AccessReadExpression<TEntity> ();
        }

        public TEntity AddOrUpdateEntity (TEntity entity)
        {
            try
            {
                TEntity result = null;
                if ( entity.Id == 0 )
                    result = _crud.Create (entity);
                else result = _crud.Update (entity);
                return result;
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return null;
        }

        public void RemoveEntity (TEntity entity)
        {
            try
            {
                _crud.Delete (entity);
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
        }

        public IList<TEntity> GetAll ()
        {
            try
            {
                return _crud.All.Where (_read.AccessExpression).ToList ();
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return new List<TEntity> ();;
        }

        public IList<TEntity> GetEntitiesFromSQLQuery (string query, params object[] parameters)
        {
            try
            {
                IList<TEntity> entities = new List<TEntity> ();
                var accessEntities = GetAll ();
                foreach ( var param in parameters )
                {
                    var template = param.ToString ().ToUpper ();
                    foreach ( var entity in _crud.SQLQuery (string.Format (query, template), template) )
                    {
                        var temp = accessEntities.Single (item => item.Id == entity.Id);
                        if ( temp != null )
                            entities.Add (temp);
                    }
                }
                return entities;
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return new List<TEntity> ();;
        }

        public IList<TEntity> GetEntities (Expression<Func<TEntity, bool>> where)
        {
            try
            {
                var entities = GetAll ();
                if ( entities != null )
                {
                    var result = entities.Where (where.Compile());
                    if ( result != null )
                        return result.ToList ();
                }
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return new List<TEntity> ();
        }

        public TEntity FindEntity (Func<TEntity, bool> where)
        {
            try
            {
                var entities = GetAll ();
                if ( entities != null )
                {
                    var temp = entities.Where (where);
                    if (temp.Count() > 0)
                        return temp.ElementAt(0);
                }
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return null;
        }
    }
}
