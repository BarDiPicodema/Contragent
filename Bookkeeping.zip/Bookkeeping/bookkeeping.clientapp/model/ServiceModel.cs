﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data;
using Bookkeeping.DataAccess.Interfaces;

namespace Bookkeeping.ClientApp.Model
{
    public class ServiceModel<TEntity> : IService<TEntity> where TEntity : class, IEntity
    {
        private ICrudService<TEntity> _crud;

        public ServiceModel ()
        {
            //_crud = ModelClient.Instance.Service.GetCrud<TEntity> ();
        }

        public void Init ()
        {
            _crud = ModelClient.Instance.Service.GetCrud<TEntity> ();
        }

        public TEntity AddOrUpdateEntity (TEntity entity)
        {
            try
            {
                TEntity result = null;
                if ( entity.Id == 0 )
                    result = _crud.Create (entity);
                else result = _crud.Update (entity);
                return result;
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return null;
        }

        public void RemoveEntity (TEntity entity)
        {
            try
            {
                _crud.Delete (entity);
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
        }

        public IList<TEntity> GetAll ()
        {
            try
            {
                string a = typeof (TEntity).Name;
                return _crud.GetAll ();
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return null;
        }

        public IList<TEntity> GetEntitiesFromSQLQuery (string query, params object[] parameters)
        {
            try
            {
                return _crud.SQLQuery (query, parameters);
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return null;
        }

        public IList<TEntity> GetEntities (Expression<Func<TEntity, bool>> where)
        {
            try
            {
                return _crud.GetList (where);
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return null;
        }

        public TEntity FindEntity (Func<TEntity, bool> where)
        {
            try
            {
                var aa = _crud.GetAll ();
                return _crud.Find (where);
            }
            catch ( Exception ex )
            {
                System.Windows.Forms.MessageBox.Show (ex.Message);
            }
            return null;
        }
    }
}
