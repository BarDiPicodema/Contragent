﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data.EF;

namespace Bookkeeping.ClientApp.Model.DatabaseReflection
{
    public class SearchReflectionService : DatabaseReflectionModel
    {
        public SearchReflectionService ()
        {

        }

        public ICollection<ElementNode> GetElementNodeSearchFromElementNode (ElementNode node)
        {
            ICollection<ElementNode> nodes = new List<ElementNode> ();
            foreach ( var key in Properties.Keys )
                if ( key.ReadebleName == node.ReadebleName )
                    foreach ( var item in Properties[key] )
                    {
                        var attribute = Attribute.GetCustomAttribute (item.Property, typeof (AssociationNameAttribute));
                        if ( attribute != null )
                        {
                            var temp = attribute as AssociationNameAttribute;
                            if ( temp.Operation == FieldOperation.Search || temp.Operation == FieldOperation.FilterSearch )
                                nodes.Add (item);
                        }
                    }
            return nodes;
        }

        public override ICollection<ElementNode> GetInitialDataTables ()
        {
            ICollection<ElementNode> tables = new List<ElementNode> ();
            foreach ( var key in Properties.Keys )
            {
                var attribute = Attribute.GetCustomAttribute (key.Property, typeof (AssociationNameAttribute)) as AssociationNameAttribute;
                if ( attribute != null )
                {
                    if ( attribute.Operation == FieldOperation.Search || attribute.Operation == FieldOperation.FilterSearch )
                        tables.Add (key);
                }
            }
            return tables;
        }
    }
}
