﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Bookkeeping.Data.EF;

namespace Bookkeeping.ClientApp.Model.DatabaseReflection
{
    public abstract class DatabaseReflectionModel
    {
        protected IDictionary<ElementNode, List<ElementNode>> Properties;
        protected IDictionary<PropertyInfo, bool> Visited;

        public DatabaseReflectionModel ()
        {
            Properties = new Dictionary<ElementNode, List<ElementNode>> ();
            Visited = new Dictionary<PropertyInfo, bool> ();

            LoadData ();
        }

        protected void LoadData ()
        {
            var type = typeof (Bookkeeping.Data.BookkeepingContext);
            foreach ( var property in type.GetProperties () )
                if (Attribute.GetCustomAttribute (property, typeof (AssociationNameAttribute)) != null && property.PropertyType.IsGenericType)
                    Visited.Add (property, false);

            PropertyInfo[] properties = new PropertyInfo[Visited.Keys.Count];
            Visited.Keys.CopyTo (properties, 0);
            foreach ( var item in properties )
                PropertyFiller (item);
        }

        private void PropertyFiller (PropertyInfo dbSet)
        {
            var dbSetElement = new ElementNode (dbSet);
            if ( Properties.ContainsKey (dbSetElement) == false && Visited.ContainsKey(dbSet) )
            {
                List<ElementNode> columnElements = new List<ElementNode> ();
                IList<PropertyInfo> propertiesDbSet = GetColumnFromDbSet (dbSet);
                foreach ( var property in propertiesDbSet )
                {
                    var temp = IsExampleTypeFromContext (property);
                    if ( property.PropertyType.IsGenericParameter || temp != null)
                        columnElements.Add (new ElementNode (TypeProperty.TableProperty, temp));
                    else columnElements.Add (new ElementNode (TypeProperty.ColumnProperty, property));
                }
                Visited[dbSet] = true;
                Properties.Add (dbSetElement, columnElements);
            }
        }

        private PropertyInfo IsExampleTypeFromContext (PropertyInfo property)
        {
            var properties = typeof (Bookkeeping.Data.BookkeepingContext).GetProperties();
            foreach ( PropertyInfo item in properties )
            {
                var type = item.PropertyType.GetGenericArguments ();
                if ( type.Any () )
                {
                    var typeProperty = property.PropertyType.GetGenericArguments ();
                    if ( typeProperty.Any () )
                    {
                        if ( type.Single () == typeProperty.Single () )
                            return item;
                    }
                    else if ( type.Single () == property.PropertyType )
                        return item;
                }
            }
            return null;
        }

        public ICollection<ElementNode> GetElementNodesFromElementNode (ElementNode node)
        {
            foreach ( var key in Properties.Keys )
                if ( key.ReadebleName == node.ReadebleName )
                    return Properties[key];
            return null;
        }

        protected Type GetTypeFromProperty (PropertyInfo property)
        {
            var type = property.PropertyType.GetGenericArguments().Single();
            if ( type != null )
                return type;
            return property.PropertyType;
        }

        private IList<PropertyInfo> GetColumnFromDbSet (PropertyInfo dbSet)
        {
            IList<PropertyInfo> properties = new List<PropertyInfo> ();
            foreach ( var property in dbSet.PropertyType.GetGenericArguments ()[0].GetProperties () )
            {
                if ( Attribute.GetCustomAttribute (property, typeof (AssociationNameAttribute)) != null )
                    properties.Add (property);
            }
            return properties;
        }

        public ICollection<string> GetValues (ElementNode table, ElementNode element)
        {
            ICollection<string> data = new List<string> ();
                using ( var database = new Bookkeeping.Data.BookkeepingContext ("Bookkeeping") )
                {
                    var dbSet = typeof (Bookkeeping.Data.BookkeepingContext).GetProperty (table.Property.Name);
                    foreach ( var item in ( dbSet.GetValue (database, null) as IEnumerable<object> ) )
                    {
                        var property = item.GetType ().GetProperty (element.Property.Name);
                        data.Add (property.GetValue (item, null).ToString());
                    }
                }
            return data;
        }

        /// <summary>
        /// Метод инициализирующий таблицы
        /// </summary>
        /// <returns></returns>
        public abstract ICollection<ElementNode> GetInitialDataTables ();
    }
}
