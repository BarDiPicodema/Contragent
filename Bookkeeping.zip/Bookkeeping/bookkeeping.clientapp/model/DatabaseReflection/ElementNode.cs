﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Bookkeeping.Data.EF;
using Bookkeeping.Data.EntityHelper;

namespace Bookkeeping.ClientApp.Model.DatabaseReflection
{
    public enum TypeProperty
    {
        TableProperty,
        ColumnProperty
    };

    public class ElementNode
    {
        public TypeProperty TypeProperty { get; private set; }

        public PropertyInfo Property { get; private set; }

        public string ReadebleName { get { return Property.Name; } }

        public string ReadebleAssociationName 
        {
            get
            {
                var attr = Attribute.GetCustomAttribute (Property, typeof (AssociationNameAttribute)) as AssociationNameAttribute;
                if (attr != null)
                    return (attr).Name;
                return null;
            }
        }

        public ElementNode (TypeProperty type,  PropertyInfo property)
        {
            TypeProperty = type;
            Property = property;
        }

        public ElementNode (PropertyInfo property)
        {
            if ( property.PropertyType.IsGenericType )
                TypeProperty = TypeProperty.TableProperty;
            else TypeProperty = TypeProperty.ColumnProperty;

            Property = property;
        }
    }
}
