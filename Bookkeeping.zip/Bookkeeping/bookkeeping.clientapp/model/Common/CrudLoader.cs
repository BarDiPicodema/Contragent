﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bookkeeping.Data;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.EntityHelper;
using Bookkeeping.DataAccess;

namespace Bookkeeping.ClientApp.Model.Common
{
    public class CrudLoader
    {
        private BookkeepingContext _context;
        private NomenclatureService _service;

        public CrudLoader (BookkeepingContext context)
        {
            _service = new NomenclatureService ();
            _context = context;
            LoadCrudServices ();
            LoadExtensionCrudServices ();
        }

        private void LoadCrudServices ()
        {
            _service.AddCrud (new CrudService<AccessType> (_context));
            _service.AddCrud (new CrudService<Flag> (_context));
            _service.AddCrud (new CrudService<Signing> (_context));

            _service.AddCrud (new CrudService<Okato> (_context));
            _service.AddCrud (new CrudService<Okfs> (_context));
            _service.AddCrud (new CrudService<Okogu> (_context));
            _service.AddCrud (new CrudService<Okopf> (_context));
            _service.AddCrud (new CrudService<Oksm> (_context));
            _service.AddCrud (new CrudService<Okv> (_context));
            _service.AddCrud (new CrudService<Okved> (_context));
            _service.AddCrud (new CrudService<Sono> (_context));

            _service.AddCrud (new CrudService<Departament> (_context));
            _service.AddCrud (new CrudService<User> (_context));
            _service.AddCrud (new CrudService<UserGrant> (_context));

            _service.AddCrud (new CrudService<Partner> (_context));
            _service.AddCrud (new CrudService<Individual> (_context));
            _service.AddCrud (new CrudService<Entrepreneur> (_context));
            _service.AddCrud (new CrudService<Classifier> (_context));

            _service.AddCrud (new CrudService<Specification> (_context));

            _service.AddCrud (new CrudService<AccountType> (_context));
            _service.AddCrud (new CrudService<AccountKind> (_context));
            _service.AddCrud (new CrudService<Account> (_context));

            _service.AddCrud (new CrudService<AddressType> (_context));
            _service.AddCrud (new CrudService<Address> (_context));
            _service.AddCrud (new CrudService<AddressValue> (_context));

            _service.AddCrud (new CrudService<ContactType> (_context));
            _service.AddCrud (new CrudService<Contact> (_context));

            _service.AddCrud (new CrudService<ProcessType> (_context));
            _service.AddCrud (new CrudService<Process> (_context));

            _service.AddCrud (new CrudService<Link> (_context));
            _service.AddCrud (new CrudService<DocumentType> (_context));
            _service.AddCrud (new CrudService<Document> (_context));
            _service.AddCrud (new CrudService<DocumentParticipant> (_context));

            _service.AddCrud (new CrudService<Group> (_context));
            _service.AddCrud (new CrudService<GroupType> (_context));
            _service.AddCrud (new CrudService<GroupTypeToType> (_context));
        }

        private void LoadExtensionCrudServices ()
        {
            _service.AddCrud (new CrudService<AssociationTable> (_context));
            _service.AddCrud (new CrudService<Filter> (_context));
            _service.AddCrud (new CrudService<QueryNode> (_context));
            _service.AddCrud (new CrudService<FilterValue> (_context));
        }

        public NomenclatureService Service { get { return _service; } }
    }
}
