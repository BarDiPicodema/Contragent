﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.Common
{
    public static class ComparerAlphabet
    {
        public static void SortPartner (this IList<Partner> partners)
        {
            
        }
    }
}
