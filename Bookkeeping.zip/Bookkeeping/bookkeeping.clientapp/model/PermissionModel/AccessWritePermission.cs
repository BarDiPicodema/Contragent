﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.PermissionModel
{
    public class AccessWritePermission
    {
        public AccessWritePermission (User user)
        {
            _user = user;
        }

        private User _user;

        public bool GetPermission (AccessType access)
        {
            if ( access == null )
                return true;

            if ( _user.UserGrant.OverallData == GrantType.ReadWrite && AccessTypeOverall (access) )
                return true;
            else if (_user.UserGrant.PrivateData == GrantType.ReadWrite && AccessTypePrivate (access))
                return true;
            else if (_user.UserGrant.TheirPersonal == GrantType.ReadWrite && AccessTypePersonal (access))
                return true;
            else if (_user.UserGrant.HisDepartament == GrantType.ReadWrite && AccessTypeHisDepartament (access))
                return true;
            else if (_user.UserGrant.ForeignPersonal == GrantType.ReadWrite && AccessTypeForeignPersonal (access))
                return true;
            else if (_user.UserGrant.ForeignPrivate == GrantType.ReadWrite && AccessTypeForeignPrivate (access))
                return true;
            else if (_user.UserGrant.OtherDepartament == GrantType.ReadWrite && AccessTypeOtherDepartament (access))
                return true;
            else if (_user.UserGrant.OtherPersonal == GrantType.ReadWrite && AccessTypeOtherPersonal (access))
                return true;

            return false;
        }

        #region Access types
        private bool AccessTypeOverall (AccessType access)
        {
            if ( access.IdDepartament == 0 && access.IdUser == 0 && access.IsPrivate == false )
                return true;
            return false;
        }

        private bool AccessTypePrivate (AccessType access)
        {
            if ( access.IdDepartament == _user.Departament.Id && access.IdUser == _user.Id && access.IsPrivate == true )
                return true;
            return false;
        }

        private bool AccessTypePersonal (AccessType access)
        {
            if ( access.IdDepartament == _user.Departament.Id && access.IdUser == _user.Id && access.IsPrivate == false )
                return true;
            return false;
        }

        private bool AccessTypeHisDepartament (AccessType access)
        {
            if ( access.IdDepartament == _user.Departament.Id && access.IsPrivate == false )
                return true;
            return false;
        }

        private bool AccessTypeForeignPersonal (AccessType access)
        {
            if ( access.IdDepartament == _user.Departament.Id && access.IdUser != _user.Id && access.IsPrivate == false )
                return true;
            return false;
        }

        private bool AccessTypeForeignPrivate (AccessType access)
        {
            if ( access.IdDepartament == _user.Departament.Id && access.IdUser != _user.Id && access.IsPrivate == true )
                return true;
            return false;
        }

        private bool AccessTypeOtherPersonal (AccessType access)
        {
            if ( access.IdDepartament != _user.Departament.Id && access.IdUser != _user.Id && access.IsPrivate == false )
                return true;
            return false;
        }

        private bool AccessTypeOtherDepartament (AccessType access)
        {
            if ( access.IdDepartament != _user.Departament.Id && access.IdUser != _user.Id && access.IsPrivate == true )
                return true;
            return false;
        }
        #endregion
    }
}
