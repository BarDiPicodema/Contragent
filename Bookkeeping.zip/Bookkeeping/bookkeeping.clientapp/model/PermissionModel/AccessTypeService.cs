﻿using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.PermissionModel
{
    class AccessTypeService
    {
        ServiceModel<AccessType> _service;
        public ServiceModel<AccessType> Service { get { return _service; } }

        public AccessTypeService ()
        {
            _service = new ServiceModel<AccessType> ();
            _service.Init ();
        }

        public List<AccessType> GetAccessTypeFromUser (User user)
        {
            UserGrant grant = user.UserGrant;
            List<AccessType> types = new List<AccessType> ();

            foreach ( var item in _service.GetAll () )
                if ( grant.HisDepartament == GrantType.ReadWrite && item.IdDepartament == user.IdDepartament )
                    types.Add (item);
                else if ( grant.OtherDepartament == GrantType.ReadWrite && item.IdDepartament != user.IdDepartament )
                    types.Add (item);
                else if ( grant.ForeignPersonal == GrantType.ReadWrite && item.IdDepartament == user.IdDepartament && item.IdUser != user.Id && item.IsPrivate == false )
                    types.Add (item);
                else if ( grant.ForeignPrivate == GrantType.ReadWrite && item.IdDepartament == user.IdDepartament && item.IdUser != user.Id && item.IsPrivate == true )
                    types.Add (item);
                else if ( grant.OtherDepartament == GrantType.ReadWrite && item.IdDepartament != user.IdDepartament )
                    types.Add (item);
                else if ( grant.OtherPersonal == GrantType.ReadWrite && item.IsPrivate == true && item.IdDepartament != user.IdDepartament )
                    types.Add (item);
                else if ( grant.OverallData == GrantType.Read )
                    types.Add (item);
                else if ( grant.PrivateData != GrantType.NotRead && grant.TheirPersonal != GrantType.NotRead )
                    types.Add (item);

            return types;
        }

        public AccessType Find (Func<AccessType, bool> lambda)
        {
            return _service.FindEntity (lambda);
        }
    }
}
