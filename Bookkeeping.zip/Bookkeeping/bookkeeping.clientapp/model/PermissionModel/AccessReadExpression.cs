﻿using Bookkeeping.Data;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Bookkeeping.ClientApp.Model.PermissionModel
{
    public class AccessReadExpression<TEntity> where TEntity : class, IEntity, IAccessData
    {
        private Expression<Func<TEntity, bool>> _accessExpression;
        public Expression<Func<TEntity, bool>> AccessExpression { get { return _accessExpression; } }

        private Dictionary<string, List<Expression>> _allExpression;
        private Dictionary<string, List<Expression>> _regulationDictionary;

        private ParameterExpression _parameter;

        public AccessReadExpression ()
        {
            _allExpression = new Dictionary<string, List<Expression>> ();
            _regulationDictionary = new Dictionary<string, List<Expression>> ();
            _parameter = Expression.Parameter (typeof (TEntity), "item");

            GetAccessExpressions ();

            _accessExpression = GetAccessLambda ();
        }

        public Expression<Func<TEntity, bool>> GetAccessLambda ()
        {
            Expression expression = null;
            foreach ( var item in _regulationDictionary.Keys )
            {
                Expression expressionNode = null;
                var nodes = _regulationDictionary[item];
                foreach ( var node in nodes )
                    if ( expressionNode == null )
                        expressionNode = node;
                    else expressionNode = Or (expressionNode, node);
                if ( expression == null )
                    expression = expressionNode;
                else expression = And (expression, expressionNode);
            }
            return Expression.Lambda<Func<TEntity, bool>> (expression, _parameter);
        }

        private void GetAccessExpressions ()
        {
            if ( typeof (TEntity).GetProperty ("AccessType") != null )
            {
                if ( CurrentUser.Grant.PrivateData != GrantType.NotRead )
                {
                    AddExpression (GetIdUserProperty (), Expression.And (Expression.Equal (GetIdUserProperty (), GetConstantIdUser ()),
                                                                                             Expression.Equal (GetIsPrivateProperty (), GetConstantIsPrivateTrue ())));
                }
                if ( CurrentUser.Grant.TheirPersonal != GrantType.NotRead )
                {
                    AddExpression (GetIdUserProperty (), Expression.Equal (GetIdUserProperty (), GetConstantIdUser ()));
                    AddExpression (GetIsPrivateProperty (), Expression.Equal (GetIsPrivateProperty (), GetConstantIsPrivateFalse ()));
                }
                if ( CurrentUser.Grant.HisDepartament != GrantType.NotRead )
                {
                    Expression userExpression = Expression.Equal (GetIdUserProperty (), GetConstantIdUser ());
                    Expression isPrivate = Expression.Equal (GetIsPrivateProperty (), GetConstantIsPrivateTrue ());
                    AddExpression (GetIsPrivateProperty (), Expression.And (userExpression, isPrivate));

                    AddExpression (GetIdDepartamentProperty (), Expression.Equal (GetIdDepartamentProperty (), GetConstantIdDepartament ()));
                    AddExpression (GetIdDepartamentProperty (), Expression.Equal (GetIdDepartamentProperty (), Expression.Convert(Expression.Constant (decimal.Zero), typeof(decimal?))));
                    AddExpression (GetIdUserProperty (), Expression.Equal (GetIdUserProperty (), GetConstantIdUserNull ()));
                }
                if ( CurrentUser.Grant.ForeignPersonal != GrantType.NotRead )
                {
                    AddExpression (GetIdUserProperty (), Expression.NotEqual (GetIdUserProperty (), GetConstantIdUser ()));
                    AddExpression (GetIdDepartamentProperty (), Expression.Equal (GetIdDepartamentProperty (), GetConstantIdDepartament ()));
                    AddExpression (GetIsPrivateProperty (), Expression.Equal (GetIsPrivateProperty (), GetConstantIsPrivateFalse ()));
                }
                if ( CurrentUser.Grant.OtherDepartament != GrantType.NotRead )
                {
                    AddExpression (GetIdDepartamentProperty (), Expression.NotEqual (GetIdDepartamentProperty (), GetConstantIdDepartament ()));
                    AddExpression (GetIsPrivateProperty (), Expression.Equal (GetIsPrivateProperty (), GetConstantIsPrivateFalse ()));
                    AddExpression (GetIdUserProperty (), Expression.NotEqual (GetIdUserProperty (), GetConstantIdUser ()));
                }
                if ( CurrentUser.Grant.OtherPersonal != GrantType.NotRead )
                {
                    AddExpression (GetIdDepartamentProperty (), Expression.NotEqual (GetIdDepartamentProperty (), GetConstantIdDepartament ()));
                    AddExpression (GetIsPrivateProperty (), Expression.Equal (GetIsPrivateProperty (), GetConstantIsPrivateFalse ()));
                }
                if ( CurrentUser.Grant.ForeignPrivate != GrantType.NotRead )
                    AddExpression (GetIsPrivateProperty (), Expression.Equal (GetIsPrivateProperty (), GetConstantIsPrivateTrue ()));
            }
        }

        private void AddExpression (MemberExpression property, Expression expression)
        {
            string propertyName = property.ToString ();
            if ( _regulationDictionary.ContainsKey (propertyName) )
            {
                if ( !ExpressionContains (_regulationDictionary[propertyName], expression) )
                    _regulationDictionary[propertyName].Add (expression);
            }
            else _regulationDictionary.Add (propertyName, new List<Expression> () { expression });
        }

        private bool ExpressionContains (List<Expression> expressions, Expression expression)
        {
            foreach ( var item in expressions )
                if ( item.ToString () == expression.ToString () )
                    return true;
            return false;
        }

        #region
        private MemberExpression GetAccessParameter ()
        {
            return Expression.Property (_parameter, "AccessType");
        }

        private MemberExpression GetIdUserProperty ()
        {
            return Expression.Property (GetAccessParameter (), "IdUser");
        }

        private MemberExpression GetIdDepartamentProperty ()
        {
            return Expression.Property (GetAccessParameter ().ReduceExtensions (), "IdDepartament");
        }

        private MemberExpression GetIsPrivateProperty ()
        {
            return Expression.Property (GetAccessParameter ().ReduceExtensions (), "IsPrivate");
        }

        private UnaryExpression GetConstantIdUser ()
        {
            return  Expression.Convert(Expression.Constant (CurrentUser.Departament.Id), typeof (decimal?));
        }

        private UnaryExpression GetConstantIdUserNull ()
        {
            return  Expression.Convert(Expression.Constant (decimal.Zero), typeof(decimal?));
        }

        private UnaryExpression GetConstantIdDepartament ()
        {
            return  Expression.Convert(Expression.Constant (CurrentUser.Departament.Id), typeof (decimal?));
        }

        private ConstantExpression GetConstantIsPrivateTrue ()
        {
            return Expression.Constant (true);
        }

        private ConstantExpression GetConstantIsPrivateFalse ()
        {
            return Expression.Constant (false);
        }
        #endregion

        public static Expression And (Expression left, Expression right)
        {
            return Expression.AndAlso (left, right);
        }

        public static Expression Or (Expression left, Expression right)
        {
            return Expression.OrElse (left, right);
        }

        public static implicit operator Expression<Func<TEntity, bool>> (AccessReadExpression<TEntity> access)
        {
            return access.AccessExpression;
        }
    }
}
