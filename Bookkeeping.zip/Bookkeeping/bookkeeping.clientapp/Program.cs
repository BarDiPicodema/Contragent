﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using Bookkeeping.ClientApp.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main ()
        {
            Application.EnableVisualStyles ();
            Application.SetCompatibleTextRenderingDefault (false);

            LoginPresenter presenter = new LoginPresenter (new LoginWindow (), new ServiceModel<Bookkeeping.Data.Entities.User> ());
            presenter.Run ();

            Application.Run (ModelClient.Instance.ClientContext);
        }
    }
}
