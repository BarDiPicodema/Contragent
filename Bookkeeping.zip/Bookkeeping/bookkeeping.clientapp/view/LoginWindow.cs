﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View
{
    public partial class LoginWindow : Form, Bookkeeping.ClientApp.Presenter.ClientPresenter.ILoginView
    {
        public List<string> Usernames
        {
            get { return LoginList.DataSource as List<string>; }
            set { LoginList.DataSource = value; }
        }
        public string Username { get { return LoginList.Text; } }
        public string Password { get { return PasswordField.Text; } }

        public event Action Login;

        public LoginWindow ()
        {
            InitializeComponent ();

            Usernames = new List<string> ();
            LogIn.Click += (sender, args) => Invoke (Login);
        }

        public new void Show ()
        {
            base.Show ();
        }

        private void Invoke (Action action)
        {
            if ( action != null )
                action ();
        }
    }
}
