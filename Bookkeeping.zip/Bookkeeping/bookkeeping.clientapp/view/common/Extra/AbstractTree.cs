﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Common.Extra
{
    public class AbstractTree : Common.CUIControl
    {
        public AbstractTree ()
        {
            InitializeComponent ();

            _checkedProcess = false;
        }

        protected bool _checkedProcess;
        protected TreeView Tree;
        
        public Action CheckedNode;
        
        protected virtual void Tree_AfterCheck (object sender, TreeViewEventArgs e)
        {
            if ( _checkedProcess == false )
            {
                _checkedProcess = true;
                CheckParent (e.Node, e.Node.Checked);
                CheckNodes (e.Node, e.Node.Checked);

                Invoke (CheckedNode);
            }
        }

        private void InitializeComponent ()
        {
            this.Tree = new System.Windows.Forms.TreeView ();
            this.SuspendLayout ();
            // 
            // Tree
            // 
            this.Tree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tree.Location = new System.Drawing.Point (0, 0);
            this.Tree.Name = "TreeControl";
            this.Tree.Size = new System.Drawing.Size (150, 150);
            this.Tree.TabIndex = 0;
            this.Tree.CheckBoxes = true;
            this.Tree.AfterCheck += Tree_AfterCheck;
            // 
            // AbstractTree
            // 
            this.Controls.Add (this.Tree);
            this.Name = "AbstractTree";
            this.ResumeLayout (false);
        }

        protected virtual void CheckNodes (TreeNode node, bool check)
        {
            if ( node.Nodes.Count == 0 )
            {
                node.Checked = check;
                _checkedProcess = false;
                return;
            }
            foreach ( TreeNode item in node.Nodes )
            {
                CheckNodes (item, check);
                item.Checked = check;
            }
        }

        protected virtual void CheckParent (TreeNode node, bool check)
        {
            node.Checked = check;
            if ( node.Parent != null )
            {
                foreach ( TreeNode item in node.Parent.Nodes )
                    if ( item.Checked == true )
                        check = true;
                CheckParent (node.Parent, check);
            }
            else return;
        }
    }
}
