﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Common.Extra
{
    public class SingleCheckTreeControl : AbstractTree
    {
        public SingleCheckTreeControl ()
            : base ()
        {
            _checkedProcess = false;
        }

        protected override void Tree_AfterCheck (object sender, TreeViewEventArgs e)
        {
            if ( e.Node.Nodes.Count == 0 )
            {
                CheckNodes (Tree.Nodes[0], false);
                e.Node.Checked = true;
                _checkedProcess = false;
                Invoke (CheckedNode);
                return;
            }
        }

        protected override void CheckNodes (TreeNode node, bool check)
        {
            if ( node != null )
            {
                node.Checked = false;
                foreach ( TreeNode item in node.Nodes )
                {
                    item.Checked = false;
                    if ( item.Nodes.Count > 0 )
                        CheckParent (item.Nodes[0], false);
                }
            }
        }

        protected override void CheckParent (TreeNode node, bool check)
        {
            base.CheckParent (node, check);
        }
    }
}
