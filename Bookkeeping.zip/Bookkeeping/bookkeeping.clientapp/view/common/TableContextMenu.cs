﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Common
{
    public class TableContextMenu : ContextMenu
    {
        public event EventHandler AddItem;
        public event EventHandler EditItem;
        
        public TableContextMenu ()
        {
            var add = new MenuItem ("Добавить");
            add.Click += (sender, args) =>
            {
                if ( AddItem != null )
                    AddItem (this, args);
            };

            var edit = new MenuItem ("Редактировать");
            edit.Click += (sender, args) => 
            {
                if (EditItem != null)
                    EditItem (this, args);
            };

            this.MenuItems.Add (add);
            this.MenuItems.Add (edit);
        }
    }
}
