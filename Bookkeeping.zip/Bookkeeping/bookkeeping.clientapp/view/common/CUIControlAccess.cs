﻿using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Common
{
    public class CUIControlAccess : CUIControl, Presenter.Common.IControlPermissionChange
    {
        public CUIControlAccess ()
        {
            _controlPresenter = new ControlPermissionChange (this, new Model.PermissionModel.AccessWritePermission (CurrentUser.User));
        }

        private ControlPermissionChange _controlPresenter;

        public bool IsEnable
        {
            get { return this.Enabled; }
            set { this.Enabled = value; }
        }

        private AccessType _access;
        public AccessType AccessType
        {
            get { return _access; }
            set 
            {
                if ( _access == null )
                    return;

                _access = value;
                Invoke (SetAccessType);
            }
        }

        private IEntityControlView _accessPresenter;
        protected IEntityControlView AccessPresenter
        {
            get { return _accessPresenter; }
            set
            {
                if ( value == null )
                    return;

                _accessPresenter = value;
                _accessPresenter.SelectedEntityChanged += (sender, args) => Invoke (SetAccessType);
            }
        }

        public event Action SetAccessType;
    }
}
