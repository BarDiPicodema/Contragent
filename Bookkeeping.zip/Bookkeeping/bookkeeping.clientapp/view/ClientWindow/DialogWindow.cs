﻿using Bookkeeping.ClientApp.Presenter.ClientPresenter;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.ClientWindow
{
    public partial class DialogWindow : Form, IDialogView
    {
        public DialogWindow ()
        {
            InitializeComponent ();
        }

        public string Title
        {
            get
            {
                return Text;
            }
            set
            {
                Text = value;
            }
        }

        public UserControl ContentControl
        {
            get
            {
                return this.Controls[0] as UserControl;
            }
            set
            {
                this.Controls.Clear ();
                this.Controls.Add(value);
            }
        }

        public new void Show ()
        {
            this.ShowDialog ();
        }
    }
}
