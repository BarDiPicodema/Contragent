﻿namespace Bookkeeping.ClientApp.View.Counterparties
{
    partial class ContractorsWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent ()
        {
            this.FormTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.FilterSplit = new System.Windows.Forms.SplitContainer();
            this.ContractorInfo = new System.Windows.Forms.SplitContainer();
            this.ContractorGrids = new System.Windows.Forms.SplitContainer();
            this.MenuSplit = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.ContractorToolStrip();
            this.FilterTree = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.FilterTreeControl();
            this.PartnerTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.PartnerGrid();
            this.ContractorTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.ContractorGrid();
            this.Info = new Bookkeeping.ClientApp.View.Counterparties.ContractorInfo.InfoTab();
            this.FormTableLayout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FilterSplit)).BeginInit();
            this.FilterSplit.Panel1.SuspendLayout();
            this.FilterSplit.Panel2.SuspendLayout();
            this.FilterSplit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContractorInfo)).BeginInit();
            this.ContractorInfo.Panel1.SuspendLayout();
            this.ContractorInfo.Panel2.SuspendLayout();
            this.ContractorInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContractorGrids)).BeginInit();
            this.ContractorGrids.Panel1.SuspendLayout();
            this.ContractorGrids.Panel2.SuspendLayout();
            this.ContractorGrids.SuspendLayout();
            this.SuspendLayout();
            // 
            // FormTableLayout
            // 
            this.FormTableLayout.ColumnCount = 1;
            this.FormTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.FormTableLayout.Controls.Add(this.MenuSplit, 0, 0);
            this.FormTableLayout.Controls.Add(this.FilterSplit, 0, 1);
            this.FormTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FormTableLayout.Location = new System.Drawing.Point(0, 0);
            this.FormTableLayout.Name = "FormTableLayout";
            this.FormTableLayout.RowCount = 2;
            this.FormTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.FormTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.FormTableLayout.Size = new System.Drawing.Size(800, 540);
            this.FormTableLayout.TabIndex = 0;
            // 
            // FilterSplit
            // 
            this.FilterSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FilterSplit.Location = new System.Drawing.Point(3, 29);
            this.FilterSplit.Name = "FilterSplit";
            // 
            // FilterSplit.Panel1
            // 
            this.FilterSplit.Panel1.Controls.Add(this.FilterTree);
            // 
            // FilterSplit.Panel2
            // 
            this.FilterSplit.Panel2.Controls.Add(this.ContractorInfo);
            this.FilterSplit.Size = new System.Drawing.Size(794, 508);
            this.FilterSplit.SplitterDistance = 204;
            this.FilterSplit.TabIndex = 1;
            // 
            // ContractorInfo
            // 
            this.ContractorInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContractorInfo.Location = new System.Drawing.Point(0, 0);
            this.ContractorInfo.Name = "ContractorInfo";
            this.ContractorInfo.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // ContractorInfo.Panel1
            // 
            this.ContractorInfo.Panel1.Controls.Add(this.ContractorGrids);
            // 
            // ContractorInfo.Panel2
            // 
            this.ContractorInfo.Panel2.Controls.Add(this.Info);
            this.ContractorInfo.Size = new System.Drawing.Size(586, 508);
            this.ContractorInfo.SplitterDistance = 370;
            this.ContractorInfo.TabIndex = 0;
            // 
            // ContractorGrids
            // 
            this.ContractorGrids.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContractorGrids.Location = new System.Drawing.Point(0, 0);
            this.ContractorGrids.Name = "ContractorGrids";
            this.ContractorGrids.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // ContractorGrids.Panel1
            // 
            this.ContractorGrids.Panel1.Controls.Add(this.PartnerTable);
            // 
            // ContractorGrids.Panel2
            // 
            this.ContractorGrids.Panel2.Controls.Add(this.ContractorTable);
            this.ContractorGrids.Size = new System.Drawing.Size(586, 370);
            this.ContractorGrids.SplitterDistance = 184;
            this.ContractorGrids.TabIndex = 0;
            // 
            // MenuSplit
            // 
            this.MenuSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MenuSplit.Location = new System.Drawing.Point(0, 0);
            this.MenuSplit.Margin = new System.Windows.Forms.Padding(0);
            this.MenuSplit.Name = "MenuSplit";
            this.MenuSplit.NameTitle = null;
            this.MenuSplit.Size = new System.Drawing.Size(800, 26);
            this.MenuSplit.TabIndex = 0;
            // 
            // FilterTree
            // 
            this.FilterTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FilterTree.Location = new System.Drawing.Point(0, 0);
            this.FilterTree.Name = "FilterTree";
            this.FilterTree.NameTitle = null;
            this.FilterTree.Size = new System.Drawing.Size(204, 508);
            this.FilterTree.TabIndex = 0;
            // 
            // PartnerTable
            // 
            this.PartnerTable.DataSource = null;
            this.PartnerTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PartnerTable.Location = new System.Drawing.Point(0, 0);
            this.PartnerTable.Name = "PartnerTable";
            this.PartnerTable.NameTitle = null;
            this.PartnerTable.Size = new System.Drawing.Size(586, 184);
            this.PartnerTable.TabIndex = 0;
            // 
            // ContractorTable
            // 
            this.ContractorTable.DataSource = null;
            this.ContractorTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContractorTable.Location = new System.Drawing.Point(0, 0);
            this.ContractorTable.Name = "ContractorTable";
            this.ContractorTable.NameTitle = null;
            this.ContractorTable.Size = new System.Drawing.Size(586, 182);
            this.ContractorTable.TabIndex = 0;
            // 
            // Info
            // 
            this.Info.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Info.Location = new System.Drawing.Point(0, 0);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(586, 134);
            this.Info.TabIndex = 0;
            // 
            // ContractorsWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 540);
            this.Controls.Add(this.FormTableLayout);
            this.Name = "ContractorsWindow";
            this.Text = "ContractorsWindow";
            this.FormTableLayout.ResumeLayout(false);
            this.FilterSplit.Panel1.ResumeLayout(false);
            this.FilterSplit.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FilterSplit)).EndInit();
            this.FilterSplit.ResumeLayout(false);
            this.ContractorInfo.Panel1.ResumeLayout(false);
            this.ContractorInfo.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContractorInfo)).EndInit();
            this.ContractorInfo.ResumeLayout(false);
            this.ContractorGrids.Panel1.ResumeLayout(false);
            this.ContractorGrids.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContractorGrids)).EndInit();
            this.ContractorGrids.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel FormTableLayout;
        private MenuControls.ContractorToolStrip MenuSplit;
        private System.Windows.Forms.SplitContainer FilterSplit;
        private System.Windows.Forms.SplitContainer ContractorInfo;
        private System.Windows.Forms.SplitContainer ContractorGrids;
        private TableControls.PartnerGrid PartnerTable;
        private TableControls.ContractorGrid ContractorTable;
        private ContractorInfo.InfoTab Info;
        private ExtraControls.FilterTreeControl FilterTree;

    }
}