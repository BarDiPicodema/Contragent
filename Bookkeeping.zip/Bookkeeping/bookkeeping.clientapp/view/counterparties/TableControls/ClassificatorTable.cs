﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;

namespace Bookkeeping.ClientApp.View.Counterparties.TableControls
{
    public partial class ClassificatorTable : Common.CUIControl, IClassificatorGridView
    {
        public ClassificatorTable ()
        {
            InitializeComponent ();
            Table.MultiSelect = false;

            ColumnNames.SelectedIndexChanged += (sender, args) => Invoke (SelectedItem);
            SearchField.LostFocus += (sender, args) => Invoke (Search);

            SaveClassificator.Click += (sender, args) => Invoke (AddItem);
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public object DataSource
        {
            get { return Source.DataSource; }
            set 
            { 
                Source.DataSource = value;
                Table.DataSource = Source;
            }
        }

        public string Filter
        {
            get { return SearchField.Text; }
            set { SearchField.Text = value; }
        }

        public string Column
        {
            get { return ColumnNames.Text; }
        }

        public object SelectedClassificator
        {
            get { return Table.CurrentRow.DataBoundItem; }
        }

        List<string> IClassificatorGridView.ColumnNames
        {
            get 
            {
                List<string> names = new List<string> ();
                foreach ( var item in ColumnNames.Items )
                    names.Add (item.ToString());
                return names; 
            }
            set 
            {
                foreach ( var item in value )
                    ColumnNames.Items.Add (item);
            }
        }

        public BindingSource Source
        {
            get { return Table.DataSource as BindingSource; }
            set 
            { 
                var binding = new BindingSource ();
                binding.DataSource = value;
                Table.DataSource = value;
            }
        }

        public event Action Search;

        public event Action SelectedItem;

        public event Action AddItem;

        public event Action EditItem;

        public new Form Parent
        {
            get { return this.ParentForm; }
        }
    }
}
