﻿namespace Bookkeeping.ClientApp.View.Counterparties.TableControls
{
    partial class DocumentGrid
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.Table = new System.Windows.Forms.DataGridView();
            this.Flag = new System.Windows.Forms.DataGridViewImageColumn();
            this.NameDocument = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DocumentNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Table)).BeginInit();
            this.SuspendLayout();
            // 
            // Table
            // 
            this.Table.AllowUserToAddRows = false;
            this.Table.AllowUserToDeleteRows = false;
            this.Table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Flag,
            this.NameDocument,
            this.DocumentNote});
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.Location = new System.Drawing.Point(0, 0);
            this.Table.Name = "Table";
            this.Table.ReadOnly = true;
            this.Table.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.Table.Size = new System.Drawing.Size(500, 150);
            this.Table.TabIndex = 0;
            // 
            // Flag
            // 
            this.Flag.DataPropertyName = "FlagImage";
            this.Flag.HeaderText = "Флаг";
            this.Flag.Name = "Flag";
            this.Flag.ReadOnly = true;
            // 
            // NameDocument
            // 
            this.NameDocument.DataPropertyName = "DocumentName";
            this.NameDocument.HeaderText = "Название";
            this.NameDocument.Name = "NameDocument";
            this.NameDocument.ReadOnly = true;
            // 
            // DocumentNote
            // 
            this.DocumentNote.DataPropertyName = "Note";
            this.DocumentNote.HeaderText = "Заметка";
            this.DocumentNote.Name = "DocumentNote";
            this.DocumentNote.ReadOnly = true;
            // 
            // DocumentGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Table);
            this.Name = "DocumentGrid";
            this.Size = new System.Drawing.Size(500, 150);
            ((System.ComponentModel.ISupportInitialize)(this.Table)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Table;
        private System.Windows.Forms.DataGridViewImageColumn Flag;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameDocument;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocumentNote;
    }
}
