﻿namespace Bookkeeping.ClientApp.View.Counterparties.TableControls
{
    partial class ContactGrid
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.Table = new System.Windows.Forms.DataGridView();
            this.FlagContact = new System.Windows.Forms.DataGridViewImageColumn();
            this.ContactType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sub = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Post = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Table)).BeginInit();
            this.SuspendLayout();
            // 
            // Table
            // 
            this.Table.AllowUserToAddRows = false;
            this.Table.AllowUserToDeleteRows = false;
            this.Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FlagContact,
            this.ContactType,
            this.ContactText,
            this.ContactName,
            this.Sub,
            this.Post,
            this.Note});
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.Location = new System.Drawing.Point(0, 0);
            this.Table.Name = "Table";
            this.Table.ReadOnly = true;
            this.Table.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.Table.Size = new System.Drawing.Size(500, 150);
            this.Table.TabIndex = 0;
            // 
            // FlagContact
            // 
            this.FlagContact.DataPropertyName = "Flag.FlagImage";
            this.FlagContact.HeaderText = "Флаг";
            this.FlagContact.MinimumWidth = 30;
            this.FlagContact.Name = "FlagContact";
            this.FlagContact.ReadOnly = true;
            this.FlagContact.Width = 40;
            // 
            // ContactType
            // 
            this.ContactType.DataPropertyName = "TypeName";
            this.ContactType.HeaderText = "Тип контакта";
            this.ContactType.MinimumWidth = 90;
            this.ContactType.Name = "ContactType";
            this.ContactType.ReadOnly = true;
            // 
            // ContactText
            // 
            this.ContactText.DataPropertyName = "ContactText";
            this.ContactText.HeaderText = "Контакт";
            this.ContactText.Name = "ContactText";
            this.ContactText.ReadOnly = true;
            // 
            // ContactName
            // 
            this.ContactName.DataPropertyName = "ContactName";
            this.ContactName.HeaderText = "ФИО";
            this.ContactName.Name = "ContactName";
            this.ContactName.ReadOnly = true;
            // 
            // Sub
            // 
            this.Sub.DataPropertyName = "Sub";
            this.Sub.HeaderText = "Подразделение";
            this.Sub.MinimumWidth = 100;
            this.Sub.Name = "Sub";
            this.Sub.ReadOnly = true;
            // 
            // Post
            // 
            this.Post.DataPropertyName = "Post";
            this.Post.HeaderText = "Должность";
            this.Post.MinimumWidth = 100;
            this.Post.Name = "Post";
            this.Post.ReadOnly = true;
            // 
            // Note
            // 
            this.Note.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Note.DataPropertyName = "Note";
            this.Note.HeaderText = "Заметка";
            this.Note.MinimumWidth = 100;
            this.Note.Name = "Note";
            this.Note.ReadOnly = true;
            // 
            // ContactGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Table);
            this.Name = "ContactGrid";
            this.Size = new System.Drawing.Size(500, 150);
            ((System.ComponentModel.ISupportInitialize)(this.Table)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Table;
        private System.Windows.Forms.DataGridViewImageColumn FlagContact;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactText;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sub;
        private System.Windows.Forms.DataGridViewTextBoxColumn Post;
        private System.Windows.Forms.DataGridViewTextBoxColumn Note;
    }
}
