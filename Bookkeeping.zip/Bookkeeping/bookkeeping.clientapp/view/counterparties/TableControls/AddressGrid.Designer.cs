﻿namespace Bookkeeping.ClientApp.View.Counterparties.TableControls
{
    partial class AddressGrid
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.Table = new System.Windows.Forms.DataGridView();
            this.FlagAddress = new System.Windows.Forms.DataGridViewImageColumn();
            this.AddressType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PostCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Land = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.City = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Settlement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Street = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.House = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Structure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Porch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Office = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddressNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Table)).BeginInit();
            this.SuspendLayout();
            // 
            // Table
            // 
            this.Table.AllowUserToAddRows = false;
            this.Table.AllowUserToDeleteRows = false;
            this.Table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FlagAddress,
            this.AddressType,
            this.PostCode,
            this.Land,
            this.City,
            this.Settlement,
            this.Street,
            this.House,
            this.Structure,
            this.Porch,
            this.Office,
            this.AddressNote});
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.Location = new System.Drawing.Point(0, 0);
            this.Table.MultiSelect = false;
            this.Table.Name = "Table";
            this.Table.ReadOnly = true;
            this.Table.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.Table.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Table.Size = new System.Drawing.Size(559, 150);
            this.Table.TabIndex = 0;
            // 
            // FlagAddress
            // 
            this.FlagAddress.DataPropertyName = "FlagImage";
            this.FlagAddress.HeaderText = "Флаг";
            this.FlagAddress.MinimumWidth = 30;
            this.FlagAddress.Name = "FlagAddress";
            this.FlagAddress.ReadOnly = true;
            this.FlagAddress.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FlagAddress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FlagAddress.Width = 45;
            // 
            // AddressType
            // 
            this.AddressType.DataPropertyName = "TypeName";
            this.AddressType.HeaderText = "Тип адреса";
            this.AddressType.MinimumWidth = 100;
            this.AddressType.Name = "AddressType";
            this.AddressType.ReadOnly = true;
            // 
            // PostCode
            // 
            this.PostCode.DataPropertyName = "PostCode";
            this.PostCode.HeaderText = "Индекс";
            this.PostCode.Name = "PostCode";
            this.PostCode.ReadOnly = true;
            // 
            // Land
            // 
            this.Land.DataPropertyName = "Land";
            this.Land.HeaderText = "Страна";
            this.Land.Name = "Land";
            this.Land.ReadOnly = true;
            // 
            // City
            // 
            this.City.DataPropertyName = "City";
            this.City.HeaderText = "Город";
            this.City.Name = "City";
            this.City.ReadOnly = true;
            // 
            // Settlement
            // 
            this.Settlement.DataPropertyName = "Settlement";
            this.Settlement.HeaderText = "Район";
            this.Settlement.Name = "Settlement";
            this.Settlement.ReadOnly = true;
            // 
            // Street
            // 
            this.Street.DataPropertyName = "Street";
            this.Street.HeaderText = "Улица";
            this.Street.Name = "Street";
            this.Street.ReadOnly = true;
            // 
            // House
            // 
            this.House.DataPropertyName = "House";
            this.House.HeaderText = "Дом";
            this.House.Name = "House";
            this.House.ReadOnly = true;
            // 
            // Structure
            // 
            this.Structure.DataPropertyName = "Structure";
            this.Structure.HeaderText = "Строение";
            this.Structure.Name = "Structure";
            this.Structure.ReadOnly = true;
            // 
            // Porch
            // 
            this.Porch.DataPropertyName = "Porch";
            this.Porch.HeaderText = "Подъезд";
            this.Porch.Name = "Porch";
            this.Porch.ReadOnly = true;
            // 
            // Office
            // 
            this.Office.DataPropertyName = "Office";
            this.Office.HeaderText = "Офис";
            this.Office.Name = "Office";
            this.Office.ReadOnly = true;
            // 
            // AddressNote
            // 
            this.AddressNote.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.AddressNote.DataPropertyName = "Note";
            this.AddressNote.HeaderText = "Заметка";
            this.AddressNote.Name = "AddressNote";
            this.AddressNote.ReadOnly = true;
            this.AddressNote.Width = 76;
            // 
            // AddressGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Table);
            this.Name = "AddressGrid";
            this.Size = new System.Drawing.Size(559, 150);
            ((System.ComponentModel.ISupportInitialize)(this.Table)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Table;
        private System.Windows.Forms.DataGridViewImageColumn FlagAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressType;
        private System.Windows.Forms.DataGridViewTextBoxColumn PostCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Land;
        private System.Windows.Forms.DataGridViewTextBoxColumn City;
        private System.Windows.Forms.DataGridViewTextBoxColumn Settlement;
        private System.Windows.Forms.DataGridViewTextBoxColumn Street;
        private System.Windows.Forms.DataGridViewTextBoxColumn House;
        private System.Windows.Forms.DataGridViewTextBoxColumn Structure;
        private System.Windows.Forms.DataGridViewTextBoxColumn Porch;
        private System.Windows.Forms.DataGridViewTextBoxColumn Office;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressNote;
    }
}
