﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.Model;
using Bookkeeping.ClientApp.Model.Util;

namespace Bookkeeping.ClientApp.View.Counterparties.TableControls
{
    public partial class AddressGrid : Common.CUIControl, ITemplateGridView<Address>
    {
        public AddressGrid ()
        {
            InitializeComponent ();
            Table.AutoGenerateColumns = false;
            Table.MultiSelect = false;

            var menu = new Common.TableContextMenu ();
            menu.AddItem += (obj, arg) => Invoke (AddItem);
            menu.EditItem += (obj, arg) => Invoke (EditItem);
            Table.ContextMenu = menu;
            
            Table.MouseClick += (sender, args) =>
            {
                if ( args.Button == System.Windows.Forms.MouseButtons.Left )
                    Invoke (SelectedItem);
            };

            Table.MouseClick += (sender, args) =>
            {
                if ( args.Button == System.Windows.Forms.MouseButtons.Right )
                    Table.ContextMenu.Show (this, new Point (args.X, args.Y));
            };

            Table.DoubleClick += (sender, args) => Invoke (EditItem);

            Presenter = new AddressGridPresenter (this, new AccessServiceModel<Address> ());
        }

        public Address SelectedEntity
        {
            get
            {
                if ( Table.CurrentRow != null )
                    return (Table.CurrentRow.DataBoundItem as AddressRow).Address;
                else return null;
            }
        }

        public IPresenter Presenter
        {
            get;
            set;
        }

        public object DataSource
        {
            get { return Table.DataSource; }
            set { Table.DataSource = value; }
        }

        public event Action SelectedItem;
        public event Action AddItem;
        public event Action EditItem;
    }
}
