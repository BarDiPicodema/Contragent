﻿namespace Bookkeeping.ClientApp.View.Counterparties.TableControls
{
    partial class PartnerGrid
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.Table = new System.Windows.Forms.DataGridView();
            this.Signing = new System.Windows.Forms.DataGridViewImageColumn();
            this.Flag = new System.Windows.Forms.DataGridViewImageColumn();
            this.Alias = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Activity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Process = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Table)).BeginInit();
            this.SuspendLayout();
            // 
            // Table
            // 
            this.Table.AllowUserToAddRows = false;
            this.Table.AllowUserToDeleteRows = false;
            this.Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Signing,
            this.Flag,
            this.Alias,
            this.Activity,
            this.Process});
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.Location = new System.Drawing.Point(0, 0);
            this.Table.Name = "Table";
            this.Table.ReadOnly = true;
            this.Table.Size = new System.Drawing.Size(600, 140);
            this.Table.TabIndex = 0;
            // 
            // Signing
            // 
            this.Signing.DataPropertyName = "SigningImage";
            this.Signing.HeaderText = "!!!";
            this.Signing.Name = "Signing";
            this.Signing.ReadOnly = true;
            this.Signing.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Signing.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Signing.Width = 36;
            // 
            // Flag
            // 
            this.Flag.DataPropertyName = "Flag.FlagImage";
            this.Flag.HeaderText = "Флаг";
            this.Flag.Name = "Flag";
            this.Flag.ReadOnly = true;
            this.Flag.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Flag.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Flag.Width = 42;
            // 
            // Alias
            // 
            this.Alias.DataPropertyName = "Alias";
            this.Alias.HeaderText = "Псевдоним";
            this.Alias.Name = "Alias";
            this.Alias.ReadOnly = true;
            // 
            // Activity
            // 
            this.Activity.DataPropertyName = "Activity";
            this.Activity.HeaderText = "Деятельность";
            this.Activity.Name = "Activity";
            this.Activity.ReadOnly = true;
            // 
            // Process
            // 
            this.Process.DataPropertyName = "Process";
            this.Process.HeaderText = "Процесс";
            this.Process.Name = "Process";
            this.Process.ReadOnly = true;
            // 
            // PartnerGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Table);
            this.Name = "PartnerGrid";
            this.Size = new System.Drawing.Size(600, 140);
            ((System.ComponentModel.ISupportInitialize)(this.Table)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Table;
        private System.Windows.Forms.DataGridViewImageColumn Signing;
        private System.Windows.Forms.DataGridViewImageColumn Flag;
        private System.Windows.Forms.DataGridViewTextBoxColumn Alias;
        private System.Windows.Forms.DataGridViewTextBoxColumn Activity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Process;
    }
}
