﻿namespace Bookkeeping.ClientApp.View.Counterparties.TableControls
{
    partial class AccountGrid
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.Table = new System.Windows.Forms.DataGridView();
            this.FlagAccount = new System.Windows.Forms.DataGridViewImageColumn();
            this.Kind = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AccountNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Okv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Extra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Table)).BeginInit();
            this.SuspendLayout();
            // 
            // Table
            // 
            this.Table.AllowUserToAddRows = false;
            this.Table.AllowUserToDeleteRows = false;
            this.Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FlagAccount,
            this.Kind,
            this.Type,
            this.AccountNumber,
            this.Okv,
            this.Extra});
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.Location = new System.Drawing.Point(0, 0);
            this.Table.Name = "Table";
            this.Table.ReadOnly = true;
            this.Table.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.Table.Size = new System.Drawing.Size(500, 150);
            this.Table.TabIndex = 0;
            // 
            // FlagAccount
            // 
            this.FlagAccount.DataPropertyName = "FlagImage";
            this.FlagAccount.HeaderText = "Флаг";
            this.FlagAccount.MinimumWidth = 30;
            this.FlagAccount.Name = "FlagAccount";
            this.FlagAccount.ReadOnly = true;
            this.FlagAccount.Width = 40;
            // 
            // Kind
            // 
            this.Kind.DataPropertyName = "KindName";
            this.Kind.HeaderText = "Вид";
            this.Kind.Name = "Kind";
            this.Kind.ReadOnly = true;
            // 
            // Type
            // 
            this.Type.DataPropertyName = "TypeName";
            this.Type.HeaderText = "Тип";
            this.Type.Name = "Type";
            this.Type.ReadOnly = true;
            // 
            // AccountNumber
            // 
            this.AccountNumber.DataPropertyName = "AccountNumber";
            this.AccountNumber.HeaderText = "Счет";
            this.AccountNumber.Name = "AccountNumber";
            this.AccountNumber.ReadOnly = true;
            // 
            // Okv
            // 
            this.Okv.DataPropertyName = "OkvName";
            this.Okv.HeaderText = "OKВ";
            this.Okv.Name = "Okv";
            this.Okv.ReadOnly = true;
            // 
            // Extra
            // 
            this.Extra.DataPropertyName = "Note";
            this.Extra.HeaderText = "Заметка";
            this.Extra.Name = "Extra";
            this.Extra.ReadOnly = true;
            // 
            // AccountGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Table);
            this.Name = "AccountGrid";
            this.Size = new System.Drawing.Size(500, 150);
            ((System.ComponentModel.ISupportInitialize)(this.Table)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Table;
        private System.Windows.Forms.DataGridViewImageColumn FlagAccount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kind;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn AccountNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Okv;
        private System.Windows.Forms.DataGridViewTextBoxColumn Extra;
    }
}
