﻿namespace Bookkeeping.ClientApp.View.Counterparties.MenuControls
{
    partial class EditorToolStrip
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.ToolStripEditor = new System.Windows.Forms.ToolStrip();
            this.Save = new System.Windows.Forms.ToolStripButton();
            this.Delete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripEditor.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolStripEditor
            // 
            this.ToolStripEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ToolStripEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Save,
            this.Delete,
            this.toolStripSeparator1});
            this.ToolStripEditor.Location = new System.Drawing.Point(0, 0);
            this.ToolStripEditor.Name = "ToolStripEditor";
            this.ToolStripEditor.Size = new System.Drawing.Size(400, 27);
            this.ToolStripEditor.TabIndex = 0;
            this.ToolStripEditor.Text = "toolStrip1";
            // 
            // Save
            // 
            this.Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Save.Image = global::Bookkeeping.ClientApp.Properties.Resources.save;
            this.Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(23, 24);
            this.Save.Text = "Сохранить контрагента";
            // 
            // Delete
            // 
            this.Delete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Delete.Image = global::Bookkeeping.ClientApp.Properties.Resources.delete;
            this.Delete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(23, 24);
            this.Delete.Text = "Удалить контрагента";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // EditorToolStrip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ToolStripEditor);
            this.Name = "EditorToolStrip";
            this.Size = new System.Drawing.Size(400, 27);
            this.ToolStripEditor.ResumeLayout(false);
            this.ToolStripEditor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip ToolStripEditor;
        private System.Windows.Forms.ToolStripButton Save;
        private System.Windows.Forms.ToolStripButton Delete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;

    }
}
