﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Counterparties.MenuControls
{
    public partial class EditorToolStrip : Common.CUIControl, Presenter.Counterparties.Menu.IEditorToolView
    {
        public event Action SaveData;
        public event Action DeleteData;

        public EditorToolStrip ()
        {
            InitializeComponent ();

            Save.Click += (sender, args) => Invoke (SaveData);
            Delete.Click += (sender, args) => Invoke (DeleteData);
        }
    }
}
