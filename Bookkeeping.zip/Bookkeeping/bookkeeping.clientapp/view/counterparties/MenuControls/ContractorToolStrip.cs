﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.MenuControls
{
    public partial class ContractorToolStrip : Common.CUIControl, IContractorMenuView
    {
        public ContractorToolStrip ()
        {
            InitializeComponent ();

            SearchTree = new SearchTreeControl () { Width = 200, Height = 200 };
            Popup = new PopupControl.Popup (SearchTree);
            Popup.Resizable = true;

            Presenter = new ContractorMenuPresenter (this);

            SearchSettings.Click += SearchSettings_Click;
            AddContractor.Click += (sender, arg) => Invoke (NewContractor);
            ContractorView.Click += (sender, arg) => Invoke (ShowContractor);
            PrintContacts.Click += (sender, arg) => Invoke (PrintPhone);
            PrintContractorCard.Click += (sender, arg) => Invoke (PrintDataContractor);
            Search.Click += (sender, arg) => Invoke (SearchRun);
        }

        private SearchTreeControl SearchTree { get; set; }
        private PopupControl.Popup Popup { get; set; }

        public IPresenter Presenter { get; set; }

        public ISearchTreeView SearchTreeView
        {
            get { return SearchTree; }
        }

        public SearchTreePresenter SearchTreePresenter
        {
            get { return SearchTree.Presenter as SearchTreePresenter; }
        }

        public string SearchValue
        {
            get { return ValueField.Text; }
        }
        
        public event Action NewContractor;

        public event Action ShowContractor;

        public event Action PrintPhone;

        public event Action PrintDataContractor;

        public event Action SearchRun;


        private void SearchSettings_Click (object sender, EventArgs e)
        {
            var button = sender as ToolStripButton;
            Point location = new Point ();
            location.X = MenuItems.RectangleToScreen (button.ContentRectangle).X + button.Bounds.X;
            location.Y = MenuItems.RectangleToScreen (button.ContentRectangle).Y + button.Size.Height;
            Popup.Show (location);
        }
    }
}
