﻿namespace Bookkeeping.ClientApp.View.Counterparties.MenuControls
{
    partial class ContractorToolStrip
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MenuItems = new System.Windows.Forms.ToolStrip();
            this.AddContractor = new System.Windows.Forms.ToolStripButton();
            this.ContractorView = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.PrintContacts = new System.Windows.Forms.ToolStripMenuItem();
            this.PrintContractorCard = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ValueField = new System.Windows.Forms.ToolStripTextBox();
            this.Search = new System.Windows.Forms.ToolStripButton();
            this.SearchSettings = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItems.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuItems
            // 
            this.MenuItems.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddContractor,
            this.ContractorView,
            this.toolStripSeparator1,
            this.toolStripDropDownButton1,
            this.toolStripSeparator2,
            this.ValueField,
            this.Search,
            this.SearchSettings,
            this.toolStripSeparator3});
            this.MenuItems.Location = new System.Drawing.Point(0, 0);
            this.MenuItems.Name = "MenuItems";
            this.MenuItems.Size = new System.Drawing.Size(626, 25);
            this.MenuItems.TabIndex = 0;
            this.MenuItems.Text = "toolStrip1";
            // 
            // AddContractor
            // 
            this.AddContractor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.AddContractor.Image = global::Bookkeeping.ClientApp.Properties.Resources.contractor_add;
            this.AddContractor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddContractor.Name = "AddContractor";
            this.AddContractor.Size = new System.Drawing.Size(23, 22);
            this.AddContractor.Text = "Добавить контрагента";
            // 
            // ContractorView
            // 
            this.ContractorView.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ContractorView.Image = global::Bookkeeping.ClientApp.Properties.Resources.reading_view;
            this.ContractorView.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ContractorView.Name = "ContractorView";
            this.ContractorView.Size = new System.Drawing.Size(23, 22);
            this.ContractorView.Text = "Просмотреть контрагента";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PrintContacts,
            this.PrintContractorCard});
            this.toolStripDropDownButton1.Image = global::Bookkeeping.ClientApp.Properties.Resources.printer;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "Печать данных";
            // 
            // PrintContacts
            // 
            this.PrintContacts.Name = "PrintContacts";
            this.PrintContacts.Size = new System.Drawing.Size(195, 22);
            this.PrintContacts.Text = "Печать телефонов";
            // 
            // PrintContractorCard
            // 
            this.PrintContractorCard.Name = "PrintContractorCard";
            this.PrintContractorCard.Size = new System.Drawing.Size(195, 22);
            this.PrintContractorCard.Text = "Карточка контрагента";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // ValueField
            // 
            this.ValueField.Name = "ValueField";
            this.ValueField.Size = new System.Drawing.Size(100, 25);
            // 
            // Search
            // 
            this.Search.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Search.Image = global::Bookkeeping.ClientApp.Properties.Resources.magnifier;
            this.Search.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(23, 22);
            this.Search.Text = "Начать поиск";
            // 
            // SearchSettings
            // 
            this.SearchSettings.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SearchSettings.Image = global::Bookkeeping.ClientApp.Properties.Resources.gear;
            this.SearchSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SearchSettings.Name = "SearchSettings";
            this.SearchSettings.Size = new System.Drawing.Size(23, 22);
            this.SearchSettings.Text = "Поля для поиска";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // ContractorToolStrip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MenuItems);
            this.Name = "ContractorToolStrip";
            this.Size = new System.Drawing.Size(626, 28);
            this.MenuItems.ResumeLayout(false);
            this.MenuItems.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip MenuItems;
        private System.Windows.Forms.ToolStripButton AddContractor;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton ContractorView;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem PrintContacts;
        private System.Windows.Forms.ToolStripMenuItem PrintContractorCard;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripTextBox ValueField;
        private System.Windows.Forms.ToolStripButton Search;
        private System.Windows.Forms.ToolStripButton SearchSettings;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    }
}
