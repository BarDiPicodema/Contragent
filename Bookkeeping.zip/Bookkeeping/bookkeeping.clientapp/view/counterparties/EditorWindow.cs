﻿using Bookkeeping.ClientApp.Presenter.Counterparties;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.View.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Counterparties
{
    public partial class EditorWindow : Form, IEditContractorView
    {
        public EditorWindow ()
        {
            InitializeComponent ();
        }

        public CUIControl Control
        {
            get
            {
                return TreeSpliter.Panel2.Controls[0] as CUIControl;
            }
            set
            {
                TreeSpliter.Panel2.Controls.Clear ();
                TreeSpliter.Panel2.Controls.Add (value);
            }
        }

        public IContractorTreeView ContractorTreeView
        {
            get { return ContractorTreeNodes; }
        }

        public Presenter.Counterparties.ContractorInfo.ContractorTreePresenter ContractorTreePresenter
        {
            get { return ContractorTreeNodes.Presenter as ContractorTreePresenter; }
        }

        public Presenter.Counterparties.ContractorInfo.DetailInfoPresenter DetailInfoPresenter
        {
            get { return DetailInfoContractor.Presenter as DetailInfoPresenter; }
        }

        public Presenter.Counterparties.Menu.IEditorToolView EditorToolView
        {
            get { return ContractorEditorTool; }
        }
    }
}
