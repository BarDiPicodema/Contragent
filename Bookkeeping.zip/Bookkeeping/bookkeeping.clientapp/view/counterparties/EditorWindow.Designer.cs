﻿namespace Bookkeeping.ClientApp.View.Counterparties
{
    partial class EditorWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.MainSpliter = new System.Windows.Forms.SplitContainer();
            this.TreeSpliter = new System.Windows.Forms.SplitContainer();
            this.ContractorTreeNodes = new Bookkeeping.ClientApp.View.Counterparties.ContractorInfo.ContractorTree();
            this.DetailInfoContractor = new Bookkeeping.ClientApp.View.Counterparties.ContractorInfo.DetailInfoTab();
            this.ContractorEditorTool = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.MainTableLayout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainSpliter)).BeginInit();
            this.MainSpliter.Panel1.SuspendLayout();
            this.MainSpliter.Panel2.SuspendLayout();
            this.MainSpliter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TreeSpliter)).BeginInit();
            this.TreeSpliter.Panel1.SuspendLayout();
            this.TreeSpliter.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.MainSpliter, 0, 1);
            this.MainTableLayout.Controls.Add(this.ContractorEditorTool, 0, 0);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(820, 540);
            this.MainTableLayout.TabIndex = 0;
            // 
            // MainSpliter
            // 
            this.MainSpliter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainSpliter.Location = new System.Drawing.Point(3, 29);
            this.MainSpliter.Name = "MainSpliter";
            this.MainSpliter.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // MainSpliter.Panel1
            // 
            this.MainSpliter.Panel1.Controls.Add(this.TreeSpliter);
            // 
            // MainSpliter.Panel2
            // 
            this.MainSpliter.Panel2.Controls.Add(this.DetailInfoContractor);
            this.MainSpliter.Size = new System.Drawing.Size(814, 508);
            this.MainSpliter.SplitterDistance = 200;
            this.MainSpliter.TabIndex = 0;
            // 
            // TreeSpliter
            // 
            this.TreeSpliter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TreeSpliter.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.TreeSpliter.Location = new System.Drawing.Point(0, 0);
            this.TreeSpliter.Name = "TreeSpliter";
            // 
            // TreeSpliter.Panel1
            // 
            this.TreeSpliter.Panel1.Controls.Add(this.ContractorTreeNodes);
            // 
            // TreeSpliter.Panel2
            // 
            this.TreeSpliter.Panel2.AutoScroll = true;
            this.TreeSpliter.Size = new System.Drawing.Size(814, 200);
            this.TreeSpliter.SplitterDistance = 190;
            this.TreeSpliter.TabIndex = 0;
            // 
            // ContractorTreeNodes
            // 
            this.ContractorTreeNodes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContractorTreeNodes.Location = new System.Drawing.Point(0, 0);
            this.ContractorTreeNodes.Name = "ContractorTreeNodes";
            this.ContractorTreeNodes.NameTitle = null;
            this.ContractorTreeNodes.Size = new System.Drawing.Size(190, 200);
            this.ContractorTreeNodes.TabIndex = 0;
            // 
            // DetailInfoContractor
            // 
            this.DetailInfoContractor.Dock = System.Windows.Forms.DockStyle.Left;
            this.DetailInfoContractor.Location = new System.Drawing.Point(0, 0);
            this.DetailInfoContractor.Name = "DetailInfoContractor";
            this.DetailInfoContractor.NameTitle = null;
            this.DetailInfoContractor.Size = new System.Drawing.Size(814, 304);
            this.DetailInfoContractor.TabIndex = 0;
            // 
            // ContractorEditorTool
            // 
            this.ContractorEditorTool.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContractorEditorTool.Location = new System.Drawing.Point(0, 0);
            this.ContractorEditorTool.Margin = new System.Windows.Forms.Padding(0);
            this.ContractorEditorTool.Name = "ContractorEditorTool";
            this.ContractorEditorTool.NameTitle = null;
            this.ContractorEditorTool.Size = new System.Drawing.Size(820, 26);
            this.ContractorEditorTool.TabIndex = 1;
            // 
            // EditorWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 540);
            this.Controls.Add(this.MainTableLayout);
            this.Name = "EditorWindow";
            this.Text = "EditorWindow";
            this.MainTableLayout.ResumeLayout(false);
            this.MainSpliter.Panel1.ResumeLayout(false);
            this.MainSpliter.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainSpliter)).EndInit();
            this.MainSpliter.ResumeLayout(false);
            this.TreeSpliter.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TreeSpliter)).EndInit();
            this.TreeSpliter.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.SplitContainer MainSpliter;
        private System.Windows.Forms.SplitContainer TreeSpliter;
        private ContractorInfo.DetailInfoTab DetailInfoContractor;
        private ContractorInfo.ContractorTree ContractorTreeNodes;
        private MenuControls.EditorToolStrip ContractorEditorTool;

    }
}