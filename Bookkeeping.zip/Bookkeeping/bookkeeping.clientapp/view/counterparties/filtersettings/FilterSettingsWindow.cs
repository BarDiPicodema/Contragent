﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Counterparties.FilterSettings
{
    public partial class FilterSettingsWindow : Form, Presenter.Counterparties.Settings.IFilterSettingsView
    {
        public FilterSettingsWindow ()
        {
            InitializeComponent ();

            Save.Click += (sender, args) => Invoke (SaveFilter);
        }

        public Presenter.Counterparties.Settings.IFilterTableTreeView FilterTableTreeView
        {
            get { return FilterTableTree; }
        }

        public Presenter.Counterparties.Settings.FilterTableTreePresenter FilterTableTreePresenter
        {
            get { return FilterTableTree.Presenter as Presenter.Counterparties.Settings.FilterTableTreePresenter; }
        }

        public string NameFilter 
        { 
            get { return NameFilterField.Text; }
            set { NameFilterField.Text = value; }
        }

        public System.Windows.Forms.CheckedListBox.ObjectCollection Values
        {
            get { return ValueList.Items; }
            set { ValueList.Items.AddRange (value); }
        }

        public IList<string> SelectedValues
        {
            get
            {
                var listValue = new List<string> ();
                foreach ( var item in ValueList.CheckedItems )
                    listValue.Add (item.ToString ());
                return listValue;
            }
        }

        public event Action SaveFilter;
    }
}
