﻿namespace Bookkeeping.ClientApp.View.Counterparties.FilterSettings
{
    partial class FilterSettingsWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent ()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.MainSplitLayout = new System.Windows.Forms.SplitContainer();
            this.Save = new System.Windows.Forms.Button ();
            this.NameFilterLb = new System.Windows.Forms.Label();
            this.NameFilterField = new System.Windows.Forms.TextBox();
            this.ValueList = new System.Windows.Forms.CheckedListBox();
            this.FilterTableTree = new Bookkeeping.ClientApp.View.Counterparties.FilterSettings.Controls.FilterTableTreeControl();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainSplitLayout)).BeginInit();
            this.MainSplitLayout.Panel1.SuspendLayout();
            this.MainSplitLayout.Panel2.SuspendLayout();
            this.MainSplitLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.Controls.Add(this.MainSplitLayout, 0, 1);
            this.tableLayoutPanel1.Controls.Add (this.Save, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.NameFilterLb, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.NameFilterField, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(504, 342);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // MainSplitLayout
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.MainSplitLayout, 3);
            this.MainSplitLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainSplitLayout.Location = new System.Drawing.Point(0, 26);
            this.MainSplitLayout.Margin = new System.Windows.Forms.Padding(0);
            this.MainSplitLayout.Name = "MainSplitLayout";
            // 
            // MainSplitLayout.Panel1
            // 
            this.MainSplitLayout.Panel1.Controls.Add(this.FilterTableTree);
            // 
            // MainSplitLayout.Panel2
            // 
            this.MainSplitLayout.Panel2.Controls.Add(this.ValueList);
            this.MainSplitLayout.Size = new System.Drawing.Size(504, 290);
            this.MainSplitLayout.SplitterDistance = 249;
            this.MainSplitLayout.TabIndex = 0;
            // 
            // Save
            // 
            this.Save.Dock = System.Windows.Forms.DockStyle.Top;
            this.Save.Location = new System.Drawing.Point (366, 318);
            this.Save.Margin = new System.Windows.Forms.Padding (2);
            this.Save.Name = "SaveFilter";
            this.Save.Size = new System.Drawing.Size (136, 22);
            this.Save.TabIndex = 1;
            this.Save.Text = "Сохранить фильтр";
            this.Save.UseVisualStyleBackColor = true;
            // 
            // NameFilterLb
            // 
            this.NameFilterLb.AutoSize = true;
            this.NameFilterLb.Location = new System.Drawing.Point(267, 0);
            this.NameFilterLb.Name = "NameFilterLb";
            this.NameFilterLb.Size = new System.Drawing.Size(57, 13);
            this.NameFilterLb.TabIndex = 2;
            this.NameFilterLb.Text = "Название";
            // 
            // NameFilterField
            // 
            this.NameFilterField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NameFilterField.Location = new System.Drawing.Point(367, 3);
            this.NameFilterField.Name = "NameFilterField";
            this.NameFilterField.Size = new System.Drawing.Size(134, 20);
            this.NameFilterField.TabIndex = 3;
            // 
            // ValueList
            // 
            this.ValueList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ValueList.FormattingEnabled = true;
            this.ValueList.Location = new System.Drawing.Point(0, 0);
            this.ValueList.Name = "ValueList";
            this.ValueList.Size = new System.Drawing.Size(251, 290);
            this.ValueList.TabIndex = 0;
            // 
            // FilterTableTree
            // 
            this.FilterTableTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FilterTableTree.Location = new System.Drawing.Point(0, 0);
            this.FilterTableTree.Name = "FilterTableTree";
            this.FilterTableTree.Size = new System.Drawing.Size(249, 290);
            this.FilterTableTree.TabIndex = 0;
            // 
            // FilterSettingsWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 342);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MinimumSize = new System.Drawing.Size(520, 380);
            this.Name = "FilterSettingsWindow";
            this.Text = "FilterSettingsWindow";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.MainSplitLayout.Panel1.ResumeLayout(false);
            this.MainSplitLayout.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainSplitLayout)).EndInit();
            this.MainSplitLayout.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.SplitContainer MainSplitLayout;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Label NameFilterLb;
        private System.Windows.Forms.TextBox NameFilterField;
        private Controls.FilterTableTreeControl FilterTableTree;
        private System.Windows.Forms.CheckedListBox ValueList;
    }
}