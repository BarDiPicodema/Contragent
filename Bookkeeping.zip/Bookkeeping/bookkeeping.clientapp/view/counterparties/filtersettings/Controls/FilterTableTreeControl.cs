﻿using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Counterparties.FilterSettings.Controls
{
    /// <summary>
    /// TODO : checked parent and node
    /// </summary>
    public sealed class FilterTableTreeControl : UserControl, IFilterTableTreeView
    {
        public FilterTableTreeControl ()
        {
            InitializeComponent ();

            Presenter = new FilterTableTreePresenter (this, new Model.DatabaseReflection.FilterReflectionService ());

            _checkedProcess = false;
        }

        private bool _checkedProcess;

        public TreeView Tree;

        public object CheckedItem
        {
            get
            {
                foreach ( TreeNode item in Tree.Nodes )
                {
                    var node = GetCheckedTreeNode (item);
                    if ( node != null )
                        return node;
                }
                return null;
            }
        }

        public TreeNodeCollection Nodes
        {
            get { return Tree.Nodes; }
        }

        public IPresenter Presenter { get; set; }

        public Model.Counterparties.FilterLogic.QueryGenerator.QueryManager Manager { get; set; }

        public event Action CheckedTreeItem;
        public event Action AfterCheck;

        private void InitializeComponent ()
        {
            this.Tree = new System.Windows.Forms.TreeView ();
            this.SuspendLayout ();
            // 
            // Tree
            // 
            this.Tree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tree.Location = new System.Drawing.Point (0, 0);
            this.Tree.Name = "TreeControl";
            this.Tree.Size = new System.Drawing.Size (150, 150);
            this.Tree.TabIndex = 0;
            this.Tree.CheckBoxes = true;
            this.Tree.AfterCheck += Tree_AfterCheck;
            // 
            // AbstractTree
            // 
            this.Controls.Add (this.Tree);
            this.Name = "AbstractTree";
            this.ResumeLayout (false);
        }

        private TreeNode GetCheckedTreeNode (TreeNode node)
        {
            TreeNode checkedNode = null;
            foreach ( FilterTableNode item in node.Nodes )
                if ( item.Checked == true )
                {
                    if ( item.ElementNode.TypeProperty == Model.DatabaseReflection.TypeProperty.ColumnProperty )
                        return item;
                    checkedNode = GetCheckedTreeNode (item);
                }
            return checkedNode;
        }

        #region Checked operations
        private void Tree_AfterCheck (object sender, TreeViewEventArgs e)
        {
            if ( _checkedProcess == false )
            {
                _checkedProcess = true;
                foreach (TreeNode node in Tree.Nodes)
                    UncheckedNodes (node);

                CheckParent (e.Node, true);
                CheckNode (e.Node, true);
                _checkedProcess = false;

                if ( AfterCheck != null )
                    AfterCheck ();
                if ( CheckedTreeItem != null )
                    CheckedTreeItem ();

                return;
            }
        }

        private void CheckNode (TreeNode node, bool check)
        {
            node.Checked = check;

            if ( node.Nodes.Count == 0 )
            {
                _checkedProcess = false;
                return;
            }
            else CheckNode (node.Nodes[0], check);
        }

        private void CheckParent (TreeNode node, bool check)
        {
            node.Checked = check;
            if ( node.Parent != null )
            {
                foreach ( TreeNode item in node.Parent.Nodes )
                    if ( item.Checked == true )
                        check = true;
                CheckParent (node.Parent, check);
            }
            else return;
        }

        private void UncheckedNodes (TreeNode node)
        {
            if ( node.Nodes.Count > 0 )
                foreach ( TreeNode item in node.Nodes )
                    UncheckedNodes (item);
            node.Checked = false;
        }
        #endregion
    }
}
