﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class GroupControl : Common.CUIControl, Presenter.Counterparties.Info.IGroupView
    {
        public GroupControl ()
        {
            InitializeComponent ();
            NameTitle = "Группа";

            Presenter = new GroupPresenter (this, new Model.ServiceModel<Group> ());

            AddGroupType.Click += (sender, args) => Invoke (AddGroup);
            RemoveGroupType.Click += (sender, args) => Invoke (RemoveGroup);
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public Presenter.Counterparties.Menu.IEditorToolView ToolView
        {
            get { return GroupToolStrip; }
        }

        public IContractorGroupTypeTreeView ContractorGroupTypeView
        {
            get { return ContractorGroupTypeTree;}
        }

        public ContractorGroupTypeTreePresenter ContractorGroupTypePresenter
        {
            get { return ContractorGroupTypeTree.Presenter as ContractorGroupTypeTreePresenter; }
        }

        public IGroupTreeView GroupTreeView
        {
            get { return GroupTypeTree; }
        }

        public GroupTreePresenter GroupTreePresenter
        {
            get { return GroupTypeTree.Presenter as GroupTreePresenter; }
        }

        public event Action AddGroup;
        public event Action RemoveGroup;
    }
}
