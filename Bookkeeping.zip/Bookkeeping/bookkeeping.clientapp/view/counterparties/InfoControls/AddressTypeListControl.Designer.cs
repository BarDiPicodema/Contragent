﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    partial class AddressTypeListControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.AddressTypeList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // AddressTypeList
            // 
            this.AddressTypeList.DisplayMember = "TypeName";
            this.AddressTypeList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTypeList.FormattingEnabled = true;
            this.AddressTypeList.Location = new System.Drawing.Point(0, 0);
            this.AddressTypeList.Name = "AddressTypeList";
            this.AddressTypeList.Size = new System.Drawing.Size(150, 150);
            this.AddressTypeList.TabIndex = 0;
            this.AddressTypeList.ValueMember = "Id";
            // 
            // AddressTypeListControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.AddressTypeList);
            this.Name = "AddressTypeListControl";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox AddressTypeList;
    }
}
