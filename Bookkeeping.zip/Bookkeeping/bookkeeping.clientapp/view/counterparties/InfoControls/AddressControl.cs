﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class AddressControl : Common.CUIControlAccess, IAddressView
    {
        public IPresenter Presenter { get; set; }

        public AddressControl ()
            : base ()
        {
            InitializeComponent ();
            NameTitle = "Адрес";

            Presenter = new AddressPresenter (this, new Model.AccessServiceModel<Data.Entities.Address> ());

            AddressTypeListView.Presenter = new AddressTypesPresenter (AddressTypeListField, new Model.ServiceModel<AddressValue> ());
            AddressTypeControl.Presenter = new EntityPresenter<AddressType> (AddressTypeControl, new Model.ServiceModel<AddressType> ());
            FlagControl.Presenter = new EntityPresenter<Flag> (FlagControl, new Model.ServiceModel<Flag> ());
            AccessTypeControl.Presenter = new EntityPresenter<AccessType> (AccessTypeControl, new Model.ServiceModel<AccessType> ());
            AccessPresenter = AccessTypeView;

            OkatoField.Presenter = new ClassificatorPresenter<Okato> (OkatoField, new Model.ServiceModel<Okato> ());
            OktmoField.Presenter = new ClassificatorPresenter<Okato> (OkatoField, new Model.ServiceModel<Okato> ());
            SonoField.Presenter = new ClassificatorPresenter<Sono> (SonoField, new Model.ServiceModel<Sono> ());


        }

        public IEditorToolView ToolView
        {
            get { return AddressToolSplit as IEditorToolView; }
        }

        public Data.Entities.Address Address { get; set; }

        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        #region Properties
        public string AddressName
        {
            get { return NameField.Text; }
            set { NameField.Text = value; }
        }

        public string Land
        {
            get { return LandField.Text; }
            set { LandField.Text = value; }
        }

        public string Area
        {
            get { return AreaField.Text; }
            set { AreaField.Text = value; }
        }

        public string City
        {
            get { return CityField.Text; }
            set { CityField.Text = value; }
        }

        public string Settlement
        {
            get { return SettlementField.Text; }
            set { SettlementField.Text = value; }
        }

        public string Index
        {
            get { return IndexField.Text; }
            set { IndexField.Text = value; }
        }

        public string Street
        {
            get { return StreetField.Text; }
            set { StreetField.Text = value; }
        }

        public string House
        {
            get { return HouseField.Text; }
            set { HouseField.Text = value; }
        }

        public string Structure
        {
            get { return StructureField.Text; }
            set { StructureField.Text = value; }
        }

        public string Office
        {
            get { return OfficeField.Text; }
            set { OfficeField.Text = value; }
        }

        public string Description
        {
            get { return DescriptionField.Text; }
            set { DescriptionField.Text = value; }
        }
        #endregion

        #region Ex data properties
        public IAddressTypeListView AddressTypeListView
        {
            get { return AddressTypeListField; }
        }

        public AddressTypesPresenter AddressTypeListPresenter
        {
            get { return AddressTypeListField.Presenter as AddressTypesPresenter; }
        }

        public IEntityControlView AddressTypeView
        {
            get { return AddressTypeControl; }
        }

        public EntityPresenter<AddressType> AddressType
        {
            get { return AddressTypeControl.Presenter as EntityPresenter<AddressType>; }
        }

        public IEntityControlView AccessTypeView
        {
            get { return AccessTypeControl; }
        }

        public EntityPresenter<Data.Entities.AccessType> AccessType
        {
            get { return AccessTypeControl.Presenter as EntityPresenter<AccessType>; }
        }

        public IEntityControlView FlagView
        {
            get { return FlagControl; }
        }

        public EntityPresenter<Data.Entities.Flag> Flag
        {
            get { return FlagControl.Presenter as EntityPresenter<Flag>; }
        }
        #endregion

        #region Classificator properties
        public IClassificatorView OkatoView
        {
            get { return OkatoField; }
        }

        public ClassificatorPresenter<Okato> OkatoPresenter
        {
            get { return OkatoField.Presenter as ClassificatorPresenter<Okato>; }
        }

        public IClassificatorView OktmoView
        {
            get { return OkatoField; }
        }

        public ClassificatorPresenter<Okato> OktmoPresenter
        {
            get { return OkatoField.Presenter as ClassificatorPresenter<Okato>; }
        }

        public IClassificatorView SonoView
        {
            get { return SonoField; }
        }

        public ClassificatorPresenter<Sono> SonoPresenter
        {
            get { return SonoField.Presenter as ClassificatorPresenter<Sono>; }
        }
        #endregion

        public event Action InfoChange;

        public bool AddressTypesEnable
        {
            get { return AddressTypeListField.Enabled; }
            set { AddressTypeListField.Enabled = value; }
        }
    }
}
