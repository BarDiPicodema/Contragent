﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    partial class ContactControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.ContactToolStrip = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.ContactPanel = new System.Windows.Forms.Panel();
            this.ContentTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.ContactTextLb = new System.Windows.Forms.Label();
            this.NameContactLb = new System.Windows.Forms.Label();
            this.PostLb = new System.Windows.Forms.Label();
            this.DepartamentLb = new System.Windows.Forms.Label();
            this.NoteLb = new System.Windows.Forms.Label();
            this.ContactTextField = new System.Windows.Forms.TextBox();
            this.NameContactField = new System.Windows.Forms.TextBox();
            this.PostField = new System.Windows.Forms.TextBox();
            this.SubdivisionField = new System.Windows.Forms.TextBox();
            this.NoteField = new System.Windows.Forms.TextBox();
            this.ContactTypeLb = new System.Windows.Forms.Label();
            this.AccessTypeLb = new System.Windows.Forms.Label();
            this.ContactTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.AccessTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.FlagLb = new System.Windows.Forms.Label();
            this.FlagControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.MainTableLayout.SuspendLayout();
            this.ContactPanel.SuspendLayout();
            this.ContentTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.ContactToolStrip, 0, 0);
            this.MainTableLayout.Controls.Add(this.ContactPanel, 0, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(600, 240);
            this.MainTableLayout.TabIndex = 0;
            // 
            // ContactToolStrip
            // 
            this.ContactToolStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactToolStrip.Location = new System.Drawing.Point(3, 3);
            this.ContactToolStrip.Name = "ContactToolStrip";
            this.ContactToolStrip.NameTitle = null;
            this.ContactToolStrip.Size = new System.Drawing.Size(594, 22);
            this.ContactToolStrip.TabIndex = 2;
            // 
            // ContactPanel
            // 
            this.ContactPanel.AutoScroll = true;
            this.ContactPanel.Controls.Add(this.ContentTableLayout);
            this.ContactPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactPanel.Location = new System.Drawing.Point(0, 28);
            this.ContactPanel.Margin = new System.Windows.Forms.Padding(0);
            this.ContactPanel.Name = "ContactPanel";
            this.ContactPanel.Size = new System.Drawing.Size(600, 212);
            this.ContactPanel.TabIndex = 3;
            // 
            // ContentTableLayout
            // 
            this.ContentTableLayout.ColumnCount = 4;
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.ContentTableLayout.Controls.Add(this.ContactTextLb, 0, 2);
            this.ContentTableLayout.Controls.Add(this.NameContactLb, 0, 3);
            this.ContentTableLayout.Controls.Add(this.PostLb, 0, 4);
            this.ContentTableLayout.Controls.Add(this.DepartamentLb, 0, 5);
            this.ContentTableLayout.Controls.Add(this.NoteLb, 0, 6);
            this.ContentTableLayout.Controls.Add(this.ContactTextField, 1, 2);
            this.ContentTableLayout.Controls.Add(this.NameContactField, 1, 3);
            this.ContentTableLayout.Controls.Add(this.PostField, 1, 4);
            this.ContentTableLayout.Controls.Add(this.SubdivisionField, 1, 5);
            this.ContentTableLayout.Controls.Add(this.NoteField, 1, 6);
            this.ContentTableLayout.Controls.Add(this.ContactTypeLb, 0, 0);
            this.ContentTableLayout.Controls.Add(this.AccessTypeLb, 0, 1);
            this.ContentTableLayout.Controls.Add(this.ContactTypeControl, 1, 0);
            this.ContentTableLayout.Controls.Add(this.AccessTypeControl, 1, 1);
            this.ContentTableLayout.Controls.Add(this.FlagLb, 2, 0);
            this.ContentTableLayout.Controls.Add(this.FlagControl, 3, 0);
            this.ContentTableLayout.Dock = System.Windows.Forms.DockStyle.Top;
            this.ContentTableLayout.Location = new System.Drawing.Point(0, 0);
            this.ContentTableLayout.Name = "ContentTableLayout";
            this.ContentTableLayout.RowCount = 7;
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ContentTableLayout.Size = new System.Drawing.Size(600, 206);
            this.ContentTableLayout.TabIndex = 2;
            // 
            // ContactTextLb
            // 
            this.ContactTextLb.AutoSize = true;
            this.ContactTextLb.Location = new System.Drawing.Point(3, 56);
            this.ContactTextLb.Name = "ContactTextLb";
            this.ContactTextLb.Size = new System.Drawing.Size(52, 13);
            this.ContactTextLb.TabIndex = 0;
            this.ContactTextLb.Text = "Контакт*";
            // 
            // NameContactLb
            // 
            this.NameContactLb.AutoSize = true;
            this.NameContactLb.Location = new System.Drawing.Point(3, 79);
            this.NameContactLb.Name = "NameContactLb";
            this.NameContactLb.Size = new System.Drawing.Size(82, 13);
            this.NameContactLb.TabIndex = 0;
            this.NameContactLb.Text = "Имя контакта*";
            // 
            // PostLb
            // 
            this.PostLb.AutoSize = true;
            this.PostLb.Location = new System.Drawing.Point(3, 102);
            this.PostLb.Name = "PostLb";
            this.PostLb.Size = new System.Drawing.Size(65, 13);
            this.PostLb.TabIndex = 0;
            this.PostLb.Text = "Должность";
            // 
            // DepartamentLb
            // 
            this.DepartamentLb.AutoSize = true;
            this.DepartamentLb.Location = new System.Drawing.Point(3, 125);
            this.DepartamentLb.Name = "DepartamentLb";
            this.DepartamentLb.Size = new System.Drawing.Size(38, 13);
            this.DepartamentLb.TabIndex = 0;
            this.DepartamentLb.Text = "Отдел";
            // 
            // NoteLb
            // 
            this.NoteLb.AutoSize = true;
            this.NoteLb.Location = new System.Drawing.Point(3, 148);
            this.NoteLb.Name = "NoteLb";
            this.NoteLb.Size = new System.Drawing.Size(51, 13);
            this.NoteLb.TabIndex = 0;
            this.NoteLb.Text = "Заметка";
            // 
            // ContactTextField
            // 
            this.ContentTableLayout.SetColumnSpan(this.ContactTextField, 3);
            this.ContactTextField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactTextField.Location = new System.Drawing.Point(93, 59);
            this.ContactTextField.Name = "ContactTextField";
            this.ContactTextField.Size = new System.Drawing.Size(504, 20);
            this.ContactTextField.TabIndex = 1;
            this.ContactTextField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NameContactField
            // 
            this.ContentTableLayout.SetColumnSpan(this.NameContactField, 3);
            this.NameContactField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NameContactField.Location = new System.Drawing.Point(93, 82);
            this.NameContactField.Name = "NameContactField";
            this.NameContactField.Size = new System.Drawing.Size(504, 20);
            this.NameContactField.TabIndex = 2;
            this.NameContactField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // PostField
            // 
            this.ContentTableLayout.SetColumnSpan(this.PostField, 3);
            this.PostField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PostField.Location = new System.Drawing.Point(93, 105);
            this.PostField.Name = "PostField";
            this.PostField.Size = new System.Drawing.Size(504, 20);
            this.PostField.TabIndex = 2;
            this.PostField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SubdivisionField
            // 
            this.ContentTableLayout.SetColumnSpan(this.SubdivisionField, 3);
            this.SubdivisionField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SubdivisionField.Location = new System.Drawing.Point(93, 128);
            this.SubdivisionField.Name = "SubdivisionField";
            this.SubdivisionField.Size = new System.Drawing.Size(504, 20);
            this.SubdivisionField.TabIndex = 2;
            this.SubdivisionField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NoteField
            // 
            this.ContentTableLayout.SetColumnSpan(this.NoteField, 3);
            this.NoteField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NoteField.Location = new System.Drawing.Point(93, 151);
            this.NoteField.Multiline = true;
            this.NoteField.Name = "NoteField";
            this.NoteField.Size = new System.Drawing.Size(504, 52);
            this.NoteField.TabIndex = 2;
            this.NoteField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // ContactTypeLb
            // 
            this.ContactTypeLb.AutoSize = true;
            this.ContactTypeLb.Location = new System.Drawing.Point(3, 0);
            this.ContactTypeLb.Name = "ContactTypeLb";
            this.ContactTypeLb.Size = new System.Drawing.Size(30, 13);
            this.ContactTypeLb.TabIndex = 0;
            this.ContactTypeLb.Text = "Тип*";
            // 
            // AccessTypeLb
            // 
            this.AccessTypeLb.AutoSize = true;
            this.AccessTypeLb.Location = new System.Drawing.Point(3, 28);
            this.AccessTypeLb.Name = "AccessTypeLb";
            this.AccessTypeLb.Size = new System.Drawing.Size(48, 13);
            this.AccessTypeLb.TabIndex = 0;
            this.AccessTypeLb.Text = "Доступ*";
            // 
            // ContactTypeControl
            // 
            this.ContactTypeControl.DataSource = null;
            this.ContactTypeControl.DisplayProperty = "TypeName";
            this.ContactTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactTypeControl.Location = new System.Drawing.Point(93, 3);
            this.ContactTypeControl.Name = "ContactTypeControl";
            this.ContactTypeControl.NameTitle = null;
            this.ContactTypeControl.Presenter = null;
            this.ContactTypeControl.SelectedEntity = null;
            this.ContactTypeControl.Size = new System.Drawing.Size(204, 22);
            this.ContactTypeControl.TabIndex = 3;
            // 
            // AccessTypeControl
            // 
            this.AccessTypeControl.DataSource = null;
            this.AccessTypeControl.DisplayProperty = "TypeName";
            this.AccessTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccessTypeControl.Location = new System.Drawing.Point(93, 31);
            this.AccessTypeControl.Name = "AccessTypeControl";
            this.AccessTypeControl.NameTitle = null;
            this.AccessTypeControl.Presenter = null;
            this.AccessTypeControl.SelectedEntity = null;
            this.AccessTypeControl.Size = new System.Drawing.Size(204, 22);
            this.AccessTypeControl.TabIndex = 4;
            // 
            // FlagLb
            // 
            this.FlagLb.AutoSize = true;
            this.FlagLb.Location = new System.Drawing.Point(303, 0);
            this.FlagLb.Name = "FlagLb";
            this.FlagLb.Size = new System.Drawing.Size(39, 13);
            this.FlagLb.TabIndex = 0;
            this.FlagLb.Text = "Флаг*";
            // 
            // FlagControl
            // 
            this.FlagControl.DataSource = null;
            this.FlagControl.DisplayProperty = "TypeName";
            this.FlagControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlagControl.Location = new System.Drawing.Point(393, 3);
            this.FlagControl.Name = "FlagControl";
            this.FlagControl.NameTitle = null;
            this.FlagControl.Presenter = null;
            this.FlagControl.SelectedEntity = null;
            this.FlagControl.Size = new System.Drawing.Size(204, 22);
            this.FlagControl.TabIndex = 5;
            // 
            // ContactControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "ContactControl";
            this.Size = new System.Drawing.Size(600, 240);
            this.MainTableLayout.ResumeLayout(false);
            this.ContactPanel.ResumeLayout(false);
            this.ContentTableLayout.ResumeLayout(false);
            this.ContentTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private MenuControls.EditorToolStrip ContactToolStrip;
        private System.Windows.Forms.Panel ContactPanel;
        private System.Windows.Forms.TableLayoutPanel ContentTableLayout;
        private System.Windows.Forms.Label ContactTextLb;
        private System.Windows.Forms.Label NameContactLb;
        private System.Windows.Forms.Label PostLb;
        private System.Windows.Forms.Label DepartamentLb;
        private System.Windows.Forms.Label NoteLb;
        private System.Windows.Forms.TextBox ContactTextField;
        private System.Windows.Forms.TextBox NameContactField;
        private System.Windows.Forms.TextBox PostField;
        private System.Windows.Forms.TextBox SubdivisionField;
        private System.Windows.Forms.TextBox NoteField;
        private System.Windows.Forms.Label ContactTypeLb;
        private System.Windows.Forms.Label AccessTypeLb;
        private ExtraControls.EditEntityBoxControl ContactTypeControl;
        private ExtraControls.EntityBoxControl AccessTypeControl;
        private System.Windows.Forms.Label FlagLb;
        private ExtraControls.EditEntityBoxControl FlagControl;


    }
}
