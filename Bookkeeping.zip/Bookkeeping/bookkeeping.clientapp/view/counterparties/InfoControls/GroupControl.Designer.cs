﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    partial class GroupControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.GroupToolStrip = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.GroupTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.AddGroupType = new System.Windows.Forms.Button();
            this.RemoveGroupType = new System.Windows.Forms.Button();
            this.GroupTypeTree = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl.GroupTreeControl();
            this.label6 = new System.Windows.Forms.Label();
            this.ContractorGroupTypeTree = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ContractorGroupTypeTreeControl();
            this.MainTableLayout.SuspendLayout();
            this.GroupTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.GroupToolStrip, 0, 0);
            this.MainTableLayout.Controls.Add(this.GroupTableLayout, 0, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(600, 260);
            this.MainTableLayout.TabIndex = 0;
            // 
            // GroupToolStrip
            // 
            this.GroupToolStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupToolStrip.Location = new System.Drawing.Point(3, 3);
            this.GroupToolStrip.Name = "GroupToolStrip";
            this.GroupToolStrip.NameTitle = null;
            this.GroupToolStrip.Size = new System.Drawing.Size(594, 20);
            this.GroupToolStrip.TabIndex = 2;
            // 
            // GroupTableLayout
            // 
            this.GroupTableLayout.ColumnCount = 3;
            this.GroupTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.GroupTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.GroupTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.GroupTableLayout.Controls.Add(this.AddGroupType, 1, 0);
            this.GroupTableLayout.Controls.Add(this.RemoveGroupType, 1, 1);
            this.GroupTableLayout.Controls.Add(this.GroupTypeTree, 0, 0);
            this.GroupTableLayout.Controls.Add(this.ContractorGroupTypeTree, 2, 0);
            this.GroupTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupTableLayout.Location = new System.Drawing.Point(3, 29);
            this.GroupTableLayout.Name = "GroupTableLayout";
            this.GroupTableLayout.RowCount = 2;
            this.GroupTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.GroupTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.GroupTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.GroupTableLayout.Size = new System.Drawing.Size(594, 228);
            this.GroupTableLayout.TabIndex = 3;
            // 
            // AddGroupType
            // 
            this.AddGroupType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AddGroupType.Location = new System.Drawing.Point(280, 88);
            this.AddGroupType.Name = "AddGroupType";
            this.AddGroupType.Size = new System.Drawing.Size(34, 23);
            this.AddGroupType.TabIndex = 0;
            this.AddGroupType.Text = "=>";
            this.AddGroupType.UseVisualStyleBackColor = true;
            // 
            // RemoveGroupType
            // 
            this.RemoveGroupType.Location = new System.Drawing.Point(280, 117);
            this.RemoveGroupType.Name = "RemoveGroupType";
            this.RemoveGroupType.Size = new System.Drawing.Size(34, 23);
            this.RemoveGroupType.TabIndex = 1;
            this.RemoveGroupType.Text = "<=";
            this.RemoveGroupType.UseVisualStyleBackColor = true;
            // 
            // GroupTypeTree
            // 
            this.GroupTypeTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupTypeTree.Location = new System.Drawing.Point(3, 3);
            this.GroupTypeTree.Name = "GroupTypeTree";
            this.GroupTableLayout.SetRowSpan(this.GroupTypeTree, 2);
            this.GroupTypeTree.SelectedType = null;
            this.GroupTypeTree.Size = new System.Drawing.Size(271, 222);
            this.GroupTypeTree.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 0;
            // 
            // ContractorGroupTypeTree
            // 
            this.ContractorGroupTypeTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContractorGroupTypeTree.Location = new System.Drawing.Point(320, 3);
            this.ContractorGroupTypeTree.Name = "ContractorGroupTypeTree";
            this.ContractorGroupTypeTree.NameTitle = null;
            this.GroupTableLayout.SetRowSpan(this.ContractorGroupTypeTree, 2);
            this.ContractorGroupTypeTree.Size = new System.Drawing.Size(271, 222);
            this.ContractorGroupTypeTree.TabIndex = 3;
            // 
            // GroupControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "GroupControl";
            this.Size = new System.Drawing.Size(600, 260);
            this.MainTableLayout.ResumeLayout(false);
            this.GroupTableLayout.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.Label label6;
        private MenuControls.EditorToolStrip GroupToolStrip;
        private System.Windows.Forms.TableLayoutPanel GroupTableLayout;
        private System.Windows.Forms.Button AddGroupType;
        private System.Windows.Forms.Button RemoveGroupType;
        private OtherInfoControl.GroupTreeControl GroupTypeTree;
        private ExtraControls.ContractorGroupTypeTreeControl ContractorGroupTypeTree;

    }
}
