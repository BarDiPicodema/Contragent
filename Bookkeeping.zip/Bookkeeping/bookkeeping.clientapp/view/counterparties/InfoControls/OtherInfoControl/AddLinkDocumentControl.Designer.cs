﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    partial class AddLinkDocumentControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.LinkLb = new System.Windows.Forms.Label();
            this.LinkField = new System.Windows.Forms.TextBox();
            this.LinkMenuStrip = new System.Windows.Forms.ToolStrip();
            this.SaveLink = new System.Windows.Forms.ToolStripButton();
            this.NoteLinkField = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.FindDocument = new System.Windows.Forms.Button();
            this.MainTableLayout.SuspendLayout();
            this.LinkMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 3;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.MainTableLayout.Controls.Add(this.LinkLb, 0, 1);
            this.MainTableLayout.Controls.Add(this.LinkField, 1, 1);
            this.MainTableLayout.Controls.Add(this.LinkMenuStrip, 0, 0);
            this.MainTableLayout.Controls.Add(this.NoteLinkField, 1, 2);
            this.MainTableLayout.Controls.Add(this.label1, 0, 2);
            this.MainTableLayout.Controls.Add(this.FindDocument, 2, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 3;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(320, 100);
            this.MainTableLayout.TabIndex = 0;
            // 
            // LinkLb
            // 
            this.LinkLb.AutoSize = true;
            this.LinkLb.Location = new System.Drawing.Point(3, 27);
            this.LinkLb.Name = "LinkLb";
            this.LinkLb.Size = new System.Drawing.Size(46, 13);
            this.LinkLb.TabIndex = 1;
            this.LinkLb.Text = "Ссылка";
            // 
            // LinkField
            // 
            this.LinkField.Dock = System.Windows.Forms.DockStyle.Top;
            this.LinkField.Location = new System.Drawing.Point(73, 29);
            this.LinkField.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
            this.LinkField.Name = "LinkField";
            this.LinkField.Size = new System.Drawing.Size(214, 20);
            this.LinkField.TabIndex = 2;
            this.LinkField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // LinkMenuStrip
            // 
            this.MainTableLayout.SetColumnSpan(this.LinkMenuStrip, 3);
            this.LinkMenuStrip.GripMargin = new System.Windows.Forms.Padding(0);
            this.LinkMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveLink});
            this.LinkMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.LinkMenuStrip.Name = "LinkMenuStrip";
            this.LinkMenuStrip.Size = new System.Drawing.Size(320, 25);
            this.LinkMenuStrip.TabIndex = 3;
            this.LinkMenuStrip.Text = "toolStrip1";
            // 
            // SaveLink
            // 
            this.SaveLink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SaveLink.Image = global::Bookkeeping.ClientApp.Properties.Resources.save;
            this.SaveLink.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveLink.Name = "SaveLink";
            this.SaveLink.Size = new System.Drawing.Size(23, 22);
            this.SaveLink.Text = "Сохранить";
            this.SaveLink.ToolTipText = "Сохранить ссылку";
            // 
            // NoteLinkField
            // 
            this.MainTableLayout.SetColumnSpan(this.NoteLinkField, 2);
            this.NoteLinkField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NoteLinkField.Location = new System.Drawing.Point(73, 53);
            this.NoteLinkField.Multiline = true;
            this.NoteLinkField.Name = "NoteLinkField";
            this.NoteLinkField.Size = new System.Drawing.Size(244, 44);
            this.NoteLinkField.TabIndex = 4;
            this.NoteLinkField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Заметка";
            // 
            // FindDocument
            // 
            this.FindDocument.Image = global::Bookkeeping.ClientApp.Properties.Resources.magnifier;
            this.FindDocument.Location = new System.Drawing.Point(293, 27);
            this.FindDocument.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.FindDocument.Name = "FindDocument";
            this.FindDocument.Size = new System.Drawing.Size(24, 23);
            this.FindDocument.TabIndex = 6;
            this.FindDocument.UseVisualStyleBackColor = true;
            // 
            // AddLinkDocumentControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "AddLinkDocumentControl";
            this.Size = new System.Drawing.Size(320, 100);
            this.MainTableLayout.ResumeLayout(false);
            this.MainTableLayout.PerformLayout();
            this.LinkMenuStrip.ResumeLayout(false);
            this.LinkMenuStrip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.Label LinkLb;
        private System.Windows.Forms.TextBox LinkField;
        private System.Windows.Forms.ToolStrip LinkMenuStrip;
        private System.Windows.Forms.ToolStripButton SaveLink;
        private System.Windows.Forms.TextBox NoteLinkField;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button FindDocument;
    }
}
