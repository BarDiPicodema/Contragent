﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    partial class AddParticipantControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddParticipantControl));
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.ParticipantToolStrip = new System.Windows.Forms.ToolStrip();
            this.ContractorType = new System.Windows.Forms.ToolStripComboBox();
            this.Separator = new System.Windows.Forms.ToolStripSeparator();
            this.SearchValue = new System.Windows.Forms.ToolStripTextBox();
            this.Run = new System.Windows.Forms.ToolStripButton();
            this.Table = new System.Windows.Forms.DataGridView();
            this.Alias = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaveParticipant = new System.Windows.Forms.ToolStripButton();
            this.MainTableLayout.SuspendLayout();
            this.ParticipantToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Table)).BeginInit();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.66667F));
            this.MainTableLayout.Controls.Add(this.ParticipantToolStrip, 0, 0);
            this.MainTableLayout.Controls.Add(this.Table, 0, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(310, 300);
            this.MainTableLayout.TabIndex = 0;
            // 
            // ParticipantToolStrip
            // 
            this.ParticipantToolStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParticipantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveParticipant,
            this.Separator,
            this.ContractorType,
            this.SearchValue,
            this.Run});
            this.ParticipantToolStrip.Location = new System.Drawing.Point(0, 0);
            this.ParticipantToolStrip.Name = "ParticipantToolStrip";
            this.ParticipantToolStrip.Padding = new System.Windows.Forms.Padding(0);
            this.ParticipantToolStrip.Size = new System.Drawing.Size(310, 27);
            this.ParticipantToolStrip.TabIndex = 0;
            this.ParticipantToolStrip.Text = "toolStrip1";
            // 
            // ContractorType
            // 
            this.ContractorType.Name = "ContractorType";
            this.ContractorType.Size = new System.Drawing.Size(121, 27);
            this.ContractorType.ToolTipText = "Тип контрагента";
            // 
            // Separator
            // 
            this.Separator.Name = "Separator";
            this.Separator.Size = new System.Drawing.Size(6, 27);
            // 
            // SearchValue
            // 
            this.SearchValue.Name = "SearchValue";
            this.SearchValue.Size = new System.Drawing.Size(100, 27);
            this.SearchValue.ToolTipText = "Текст для поиска по псевдониму или названию";
            // 
            // Run
            // 
            this.Run.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Run.Image = global::Bookkeeping.ClientApp.Properties.Resources.magnifier;
            this.Run.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Run.Name = "Run";
            this.Run.Size = new System.Drawing.Size(23, 24);
            this.Run.Text = "Поиск";
            this.Run.ToolTipText = "Начать поиск";
            // 
            // Table
            // 
            this.Table.AllowUserToAddRows = false;
            this.Table.AllowUserToDeleteRows = false;
            this.Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Alias});
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.Location = new System.Drawing.Point(3, 30);
            this.Table.Name = "Table";
            this.Table.ReadOnly = true;
            this.Table.Size = new System.Drawing.Size(304, 267);
            this.Table.TabIndex = 1;
            // 
            // Alias
            // 
            this.Alias.DataPropertyName = "Alias";
            this.Alias.HeaderText = "Псевдоним";
            this.Alias.Name = "Alias";
            this.Alias.ReadOnly = true;
            // 
            // SaveParticipant
            // 
            this.SaveParticipant.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SaveParticipant.Image = ((System.Drawing.Image)(resources.GetObject("SaveParticipant.Image")));
            this.SaveParticipant.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveParticipant.Name = "SaveParticipant";
            this.SaveParticipant.Size = new System.Drawing.Size(23, 24);
            this.SaveParticipant.Text = "Save";
            this.SaveParticipant.ToolTipText = "Сохранить участника";
            // 
            // SearchParticipantControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "SearchParticipantControl";
            this.Size = new System.Drawing.Size(310, 300);
            this.MainTableLayout.ResumeLayout(false);
            this.MainTableLayout.PerformLayout();
            this.ParticipantToolStrip.ResumeLayout(false);
            this.ParticipantToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Table)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.ToolStrip ParticipantToolStrip;
        private System.Windows.Forms.ToolStripComboBox ContractorType;
        private System.Windows.Forms.ToolStripSeparator Separator;
        private System.Windows.Forms.ToolStripTextBox SearchValue;
        private System.Windows.Forms.ToolStripButton Run;
        private System.Windows.Forms.DataGridView Table;
        private System.Windows.Forms.DataGridViewTextBoxColumn Alias;
        private System.Windows.Forms.ToolStripButton SaveParticipant;
    }
}
