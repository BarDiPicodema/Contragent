﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    public partial class AddLinkDocumentControl : Common.CUIControl, IAddLinkView
    {
        public AddLinkDocumentControl ()
        {
            InitializeComponent ();

            SaveLink.Click += (sender, args) => Invoke (Save);
            FindDocument.Click += (sender, args) => Invoke (Find);

            Presenter = new AddLinkPresenter (this, new Model.ServiceModel<Data.Entities.Link> ());
        }

        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public string LinkText
        {
            get { return LinkField.Text; }
            set { LinkField.Text = value; }
        }

        public string NoteLink
        {
            get { return NoteLinkField.Text; }
            set { NoteLinkField.Text = value; }
        }

        public Link Link { get; set; }


        public event Action Save;

        public event Action Find;
    }
}
