﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    public partial class AddAddressTypeControl : Common.CUIControl, IAddAddressTypeView
    {
        public AddAddressTypeControl ()
        {
            InitializeComponent ();
            NameTitle = "Добавить тип адреса";

            Presenter = new AddAddressTypePresenter (this, new Model.ServiceModel<AddressValue> ());

            AddressTypeControl.Presenter = new EntityPresenter<AddressType> (AddressTypeControl, new Model.ServiceModel<AddressType> ());
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public Presenter.Counterparties.Menu.IEditorToolView ToolView
        {
            get { return EditorTool; }
        }

        public Presenter.Counterparties.Extra.IEntityControlView AddressTypeView
        {
            get { return AddressTypeControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<AddressType> AddressType
        {
            get { return AddressTypeControl.Presenter as EntityPresenter<AddressType>; }
        }

        public AddressValue AddressValue { get; set; }
    }
}
