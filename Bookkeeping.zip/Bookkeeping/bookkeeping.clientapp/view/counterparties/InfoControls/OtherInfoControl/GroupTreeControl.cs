﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    /// <summary>
    /// TODO : Nodes как коллекция GroupNode
    /// </summary>
    public partial class GroupTreeControl : UserControl, IGroupTreeView
    {
        public GroupTreeControl ()
        {
            InitializeComponent ();
            Tree.AfterCheck += Tree_AfterCheck;

            _checkedProcess = false;

           /* var add = new MenuItem ();
            add.Click += (sender, args) => Invoke (AddGroupType);
            var update = new MenuItem ();
            update.Click += (sender, args) => Invoke (UpdateGroupType);
            var remove = new MenuItem ();
            remove.Click += (sender, args) => Invoke (RemoveGroupType);
            Tree.ContextMenu = new System.Windows.Forms.ContextMenu (new MenuItem[] { add, update, remove });*/

            Presenter = new GroupTreePresenter (this, new Model.ServiceModel<GroupType> ());
        }

        private bool _checkedProcess;

        public GroupType SelectedType
        {
            get 
            {
                if (Tree.SelectedNode != null)
                    return (Tree.SelectedNode as GroupNode).GroupType;
                return null;
            }
            set
            {
                if ( value != null )
                {
                    var node = Tree.Nodes.Find (value.TypeName, true);
                    if ( node.Length > 0 )
                        node[0].Checked = true;
                }
            }
        }

        public object CheckedItem
        {
            get { return GetCheckedTreeNode (Tree.TopNode); }
        }

        public TreeNodeCollection Nodes
        {
            get
            {
                return Tree.Nodes;
            }
        }

        public void ExpandAll ()
        {
            Tree.ExpandAll ();
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        
        public event Action CheckedTreeItem;

        public event Action AddGroupType;

        public event Action UpdateGroupType;

        public event Action RemoveGroupType;

        private void Tree_AfterCheck (object sender, TreeViewEventArgs e)
        {
            if ( _checkedProcess == false )
            {
                _checkedProcess = true;
                foreach ( TreeNode node in Tree.Nodes )
                    UncheckedNodes (node);

                CheckParent (e.Node, true);
                CheckNode (e.Node, true);
                _checkedProcess = false;
                return;
            }
        }

        private void CheckParent (TreeNode node, bool check)
        {
            node.Checked = check;
            if ( node.Parent != null )
            {
                CheckParent (node.Parent, check);
            }
            else return;
        }

        private void CheckNode (TreeNode node, bool check)
        {
            node.Checked = check;

            if ( node.Nodes.Count == 0 )
            {
                _checkedProcess = false;
                return;
            }
            else CheckNode (node.Nodes[0], check);
        }

        private void UncheckedNodes (TreeNode node)
        {
            if ( node.Nodes.Count > 0 )
                foreach ( TreeNode item in node.Nodes )
                    UncheckedNodes (item);
            node.Checked = false;
        }

        private TreeNode GetCheckedTreeNode (TreeNode node)
        {
            TreeNode temp = node;
            if ( node.Nodes.Count == 0 )
                return node;
            else
            {
                foreach (TreeNode item in node.Nodes)
                    if (item.Checked == true)
                        temp = GetCheckedTreeNode (item);
            }
            return temp;
        }
    }

    public class GroupNode : TreeNode
    {
        public GroupNode (string name)
        {
            Text = name;

            Name = "0";
        }

        public GroupNode (GroupType type)
        {
            GroupType = type;
            Text = type.TypeName;

            Name = type.Id.ToString();
        }

        public GroupType GroupType { get; private set; }
    }
}
