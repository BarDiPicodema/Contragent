﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    public class ListContextMenu : ContextMenu
    {
        public event EventHandler AddItem;
        public event EventHandler RemoveItem;
        
        public ListContextMenu ()
        {
            var add = new MenuItem ("Добавить");
            add.Click += (sender, args) =>
            {
                if ( AddItem != null )
                    AddItem (this, args);
            };

            var remove = new MenuItem ("Удалить");
            remove.Click += (sender, args) => 
            {
                if ( RemoveItem != null )
                    RemoveItem (this, args);
            };

            this.MenuItems.Add (add);
            this.MenuItems.Add (remove);
        }
    }
}
