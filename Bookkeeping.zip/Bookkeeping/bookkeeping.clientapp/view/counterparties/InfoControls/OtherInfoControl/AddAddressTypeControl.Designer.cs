﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    partial class AddAddressTypeControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.EditorTool = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.AddressTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.MainTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.EditorTool, 0, 0);
            this.MainTableLayout.Controls.Add(this.AddressTypeControl, 0, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(150, 60);
            this.MainTableLayout.TabIndex = 0;
            // 
            // EditorTool
            // 
            this.EditorTool.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EditorTool.Location = new System.Drawing.Point(3, 3);
            this.EditorTool.Name = "EditorTool";
            this.EditorTool.NameTitle = null;
            this.EditorTool.Size = new System.Drawing.Size(144, 23);
            this.EditorTool.TabIndex = 0;
            // 
            // AddressType
            // 
            this.AddressTypeControl.DataSource = null;
            this.AddressTypeControl.DisplayProperty = "TypeName";
            this.AddressTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTypeControl.Location = new System.Drawing.Point(3, 32);
            this.AddressTypeControl.Name = "AddressType";
            this.AddressTypeControl.NameTitle = "Добавить тип адреса";
            this.AddressTypeControl.Presenter = null;
            this.AddressTypeControl.SelectedEntity = null;
            this.AddressTypeControl.Size = new System.Drawing.Size(144, 25);
            this.AddressTypeControl.TabIndex = 1;
            // 
            // AddAddressTypeControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "AddAddressTypeControl";
            this.Size = new System.Drawing.Size(150, 60);
            this.MainTableLayout.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private MenuControls.EditorToolStrip EditorTool;
        private ExtraControls.EntityBoxControl AddressTypeControl;

    }
}
