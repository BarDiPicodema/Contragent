﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl
{
    public partial class AddParticipantControl : Common.CUIControl, ISearchParticipantView
    {
        public AddParticipantControl ()
        {
            InitializeComponent ();
            Table.AutoGenerateColumns = false;

            SaveParticipant.Click += (sender, args) => Invoke (Save);
            ContractorType.SelectedIndexChanged += (sender, arg) => Invoke (SelectedType);
            Run.Click += (sender, arg) => Invoke (SearchRun);
            SearchValue.KeyUp += (sender, arg) =>
                {
                    if ( arg.KeyData == Keys.Enter )
                        Invoke (SearchRun);
                };

            Presenter = new SearchParticipantPresenter (this, new Model.ServiceModel<Data.Entities.DocumentParticipant> (),
                                                                                new Model.AccessServiceModel<Data.Entities.Partner> (), 
                                                                                new Model.Counterparties.ClientServiceModel ());
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public string FindValue
        {
            get { return SearchValue.Text; }
        }

        public BindingSource Source
        {
            get { return Table.DataSource as BindingSource; }
            set
            {
                var binding = new BindingSource ();
                binding.DataSource = value;
                Table.DataSource = binding;
            }
        }

        public object DataSourceType
        {
            get { return ContractorType.Items; }
            set 
            {
                IList<string> types = value as IList<string>;
                foreach (var item in types)
                    ContractorType.Items.Add (item); 
            }
        }

        public string Type
        {
            get { return ContractorType.SelectedItem.ToString(); }
        }

        public object SelectedContractor
        {
            get
            {
                if ( Table.CurrentRow != null )
                {
                    var row = Table.CurrentRow.DataBoundItem;
                    return row;
                }
                return null;
            }
        }


        public event Action SelectedType;
        public event Action SearchRun;
        public event Action Save;
    }
}
