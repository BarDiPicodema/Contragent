﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class AddressTypeListControl : Common.CUIControl, IAddressTypeListView
    {
        public AddressTypeListControl ()
        {
            InitializeComponent ();

            var menu = new ListContextMenu ();
            menu.AddItem += (sender, arg) => Invoke (AddAddressType);
            menu.RemoveItem += (sender, arg) =>
            {
                if ( AddressTypeList.SelectedItem != null )
                    Invoke (RemoveAddressType);
            };
            AddressTypeList.ContextMenu = menu;
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public object DataSource
        {
            get { return AddressTypeList.DataSource; }
            set { AddressTypeList.DataSource = value; }
        }

        public AddressType SelectedItem
        {
            get { return AddressTypeList.SelectedItem as AddressType; }
        }

        public event Action AddAddressType;

        public event Action RemoveAddressType;
    }
}
