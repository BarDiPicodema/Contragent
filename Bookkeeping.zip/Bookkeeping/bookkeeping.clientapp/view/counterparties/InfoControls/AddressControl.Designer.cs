﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    partial class AddressControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.AddressToolSplit = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.AddressPanel = new System.Windows.Forms.Panel();
            this.AddressContentTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.NameAddressLb = new System.Windows.Forms.Label();
            this.NameField = new System.Windows.Forms.TextBox();
            this.CountryLb = new System.Windows.Forms.Label();
            this.AreaLb = new System.Windows.Forms.Label();
            this.StreetLb = new System.Windows.Forms.Label();
            this.HouseLb = new System.Windows.Forms.Label();
            this.StructureLb = new System.Windows.Forms.Label();
            this.OfficeLb = new System.Windows.Forms.Label();
            this.LandField = new System.Windows.Forms.TextBox();
            this.AreaField = new System.Windows.Forms.TextBox();
            this.OfficeField = new System.Windows.Forms.TextBox();
            this.StructureField = new System.Windows.Forms.TextBox();
            this.PorchLb = new System.Windows.Forms.Label();
            this.PorchField = new System.Windows.Forms.TextBox();
            this.AddedTypesLb = new System.Windows.Forms.Label();
            this.OkatoLb = new System.Windows.Forms.Label();
            this.OktmoLb = new System.Windows.Forms.Label();
            this.KladrLb = new System.Windows.Forms.Label();
            this.SounLb = new System.Windows.Forms.Label();
            this.SonoLb = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.DescriptionLb = new System.Windows.Forms.Label();
            this.DescriptionField = new System.Windows.Forms.TextBox();
            this.IndexField = new System.Windows.Forms.TextBox();
            this.IndexLb = new System.Windows.Forms.Label();
            this.SettlementField = new System.Windows.Forms.TextBox();
            this.SettlementLb = new System.Windows.Forms.Label();
            this.CityLb = new System.Windows.Forms.Label();
            this.HouseField = new System.Windows.Forms.TextBox();
            this.StreetField = new System.Windows.Forms.TextBox();
            this.CityField = new System.Windows.Forms.TextBox();
            this.AddressTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.FlagControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.AccessTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.AddressTypeLb = new System.Windows.Forms.Label();
            this.FlagLb = new System.Windows.Forms.Label();
            this.AccessTypeLb = new System.Windows.Forms.Label();
            this.AddressTypeListField = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.AddressTypeListControl();
            this.OkatoField = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ClassificatorBox();
            this.OktmoField = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ClassificatorBox();
            this.SonoField = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ClassificatorBox();
            this.MainTableLayout.SuspendLayout();
            this.AddressPanel.SuspendLayout();
            this.AddressContentTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.AddressToolSplit, 0, 0);
            this.MainTableLayout.Controls.Add(this.AddressPanel, 0, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(600, 380);
            this.MainTableLayout.TabIndex = 0;
            // 
            // AddressToolSplit
            // 
            this.AddressToolSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressToolSplit.Location = new System.Drawing.Point(3, 3);
            this.AddressToolSplit.Name = "AddressToolSplit";
            this.AddressToolSplit.NameTitle = null;
            this.AddressToolSplit.Size = new System.Drawing.Size(594, 22);
            this.AddressToolSplit.TabIndex = 3;
            // 
            // AddressPanel
            // 
            this.AddressPanel.AutoScroll = true;
            this.AddressPanel.Controls.Add(this.AddressContentTableLayout);
            this.AddressPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressPanel.Location = new System.Drawing.Point(3, 31);
            this.AddressPanel.Name = "AddressPanel";
            this.AddressPanel.Size = new System.Drawing.Size(594, 346);
            this.AddressPanel.TabIndex = 4;
            // 
            // AddressContentTableLayout
            // 
            this.AddressContentTableLayout.ColumnCount = 8;
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.AddressContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.AddressContentTableLayout.Controls.Add(this.NameAddressLb, 0, 1);
            this.AddressContentTableLayout.Controls.Add(this.NameField, 1, 1);
            this.AddressContentTableLayout.Controls.Add(this.CountryLb, 0, 2);
            this.AddressContentTableLayout.Controls.Add(this.AreaLb, 4, 2);
            this.AddressContentTableLayout.Controls.Add(this.StreetLb, 0, 4);
            this.AddressContentTableLayout.Controls.Add(this.HouseLb, 0, 5);
            this.AddressContentTableLayout.Controls.Add(this.StructureLb, 2, 5);
            this.AddressContentTableLayout.Controls.Add(this.OfficeLb, 4, 5);
            this.AddressContentTableLayout.Controls.Add(this.LandField, 1, 2);
            this.AddressContentTableLayout.Controls.Add(this.AreaField, 5, 2);
            this.AddressContentTableLayout.Controls.Add(this.OfficeField, 5, 5);
            this.AddressContentTableLayout.Controls.Add(this.StructureField, 3, 5);
            this.AddressContentTableLayout.Controls.Add(this.PorchLb, 6, 5);
            this.AddressContentTableLayout.Controls.Add(this.PorchField, 7, 5);
            this.AddressContentTableLayout.Controls.Add(this.AddedTypesLb, 0, 6);
            this.AddressContentTableLayout.Controls.Add(this.OkatoLb, 4, 6);
            this.AddressContentTableLayout.Controls.Add(this.OktmoLb, 6, 6);
            this.AddressContentTableLayout.Controls.Add(this.KladrLb, 4, 8);
            this.AddressContentTableLayout.Controls.Add(this.SounLb, 5, 8);
            this.AddressContentTableLayout.Controls.Add(this.SonoLb, 7, 8);
            this.AddressContentTableLayout.Controls.Add(this.textBox4, 5, 9);
            this.AddressContentTableLayout.Controls.Add(this.textBox3, 4, 9);
            this.AddressContentTableLayout.Controls.Add(this.DescriptionLb, 0, 10);
            this.AddressContentTableLayout.Controls.Add(this.DescriptionField, 1, 10);
            this.AddressContentTableLayout.Controls.Add(this.IndexField, 7, 3);
            this.AddressContentTableLayout.Controls.Add(this.IndexLb, 6, 3);
            this.AddressContentTableLayout.Controls.Add(this.SettlementField, 4, 3);
            this.AddressContentTableLayout.Controls.Add(this.SettlementLb, 3, 3);
            this.AddressContentTableLayout.Controls.Add(this.CityLb, 0, 3);
            this.AddressContentTableLayout.Controls.Add(this.HouseField, 1, 5);
            this.AddressContentTableLayout.Controls.Add(this.StreetField, 1, 4);
            this.AddressContentTableLayout.Controls.Add(this.CityField, 1, 3);
            this.AddressContentTableLayout.Controls.Add(this.AddressTypeControl, 1, 0);
            this.AddressContentTableLayout.Controls.Add(this.FlagControl, 4, 0);
            this.AddressContentTableLayout.Controls.Add(this.AccessTypeControl, 7, 0);
            this.AddressContentTableLayout.Controls.Add(this.AddressTypeLb, 0, 0);
            this.AddressContentTableLayout.Controls.Add(this.FlagLb, 3, 0);
            this.AddressContentTableLayout.Controls.Add(this.AccessTypeLb, 6, 0);
            this.AddressContentTableLayout.Controls.Add(this.AddressTypeListField, 1, 6);
            this.AddressContentTableLayout.Controls.Add(this.OkatoField, 4, 7);
            this.AddressContentTableLayout.Controls.Add(this.OktmoField, 6, 7);
            this.AddressContentTableLayout.Controls.Add(this.SonoField, 7, 9);
            this.AddressContentTableLayout.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddressContentTableLayout.Location = new System.Drawing.Point(0, 0);
            this.AddressContentTableLayout.Name = "AddressContentTableLayout";
            this.AddressContentTableLayout.RowCount = 12;
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AddressContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.AddressContentTableLayout.Size = new System.Drawing.Size(594, 346);
            this.AddressContentTableLayout.TabIndex = 3;
            // 
            // NameAddressLb
            // 
            this.NameAddressLb.AutoSize = true;
            this.NameAddressLb.Location = new System.Drawing.Point(3, 26);
            this.NameAddressLb.Name = "NameAddressLb";
            this.NameAddressLb.Size = new System.Drawing.Size(61, 13);
            this.NameAddressLb.TabIndex = 0;
            this.NameAddressLb.Text = "Название*";
            // 
            // NameField
            // 
            this.NameField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.NameField, 7);
            this.NameField.Location = new System.Drawing.Point(74, 29);
            this.NameField.Name = "NameField";
            this.NameField.Size = new System.Drawing.Size(517, 20);
            this.NameField.TabIndex = 1;
            this.NameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // CountryLb
            // 
            this.CountryLb.AutoSize = true;
            this.CountryLb.Location = new System.Drawing.Point(3, 52);
            this.CountryLb.Name = "CountryLb";
            this.CountryLb.Size = new System.Drawing.Size(43, 13);
            this.CountryLb.TabIndex = 0;
            this.CountryLb.Text = "Страна";
            // 
            // AreaLb
            // 
            this.AreaLb.AutoSize = true;
            this.AreaLb.Location = new System.Drawing.Point(299, 52);
            this.AreaLb.Name = "AreaLb";
            this.AreaLb.Size = new System.Drawing.Size(50, 13);
            this.AreaLb.TabIndex = 0;
            this.AreaLb.Text = "Область";
            // 
            // StreetLb
            // 
            this.StreetLb.AutoSize = true;
            this.StreetLb.Location = new System.Drawing.Point(3, 104);
            this.StreetLb.Name = "StreetLb";
            this.StreetLb.Size = new System.Drawing.Size(43, 13);
            this.StreetLb.TabIndex = 0;
            this.StreetLb.Text = "Улица*";
            // 
            // HouseLb
            // 
            this.HouseLb.AutoSize = true;
            this.HouseLb.Location = new System.Drawing.Point(3, 130);
            this.HouseLb.Name = "HouseLb";
            this.HouseLb.Size = new System.Drawing.Size(34, 13);
            this.HouseLb.TabIndex = 0;
            this.HouseLb.Text = "Дом*";
            // 
            // StructureLb
            // 
            this.StructureLb.AutoSize = true;
            this.StructureLb.Location = new System.Drawing.Point(148, 130);
            this.StructureLb.Name = "StructureLb";
            this.StructureLb.Size = new System.Drawing.Size(65, 13);
            this.StructureLb.TabIndex = 0;
            this.StructureLb.Text = "Стр/корпус";
            // 
            // OfficeLb
            // 
            this.OfficeLb.AutoSize = true;
            this.OfficeLb.Location = new System.Drawing.Point(299, 130);
            this.OfficeLb.Name = "OfficeLb";
            this.OfficeLb.Size = new System.Drawing.Size(55, 13);
            this.OfficeLb.TabIndex = 0;
            this.OfficeLb.Text = "Офис/кв.";
            // 
            // LandField
            // 
            this.LandField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.LandField, 3);
            this.LandField.Location = new System.Drawing.Point(74, 55);
            this.LandField.Name = "LandField";
            this.LandField.Size = new System.Drawing.Size(219, 20);
            this.LandField.TabIndex = 1;
            this.LandField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // AreaField
            // 
            this.AreaField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.AreaField, 3);
            this.AreaField.Location = new System.Drawing.Point(388, 55);
            this.AreaField.Name = "AreaField";
            this.AreaField.Size = new System.Drawing.Size(203, 20);
            this.AreaField.TabIndex = 1;
            this.AreaField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // OfficeField
            // 
            this.OfficeField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OfficeField.Location = new System.Drawing.Point(388, 133);
            this.OfficeField.Name = "OfficeField";
            this.OfficeField.Size = new System.Drawing.Size(53, 20);
            this.OfficeField.TabIndex = 1;
            this.OfficeField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // StructureField
            // 
            this.StructureField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.StructureField.Location = new System.Drawing.Point(222, 133);
            this.StructureField.Name = "StructureField";
            this.StructureField.Size = new System.Drawing.Size(71, 20);
            this.StructureField.TabIndex = 1;
            this.StructureField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // PorchLb
            // 
            this.PorchLb.AutoSize = true;
            this.PorchLb.Location = new System.Drawing.Point(447, 130);
            this.PorchLb.Name = "PorchLb";
            this.PorchLb.Size = new System.Drawing.Size(52, 13);
            this.PorchLb.TabIndex = 0;
            this.PorchLb.Text = "Подъезд";
            // 
            // PorchField
            // 
            this.PorchField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PorchField.Location = new System.Drawing.Point(506, 133);
            this.PorchField.Name = "PorchField";
            this.PorchField.Size = new System.Drawing.Size(85, 20);
            this.PorchField.TabIndex = 1;
            this.PorchField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // AddedTypesLb
            // 
            this.AddedTypesLb.AutoSize = true;
            this.AddedTypesLb.Location = new System.Drawing.Point(3, 156);
            this.AddedTypesLb.Name = "AddedTypesLb";
            this.AddedTypesLb.Size = new System.Drawing.Size(59, 13);
            this.AddedTypesLb.TabIndex = 0;
            this.AddedTypesLb.Text = "Доп. типы";
            // 
            // OkatoLb
            // 
            this.OkatoLb.AutoSize = true;
            this.OkatoLb.Location = new System.Drawing.Point(299, 156);
            this.OkatoLb.Name = "OkatoLb";
            this.OkatoLb.Size = new System.Drawing.Size(44, 13);
            this.OkatoLb.TabIndex = 0;
            this.OkatoLb.Text = "ОКАТО";
            // 
            // OktmoLb
            // 
            this.OktmoLb.AutoSize = true;
            this.OktmoLb.Location = new System.Drawing.Point(447, 156);
            this.OktmoLb.Name = "OktmoLb";
            this.OktmoLb.Size = new System.Drawing.Size(46, 13);
            this.OktmoLb.TabIndex = 0;
            this.OktmoLb.Text = "ОКТМО";
            // 
            // KladrLb
            // 
            this.KladrLb.AutoSize = true;
            this.KladrLb.Location = new System.Drawing.Point(299, 208);
            this.KladrLb.Name = "KladrLb";
            this.KladrLb.Size = new System.Drawing.Size(45, 13);
            this.KladrLb.TabIndex = 0;
            this.KladrLb.Text = "КЛАДР";
            // 
            // SounLb
            // 
            this.SounLb.AutoSize = true;
            this.SounLb.Location = new System.Drawing.Point(388, 208);
            this.SounLb.Name = "SounLb";
            this.SounLb.Size = new System.Drawing.Size(38, 13);
            this.SounLb.TabIndex = 0;
            this.SounLb.Text = "СОУН";
            // 
            // SonoLb
            // 
            this.SonoLb.AutoSize = true;
            this.SonoLb.Location = new System.Drawing.Point(506, 208);
            this.SonoLb.Name = "SonoLb";
            this.SonoLb.Size = new System.Drawing.Size(38, 13);
            this.SonoLb.TabIndex = 0;
            this.SonoLb.Text = "СОНО";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.textBox4, 2);
            this.textBox4.Location = new System.Drawing.Point(388, 237);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(112, 20);
            this.textBox4.TabIndex = 1;
            this.textBox4.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox3.Location = new System.Drawing.Point(299, 237);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(83, 20);
            this.textBox3.TabIndex = 1;
            this.textBox3.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // DescriptionLb
            // 
            this.DescriptionLb.AutoSize = true;
            this.DescriptionLb.Location = new System.Drawing.Point(3, 260);
            this.DescriptionLb.Name = "DescriptionLb";
            this.DescriptionLb.Size = new System.Drawing.Size(57, 13);
            this.DescriptionLb.TabIndex = 3;
            this.DescriptionLb.Text = "Описание";
            // 
            // DescriptionField
            // 
            this.DescriptionField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.DescriptionField, 7);
            this.DescriptionField.Location = new System.Drawing.Point(74, 263);
            this.DescriptionField.Multiline = true;
            this.DescriptionField.Name = "DescriptionField";
            this.AddressContentTableLayout.SetRowSpan(this.DescriptionField, 2);
            this.DescriptionField.Size = new System.Drawing.Size(517, 80);
            this.DescriptionField.TabIndex = 5;
            this.DescriptionField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // IndexField
            // 
            this.IndexField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IndexField.Location = new System.Drawing.Point(506, 81);
            this.IndexField.Name = "IndexField";
            this.IndexField.Size = new System.Drawing.Size(85, 20);
            this.IndexField.TabIndex = 1;
            this.IndexField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // IndexLb
            // 
            this.IndexLb.AutoSize = true;
            this.IndexLb.Location = new System.Drawing.Point(447, 78);
            this.IndexLb.Name = "IndexLb";
            this.IndexLb.Size = new System.Drawing.Size(50, 26);
            this.IndexLb.TabIndex = 0;
            this.IndexLb.Text = "Индекс/zip";
            // 
            // SettlementField
            // 
            this.SettlementField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.SettlementField, 2);
            this.SettlementField.Location = new System.Drawing.Point(299, 81);
            this.SettlementField.Name = "SettlementField";
            this.SettlementField.Size = new System.Drawing.Size(142, 20);
            this.SettlementField.TabIndex = 1;
            this.SettlementField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SettlementLb
            // 
            this.SettlementLb.AutoSize = true;
            this.SettlementLb.Location = new System.Drawing.Point(222, 78);
            this.SettlementLb.Name = "SettlementLb";
            this.SettlementLb.Size = new System.Drawing.Size(51, 13);
            this.SettlementLb.TabIndex = 0;
            this.SettlementLb.Text = "Поселок";
            // 
            // CityLb
            // 
            this.CityLb.AutoSize = true;
            this.CityLb.Location = new System.Drawing.Point(3, 78);
            this.CityLb.Name = "CityLb";
            this.CityLb.Size = new System.Drawing.Size(41, 13);
            this.CityLb.TabIndex = 0;
            this.CityLb.Text = "Город*";
            // 
            // HouseField
            // 
            this.HouseField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HouseField.Location = new System.Drawing.Point(74, 133);
            this.HouseField.Name = "HouseField";
            this.HouseField.Size = new System.Drawing.Size(68, 20);
            this.HouseField.TabIndex = 1;
            this.HouseField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // StreetField
            // 
            this.StreetField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.StreetField, 2);
            this.StreetField.Location = new System.Drawing.Point(74, 107);
            this.StreetField.Name = "StreetField";
            this.StreetField.Size = new System.Drawing.Size(142, 20);
            this.StreetField.TabIndex = 1;
            this.StreetField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // CityField
            // 
            this.CityField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddressContentTableLayout.SetColumnSpan(this.CityField, 2);
            this.CityField.Location = new System.Drawing.Point(74, 81);
            this.CityField.Name = "CityField";
            this.CityField.Size = new System.Drawing.Size(142, 20);
            this.CityField.TabIndex = 1;
            this.CityField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // AddressTypeControl
            // 
            this.AddressContentTableLayout.SetColumnSpan(this.AddressTypeControl, 2);
            this.AddressTypeControl.DataSource = null;
            this.AddressTypeControl.DisplayProperty = "TypeName";
            this.AddressTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTypeControl.Location = new System.Drawing.Point(73, 2);
            this.AddressTypeControl.Margin = new System.Windows.Forms.Padding(2);
            this.AddressTypeControl.Name = "AddressTypeControl";
            this.AddressTypeControl.NameTitle = null;
            this.AddressTypeControl.Presenter = null;
            this.AddressTypeControl.SelectedEntity = null;
            this.AddressTypeControl.Size = new System.Drawing.Size(144, 22);
            this.AddressTypeControl.TabIndex = 6;
            // 
            // FlagControl
            // 
            this.AddressContentTableLayout.SetColumnSpan(this.FlagControl, 2);
            this.FlagControl.DataSource = null;
            this.FlagControl.DisplayProperty = "TypeName";
            this.FlagControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlagControl.Location = new System.Drawing.Point(298, 2);
            this.FlagControl.Margin = new System.Windows.Forms.Padding(2);
            this.FlagControl.Name = "FlagControl";
            this.FlagControl.NameTitle = null;
            this.FlagControl.Presenter = null;
            this.FlagControl.SelectedEntity = null;
            this.FlagControl.Size = new System.Drawing.Size(144, 22);
            this.FlagControl.TabIndex = 6;
            // 
            // AccessTypeControl
            // 
            this.AccessTypeControl.DataSource = null;
            this.AccessTypeControl.DisplayProperty = "TypeName";
            this.AccessTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccessTypeControl.Location = new System.Drawing.Point(505, 2);
            this.AccessTypeControl.Margin = new System.Windows.Forms.Padding(2);
            this.AccessTypeControl.Name = "AccessTypeControl";
            this.AccessTypeControl.NameTitle = null;
            this.AccessTypeControl.Presenter = null;
            this.AccessTypeControl.SelectedEntity = null;
            this.AccessTypeControl.Size = new System.Drawing.Size(87, 22);
            this.AccessTypeControl.TabIndex = 7;
            // 
            // AddressTypeLb
            // 
            this.AddressTypeLb.AutoSize = true;
            this.AddressTypeLb.Location = new System.Drawing.Point(3, 0);
            this.AddressTypeLb.Name = "AddressTypeLb";
            this.AddressTypeLb.Size = new System.Drawing.Size(30, 13);
            this.AddressTypeLb.TabIndex = 0;
            this.AddressTypeLb.Text = "Тип*";
            // 
            // FlagLb
            // 
            this.FlagLb.AutoSize = true;
            this.FlagLb.Location = new System.Drawing.Point(222, 0);
            this.FlagLb.Name = "FlagLb";
            this.FlagLb.Size = new System.Drawing.Size(39, 13);
            this.FlagLb.TabIndex = 0;
            this.FlagLb.Text = "Флаг*";
            // 
            // AccessTypeLb
            // 
            this.AccessTypeLb.AutoSize = true;
            this.AccessTypeLb.Location = new System.Drawing.Point(447, 0);
            this.AccessTypeLb.Name = "AccessTypeLb";
            this.AccessTypeLb.Size = new System.Drawing.Size(48, 13);
            this.AccessTypeLb.TabIndex = 0;
            this.AccessTypeLb.Text = "Доступ*";
            // 
            // AddressTypeListField
            // 
            this.AddressContentTableLayout.SetColumnSpan(this.AddressTypeListField, 3);
            this.AddressTypeListField.DataSource = null;
            this.AddressTypeListField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTypeListField.Location = new System.Drawing.Point(74, 159);
            this.AddressTypeListField.Name = "AddressTypeListField";
            this.AddressTypeListField.NameTitle = null;
            this.AddressTypeListField.Presenter = null;
            this.AddressContentTableLayout.SetRowSpan(this.AddressTypeListField, 4);
            this.AddressTypeListField.Size = new System.Drawing.Size(219, 98);
            this.AddressTypeListField.TabIndex = 8;
            // 
            // OkatoField
            // 
            this.OkatoField.Classificator = null;
            this.OkatoField.ClassificatorCode = "";
            this.AddressContentTableLayout.SetColumnSpan(this.OkatoField, 2);
            this.OkatoField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OkatoField.Location = new System.Drawing.Point(299, 185);
            this.OkatoField.Name = "OkatoField";
            this.OkatoField.NameTitle = "";
            this.OkatoField.Size = new System.Drawing.Size(142, 20);
            this.OkatoField.TabIndex = 9;
            // 
            // OktmoField
            // 
            this.OktmoField.Classificator = null;
            this.OktmoField.ClassificatorCode = "";
            this.AddressContentTableLayout.SetColumnSpan(this.OktmoField, 2);
            this.OktmoField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OktmoField.Location = new System.Drawing.Point(447, 185);
            this.OktmoField.Name = "OktmoField";
            this.OktmoField.NameTitle = null;
            this.OktmoField.Size = new System.Drawing.Size(144, 20);
            this.OktmoField.TabIndex = 10;
            // 
            // SonoField
            // 
            this.SonoField.Classificator = null;
            this.SonoField.ClassificatorCode = "";
            this.SonoField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SonoField.Location = new System.Drawing.Point(506, 237);
            this.SonoField.Name = "SonoField";
            this.SonoField.NameTitle = null;
            this.SonoField.Size = new System.Drawing.Size(85, 20);
            this.SonoField.TabIndex = 10;
            // 
            // AddressControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "AddressControl";
            this.Size = new System.Drawing.Size(600, 380);
            this.MainTableLayout.ResumeLayout(false);
            this.AddressPanel.ResumeLayout(false);
            this.AddressContentTableLayout.ResumeLayout(false);
            this.AddressContentTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private MenuControls.EditorToolStrip AddressToolSplit;
        private System.Windows.Forms.Panel AddressPanel;
        private System.Windows.Forms.TableLayoutPanel AddressContentTableLayout;
        private System.Windows.Forms.Label NameAddressLb;
        private System.Windows.Forms.TextBox NameField;
        private System.Windows.Forms.Label CountryLb;
        private System.Windows.Forms.Label AreaLb;
        private System.Windows.Forms.Label StreetLb;
        private System.Windows.Forms.Label HouseLb;
        private System.Windows.Forms.Label StructureLb;
        private System.Windows.Forms.Label OfficeLb;
        private System.Windows.Forms.TextBox LandField;
        private System.Windows.Forms.TextBox AreaField;
        private System.Windows.Forms.TextBox OfficeField;
        private System.Windows.Forms.TextBox StructureField;
        private System.Windows.Forms.Label PorchLb;
        private System.Windows.Forms.TextBox PorchField;
        private System.Windows.Forms.Label AddedTypesLb;
        private System.Windows.Forms.Label OkatoLb;
        private System.Windows.Forms.Label OktmoLb;
        private System.Windows.Forms.Label KladrLb;
        private System.Windows.Forms.Label SounLb;
        private System.Windows.Forms.Label SonoLb;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label DescriptionLb;
        private System.Windows.Forms.TextBox DescriptionField;
        private System.Windows.Forms.TextBox IndexField;
        private System.Windows.Forms.Label IndexLb;
        private System.Windows.Forms.TextBox SettlementField;
        private System.Windows.Forms.Label SettlementLb;
        private System.Windows.Forms.Label CityLb;
        private System.Windows.Forms.TextBox HouseField;
        private System.Windows.Forms.TextBox StreetField;
        private System.Windows.Forms.TextBox CityField;
        private ExtraControls.EditEntityBoxControl AddressTypeControl;
        private ExtraControls.EditEntityBoxControl FlagControl;
        private ExtraControls.EntityBoxControl AccessTypeControl;
        private System.Windows.Forms.Label AddressTypeLb;
        private System.Windows.Forms.Label FlagLb;
        private System.Windows.Forms.Label AccessTypeLb;
        private AddressTypeListControl AddressTypeListField;
        private ExtraControls.ClassificatorBox OkatoField;
        private ExtraControls.ClassificatorBox OktmoField;
        private ExtraControls.ClassificatorBox SonoField;

    }
}
