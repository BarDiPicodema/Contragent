﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class ParticipantListControl : Common.CUIControl, IParticipantListView
    {
        public ParticipantListControl ()
        {
            InitializeComponent ();

            var menu = new ListContextMenu ();
            menu.AddItem += (sender, arg) => Invoke (AddParticipant);
            menu.RemoveItem += (sender, arg) =>
                {
                    if ( ParticipantList.SelectedItem != null )
                        Invoke (RemoveParticipant);
                };
            ParticipantList.ContextMenu = menu;
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public object DataSource
        {
            get { return ParticipantList.DataSource; }
            set { ParticipantList.DataSource = value; }
        }

        public DocumentParticipant SelectedItem
        {
            get { return ParticipantList.SelectedItem as DocumentParticipant; }
        }

        public event Action AddParticipant;

        public event Action RemoveParticipant;
    }
}
