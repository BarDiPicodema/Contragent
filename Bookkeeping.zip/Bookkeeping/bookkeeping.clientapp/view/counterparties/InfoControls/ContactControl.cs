﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class ContactControl : Common.CUIControlAccess, IContactView
    {
        public IPresenter Presenter { get; set; }

        public ContactControl ()
            : base ()
        {
            InitializeComponent ();
            NameTitle = "Контакт";

            Presenter = new ContactPresenter (this, new Model.AccessServiceModel<Data.Entities.Contact> ());

            ContactTypeControl.Presenter = new EntityPresenter<ContactType> (ContactTypeControl, new Model.ServiceModel<ContactType> ());
            FlagControl.Presenter = new EntityPresenter<Flag> (FlagControl, new Model.ServiceModel<Flag> ());
            AccessTypeControl.Presenter = new EntityPresenter<AccessType> (AccessTypeControl, new Model.ServiceModel<AccessType> ());
            AccessPresenter = AccessTypeView;

            ToolView.SaveData += () => Invoke (InfoChange);
        }

        public IEditorToolView ToolView
        {
            get { return ContactToolStrip as IEditorToolView; }
        }

        public Contact Contact { get; set;}

        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        #region Properties
        public string ContactText
        {
            get { return ContactTextField.Text; }
            set { ContactTextField.Text = value; }
        }

        public string ContactName
        {
            get { return NameContactField.Text; }
            set { NameContactField.Text = value; }
        }

        public string Post
        {
            get { return PostField.Text; }
            set { PostField.Text = value; }
        }

        public string Sub
        {
            get { return SubdivisionField.Text; }
            set { SubdivisionField .Text = value; }
        }

        public string Note
        {
            get { return NoteField.Text; }
            set { NoteField.Text = value; }
        }
        #endregion

        public IEntityControlView ContactTypeView
        {
            get { return ContactTypeControl as IEntityControlView; }
        }

        public EntityPresenter<Data.Entities.ContactType> ContactType
        {
            get { return ContactTypeControl.Presenter as EntityPresenter<ContactType>; }
        }

        public IEntityControlView AccessTypeView
        {
            get { return AccessTypeControl as IEntityControlView; }
        }

        public EntityPresenter<Data.Entities.AccessType> AccessType
        {
            get { return AccessTypeControl.Presenter as EntityPresenter<AccessType>; }
        }

        public IEntityControlView FlagView
        {
            get { return FlagControl as IEntityControlView; }
        }

        public EntityPresenter<Data.Entities.Flag> Flag
        {
            get { return FlagControl.Presenter as EntityPresenter<Flag>; }
        }


        public event Action InfoChange;
    }
}
