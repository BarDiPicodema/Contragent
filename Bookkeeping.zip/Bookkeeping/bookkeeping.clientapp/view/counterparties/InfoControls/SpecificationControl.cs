﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Common;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class SpecificationControl : Common.CUIControl, ISpecificationView
    {
        public SpecificationControl ()
        {
            InitializeComponent ();

            Presenter = new SpecificationPresenter (this, new Model.ServiceModel<Specification> ());

            FontSizeField.SelectedIndex = 0;

            Save.Click += (sender, args) => Invoke (SaveData);
        }

        public IPresenter Presenter { get; set; }

        public Specification Specification { get; set; }

        public bool ReadOnly
        {
            get { return ToolSpecificationTextEdit.Enabled; }
            set { ToolSpecificationTextEdit.Enabled = value; }
        }

        public string TextSpecification
        {
            get { return SpecificationTextBox.Rtf; }
            set { SpecificationTextBox.Rtf = value;}
        }

        public string RtfText
        {
            get { return SpecificationTextBox.Rtf; }
            set { SpecificationTextBox.Rtf = value; }
        }

        public event Action SaveData;

        private void SpecificationControl_Load (object sender, EventArgs e)
        {
            FontStyleText.Items.Clear ();
            foreach ( FontFamily item in FontFamily.Families )
                if ( item.IsStyleAvailable (FontStyle.Regular) )
                {
                    FontStyleText.Items.Add (item.Name);
                }
        }

        #region Text style
        private void BoldText_Click (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionFont = new Font (SpecificationTextBox.SelectionFont, FontStyle.Bold);
        }

        private void ItalicText_Click (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionFont =  new Font (SpecificationTextBox.SelectionFont, FontStyle.Italic);
        }

        private void UnderlineText_Click (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionFont =  new Font (SpecificationTextBox.SelectionFont, FontStyle.Underline);
        }

        private void StrikethoughText_Click (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionFont =  new Font (SpecificationTextBox.SelectionFont, FontStyle.Strikeout);
        }
        #endregion

        #region Text alignment
        private void LeftAlignment_Click (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionAlignment = HorizontalAlignment.Left;
        }

        private void CenterAlignment_Click (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionAlignment = HorizontalAlignment.Center;
        }

        private void RightAlignment_Click (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionAlignment = HorizontalAlignment.Right;
        }
        #endregion

        #region PrintMenu
        private void PrintText_Click (object sender, EventArgs e)
        {
            PrintDialog print = new PrintDialog ();
            PrintDocument document = new PrintDocument ();
            document.DocumentName = "Document";
            print.Document = document;
            print.AllowSelection = true;
            print.AllowSomePages = true;
            if ( print.ShowDialog () == DialogResult.OK )
                document.Print ();
        }
        #endregion

        #region Colors
        private void FontColor_Click (object sender, EventArgs e)
        {
            ColorDialog color = new ColorDialog ();
            color.SolidColorOnly = true;
            if ( color.ShowDialog () == DialogResult.OK )
                SpecificationTextBox.SelectionColor = color.Color;
        }

        private void ForegroundColor_Click (object sender, EventArgs e)
        {
            ColorDialog color = new ColorDialog ();
            color.SolidColorOnly = true;
            if ( color.ShowDialog () == DialogResult.OK )
                SpecificationTextBox.SelectionBackColor = color.Color;
        }
        #endregion

        private void FontStyleText_SelectedIndexChanged (object sender, EventArgs e)
        {
            //var fontFamily = Font.FontFamily FontFamily.Families.ToList().Find (item => item.Name == FontStyleText.SelectedText);
            SpecificationTextBox.SelectionFont = new Font (FontStyleText.Text, Convert.ToInt32 (FontSizeField.Text));
        }

        private void FontSizeField_Leave (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionFont = new Font (FontStyleText.Text, Convert.ToInt32 (FontSizeField.Text));
        }

        private void FontSizeField_SelectedIndexChanged (object sender, EventArgs e)
        {
            SpecificationTextBox.SelectionFont = new Font (FontStyleText.Text, Convert.ToInt32 (FontSizeField.Text));
        }

        public event Action PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged ();
        }
    }
}
