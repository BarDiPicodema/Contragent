﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    partial class SpecificationControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SpecificationControl));
            this.ToolSpecificationTextEdit = new System.Windows.Forms.ToolStrip();
            this.Save = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.FontStyleText = new System.Windows.Forms.ToolStripComboBox();
            this.FontSizeField = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.BoldText = new System.Windows.Forms.ToolStripButton();
            this.ItalicText = new System.Windows.Forms.ToolStripButton();
            this.UnderlineText = new System.Windows.Forms.ToolStripButton();
            this.StrikethoughText = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.LeftAlignment = new System.Windows.Forms.ToolStripButton();
            this.CenterAlignment = new System.Windows.Forms.ToolStripButton();
            this.RightAlignment = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.FontColor = new System.Windows.Forms.ToolStripButton();
            this.ForegroundColor = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.PrintText = new System.Windows.Forms.ToolStripButton();
            this.SpecificationTextBox = new System.Windows.Forms.RichTextBox();
            this.ToolSpecificationTextEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolSpecificationTextEdit
            // 
            this.ToolSpecificationTextEdit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Save,
            this.toolStripSeparator5,
            this.FontStyleText,
            this.FontSizeField,
            this.toolStripSeparator3,
            this.BoldText,
            this.ItalicText,
            this.UnderlineText,
            this.StrikethoughText,
            this.toolStripSeparator1,
            this.LeftAlignment,
            this.CenterAlignment,
            this.RightAlignment,
            this.toolStripSeparator2,
            this.FontColor,
            this.ForegroundColor,
            this.toolStripSeparator4,
            this.PrintText});
            this.ToolSpecificationTextEdit.Location = new System.Drawing.Point(0, 0);
            this.ToolSpecificationTextEdit.Name = "ToolSpecificationTextEdit";
            this.ToolSpecificationTextEdit.Size = new System.Drawing.Size(620, 25);
            this.ToolSpecificationTextEdit.TabIndex = 0;
            this.ToolSpecificationTextEdit.Text = "toolStrip1";
            // 
            // Save
            // 
            this.Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Save.Image = global::Bookkeeping.ClientApp.Properties.Resources.save;
            this.Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(23, 22);
            this.Save.Text = "Сохранить";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // FontStyleText
            // 
            this.FontStyleText.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FontStyleText.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.FontStyleText.Name = "FontStyleText";
            this.FontStyleText.Size = new System.Drawing.Size(121, 25);
            this.FontStyleText.SelectedIndexChanged += new System.EventHandler(this.FontStyleText_SelectedIndexChanged);
            // 
            // FontSizeField
            // 
            this.FontSizeField.Items.AddRange(new object[] {
            "8",
            "10",
            "12",
            "14",
            "16",
            "18",
            "20",
            "22",
            "24",
            "26"});
            this.FontSizeField.MaxLength = 3;
            this.FontSizeField.Name = "FontSizeField";
            this.FontSizeField.Size = new System.Drawing.Size(75, 25);
            this.FontSizeField.SelectedIndexChanged += new System.EventHandler(this.FontSizeField_SelectedIndexChanged);
            this.FontSizeField.Leave += new System.EventHandler(this.FontSizeField_Leave);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // BoldText
            // 
            this.BoldText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.BoldText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoldText.Image = ((System.Drawing.Image)(resources.GetObject("BoldText.Image")));
            this.BoldText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BoldText.Name = "BoldText";
            this.BoldText.Size = new System.Drawing.Size(23, 22);
            this.BoldText.Text = "B";
            this.BoldText.Click += new System.EventHandler(this.BoldText_Click);
            // 
            // ItalicText
            // 
            this.ItalicText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ItalicText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ItalicText.Image = ((System.Drawing.Image)(resources.GetObject("ItalicText.Image")));
            this.ItalicText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ItalicText.Name = "ItalicText";
            this.ItalicText.Size = new System.Drawing.Size(23, 22);
            this.ItalicText.Text = "I";
            this.ItalicText.Click += new System.EventHandler(this.ItalicText_Click);
            // 
            // UnderlineText
            // 
            this.UnderlineText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.UnderlineText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UnderlineText.Image = ((System.Drawing.Image)(resources.GetObject("UnderlineText.Image")));
            this.UnderlineText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.UnderlineText.Name = "UnderlineText";
            this.UnderlineText.Size = new System.Drawing.Size(23, 22);
            this.UnderlineText.Text = "U";
            this.UnderlineText.Click += new System.EventHandler(this.UnderlineText_Click);
            // 
            // StrikethoughText
            // 
            this.StrikethoughText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StrikethoughText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StrikethoughText.Image = ((System.Drawing.Image)(resources.GetObject("StrikethoughText.Image")));
            this.StrikethoughText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StrikethoughText.Name = "StrikethoughText";
            this.StrikethoughText.Size = new System.Drawing.Size(23, 22);
            this.StrikethoughText.Text = "S";
            this.StrikethoughText.Click += new System.EventHandler(this.StrikethoughText_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // LeftAlignment
            // 
            this.LeftAlignment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.LeftAlignment.Image = global::Bookkeeping.ClientApp.Properties.Resources.text_align_left;
            this.LeftAlignment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.LeftAlignment.Name = "LeftAlignment";
            this.LeftAlignment.Size = new System.Drawing.Size(23, 22);
            this.LeftAlignment.Text = "Left alignment";
            this.LeftAlignment.Click += new System.EventHandler(this.LeftAlignment_Click);
            // 
            // CenterAlignment
            // 
            this.CenterAlignment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.CenterAlignment.Image = global::Bookkeeping.ClientApp.Properties.Resources.text_align_center;
            this.CenterAlignment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CenterAlignment.Name = "CenterAlignment";
            this.CenterAlignment.Size = new System.Drawing.Size(23, 22);
            this.CenterAlignment.Text = "Center alignment";
            this.CenterAlignment.Click += new System.EventHandler(this.CenterAlignment_Click);
            // 
            // RightAlignment
            // 
            this.RightAlignment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.RightAlignment.Image = global::Bookkeeping.ClientApp.Properties.Resources.text_align_right;
            this.RightAlignment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RightAlignment.Name = "RightAlignment";
            this.RightAlignment.Size = new System.Drawing.Size(23, 22);
            this.RightAlignment.Text = "Right alignment";
            this.RightAlignment.Click += new System.EventHandler(this.RightAlignment_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // FontColor
            // 
            this.FontColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FontColor.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FontColor.ForeColor = System.Drawing.Color.Red;
            this.FontColor.Image = ((System.Drawing.Image)(resources.GetObject("FontColor.Image")));
            this.FontColor.ImageTransparentColor = System.Drawing.Color.Red;
            this.FontColor.Name = "FontColor";
            this.FontColor.Size = new System.Drawing.Size(23, 22);
            this.FontColor.Text = "A";
            this.FontColor.Click += new System.EventHandler(this.FontColor_Click);
            // 
            // ForegroundColor
            // 
            this.ForegroundColor.BackColor = System.Drawing.Color.Yellow;
            this.ForegroundColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ForegroundColor.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForegroundColor.Image = ((System.Drawing.Image)(resources.GetObject("ForegroundColor.Image")));
            this.ForegroundColor.ImageTransparentColor = System.Drawing.Color.Yellow;
            this.ForegroundColor.Name = "ForegroundColor";
            this.ForegroundColor.Size = new System.Drawing.Size(32, 22);
            this.ForegroundColor.Text = "Abc";
            this.ForegroundColor.Click += new System.EventHandler(this.ForegroundColor_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // PrintText
            // 
            this.PrintText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.PrintText.Image = global::Bookkeeping.ClientApp.Properties.Resources.printer;
            this.PrintText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.PrintText.Name = "PrintText";
            this.PrintText.Size = new System.Drawing.Size(23, 22);
            this.PrintText.Text = "Print";
            this.PrintText.Click += new System.EventHandler(this.PrintText_Click);
            // 
            // SpecificationTextBox
            // 
            this.SpecificationTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SpecificationTextBox.Location = new System.Drawing.Point(0, 25);
            this.SpecificationTextBox.Name = "SpecificationTextBox";
            this.SpecificationTextBox.Size = new System.Drawing.Size(620, 315);
            this.SpecificationTextBox.TabIndex = 1;
            this.SpecificationTextBox.Text = "";
            this.SpecificationTextBox.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SpecificationControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.SpecificationTextBox);
            this.Controls.Add(this.ToolSpecificationTextEdit);
            this.Name = "SpecificationControl";
            this.Size = new System.Drawing.Size(620, 340);
            this.Load += new System.EventHandler(this.SpecificationControl_Load);
            this.ToolSpecificationTextEdit.ResumeLayout(false);
            this.ToolSpecificationTextEdit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip ToolSpecificationTextEdit;
        private System.Windows.Forms.ToolStripButton BoldText;
        private System.Windows.Forms.ToolStripButton ItalicText;
        private System.Windows.Forms.ToolStripButton UnderlineText;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton LeftAlignment;
        private System.Windows.Forms.ToolStripButton CenterAlignment;
        private System.Windows.Forms.ToolStripButton RightAlignment;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.RichTextBox SpecificationTextBox;
        private System.Windows.Forms.ToolStripComboBox FontStyleText;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton StrikethoughText;
        private System.Windows.Forms.ToolStripButton FontColor;
        private System.Windows.Forms.ToolStripButton ForegroundColor;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton PrintText;
        private System.Windows.Forms.ToolStripButton Save;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripComboBox FontSizeField;
    }
}
