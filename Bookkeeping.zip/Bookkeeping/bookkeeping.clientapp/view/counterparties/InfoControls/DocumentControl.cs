﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class DocumentControl : Common.CUIControlAccess, IDocumentView
    {
        public DocumentControl ()
        {
            InitializeComponent ();
            NameTitle = "Документ";

            Presenter = new DocumentPresenter (this, new Model.AccessServiceModel<Data.Entities.Document> ());

            DocumentTypeControl.Presenter = new EntityPresenter<DocumentType> (DocumentTypeControl, new Model.ServiceModel<DocumentType> ());
            FlagControl.Presenter = new EntityPresenter<Flag> (FlagControl, new Model.ServiceModel<Flag> ());
            AccessTypeControl.Presenter = new EntityPresenter<AccessType> (AccessTypeControl, new Model.ServiceModel<AccessType> ());
            AccessPresenter = AccessTypeView;
            ParticipantList.Presenter = new ParticipantListPresenter (ParticipantList, new Model.ServiceModel<DocumentParticipant> ());
            LinkList.Presenter = new LinkListPresenter (LinkList, new Model.ServiceModel<Link> ());
        }

        public IEditorToolView ToolView
        {
            get { return DocumentToolStrip as IEditorToolView; }
        }

        public IPresenter Presenter { get; set; }

        public Data.Entities.Document Document { get; set; }

        #region Properties
        public string DocumentName
        {
            get { return NameField.Text; }
            set { NameField.Text = value; }
        }

        public string Appointment
        {
            get { return AppointmentField.Text; }
            set
            {
                AppointmentField.Text = value;
            }
        }

        public string Series
        {
            get { return SeriesField.Text; }
            set
            {
                SeriesField.Text = value;
            }
        }

        public string Number
        {
            get
            {
                return NumberField.Text;
            }
            set
            {
                NumberField.Text = value;
            }
        }

        public DateTime DocumentDate
        {
            get
            {
                return CreateDateField.Value;
            }
            set
            {
                CreateDateField.Value = value;
            }
        }

        public string DocumentPlace
        {
            get
            {
                return PlaceField.Text;
            }
            set
            {
                PlaceField.Text = value;
            }
        }

        public string SubdivisionCode
        {
            get
            {
                return SubdivisionCodeField.Text;
            }
            set
            {
                SubdivisionCodeField.Text = value;
            }
        }

        public DateTime ExpDate
        {
            get
            {
                return ExpDataField.Value;
            }
            set
            {
                ExpDataField.Value = value;
            }
        }

        public string Renew
        {
            get
            {
                return RenewField.Text;
            }
            set
            {
                RenewField.Text = value;
            }
        }

        public string Issues
        {
            get
            {
                return IssuerField.Text;
            }
            set
            {
                IssuerField.Text = value;
            }
        }

        public string Note
        {
            get
            {
                return NoteField.Text;
            }
            set
            {
                NoteField.Text = value;
            }
        }
        #endregion

        public IEntityControlView DocumentTypeView
        {
            get { return DocumentTypeControl; }
        }

        public EntityPresenter<Data.Entities.DocumentType> DocumentType
        {
            get { return DocumentTypeControl.Presenter as EntityPresenter<DocumentType>; }
        }

        public IParticipantListView ParticipantListView
        {
            get { return ParticipantList; }
        }

        public ParticipantListPresenter ParticipantListPresenter
        {
            get { return ParticipantList.Presenter as ParticipantListPresenter; }
        }

        public ILinkListView LinkListView
        {
            get { return LinkList; }
        }

        public LinkListPresenter LinkListPresenter
        {
            get { return LinkList.Presenter as LinkListPresenter; }
        }


        public IEntityControlView AccessTypeView
        {
            get { return AccessTypeControl; }
        }

        public EntityPresenter<Data.Entities.AccessType> AccessType
        {
            get { return AccessTypeControl.Presenter as EntityPresenter<AccessType>; }
        }

        public IEntityControlView FlagView
        {
            get { return FlagControl; }
        }

        public EntityPresenter<Data.Entities.Flag> Flag
        {
            get { return FlagControl.Presenter as EntityPresenter<Flag>; }
        }


        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        public event Action InfoChange;

        public bool ParticipantsEnable
        {
            get { return ParticipantList.Enabled; }
            set { ParticipantList.Enabled = value; }
        }

        public bool LinksEnable
        {
            get { return LinkList.Enabled; }
            set { LinkList.Enabled = value; }
        }
    }
}
