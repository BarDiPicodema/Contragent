﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    partial class AccountControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.AccountToolStrip = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.AccountPanel = new System.Windows.Forms.Panel();
            this.AccountContentTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.NameLb = new System.Windows.Forms.Label();
            this.NumberAccountLb = new System.Windows.Forms.Label();
            this.RecipientLb = new System.Windows.Forms.Label();
            this.IbanLb = new System.Windows.Forms.Label();
            this.BicLb = new System.Windows.Forms.Label();
            this.BankLb = new System.Windows.Forms.Label();
            this.SettlementBankLb = new System.Windows.Forms.Label();
            this.CorAccountLb = new System.Windows.Forms.Label();
            this.CorBankLb = new System.Windows.Forms.Label();
            this.NameField = new System.Windows.Forms.TextBox();
            this.BankField = new System.Windows.Forms.TextBox();
            this.DescriptionLb = new System.Windows.Forms.Label();
            this.NumberAccountField = new System.Windows.Forms.TextBox();
            this.IbanField = new System.Windows.Forms.TextBox();
            this.CorBankField = new System.Windows.Forms.TextBox();
            this.CorAccountField = new System.Windows.Forms.TextBox();
            this.AddressField = new System.Windows.Forms.TextBox();
            this.RecipientField = new System.Windows.Forms.TextBox();
            this.DescriptionField = new System.Windows.Forms.TextBox();
            this.AddedDataTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.AccountTypeLb = new System.Windows.Forms.Label();
            this.AccountKindLb = new System.Windows.Forms.Label();
            this.AccessTypeLb = new System.Windows.Forms.Label();
            this.OkvLb = new System.Windows.Forms.Label();
            this.FlagLb = new System.Windows.Forms.Label();
            this.AccessTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.FlagControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.AccountTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.AccountKindControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.OkvField = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ClassificatorBox();
            this.label12 = new System.Windows.Forms.Label();
            this.LSLb = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.BicField = new System.Windows.Forms.TextBox();
            this.MainTableLayout.SuspendLayout();
            this.AccountPanel.SuspendLayout();
            this.AccountContentTableLayout.SuspendLayout();
            this.AddedDataTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.AccountToolStrip, 0, 0);
            this.MainTableLayout.Controls.Add(this.AccountPanel, 0, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(600, 380);
            this.MainTableLayout.TabIndex = 0;
            // 
            // AccountToolStrip
            // 
            this.AccountToolStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountToolStrip.Location = new System.Drawing.Point(3, 3);
            this.AccountToolStrip.Name = "AccountToolStrip";
            this.AccountToolStrip.NameTitle = null;
            this.AccountToolStrip.Size = new System.Drawing.Size(594, 22);
            this.AccountToolStrip.TabIndex = 3;
            // 
            // AccountPanel
            // 
            this.AccountPanel.AutoScroll = true;
            this.AccountPanel.Controls.Add(this.AccountContentTableLayout);
            this.AccountPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountPanel.Location = new System.Drawing.Point(3, 31);
            this.AccountPanel.Name = "AccountPanel";
            this.AccountPanel.Size = new System.Drawing.Size(594, 346);
            this.AccountPanel.TabIndex = 4;
            // 
            // AccountContentTableLayout
            // 
            this.AccountContentTableLayout.ColumnCount = 6;
            this.AccountContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.AccountContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.AccountContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.AccountContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.AccountContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.AccountContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.AccountContentTableLayout.Controls.Add(this.NameLb, 0, 2);
            this.AccountContentTableLayout.Controls.Add(this.NumberAccountLb, 0, 3);
            this.AccountContentTableLayout.Controls.Add(this.RecipientLb, 0, 4);
            this.AccountContentTableLayout.Controls.Add(this.IbanLb, 3, 5);
            this.AccountContentTableLayout.Controls.Add(this.BicLb, 0, 5);
            this.AccountContentTableLayout.Controls.Add(this.BankLb, 0, 6);
            this.AccountContentTableLayout.Controls.Add(this.SettlementBankLb, 0, 7);
            this.AccountContentTableLayout.Controls.Add(this.CorAccountLb, 0, 8);
            this.AccountContentTableLayout.Controls.Add(this.CorBankLb, 3, 8);
            this.AccountContentTableLayout.Controls.Add(this.NameField, 1, 2);
            this.AccountContentTableLayout.Controls.Add(this.BankField, 1, 6);
            this.AccountContentTableLayout.Controls.Add(this.DescriptionLb, 0, 9);
            this.AccountContentTableLayout.Controls.Add(this.NumberAccountField, 1, 3);
            this.AccountContentTableLayout.Controls.Add(this.IbanField, 4, 5);
            this.AccountContentTableLayout.Controls.Add(this.CorBankField, 4, 8);
            this.AccountContentTableLayout.Controls.Add(this.CorAccountField, 1, 8);
            this.AccountContentTableLayout.Controls.Add(this.AddressField, 1, 7);
            this.AccountContentTableLayout.Controls.Add(this.RecipientField, 1, 4);
            this.AccountContentTableLayout.Controls.Add(this.DescriptionField, 1, 9);
            this.AccountContentTableLayout.Controls.Add(this.AddedDataTableLayout, 0, 0);
            this.AccountContentTableLayout.Controls.Add(this.BicField, 1, 5);
            this.AccountContentTableLayout.Dock = System.Windows.Forms.DockStyle.Top;
            this.AccountContentTableLayout.Location = new System.Drawing.Point(0, 0);
            this.AccountContentTableLayout.Name = "AccountContentTableLayout";
            this.AccountContentTableLayout.RowCount = 10;
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.AccountContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 94F));
            this.AccountContentTableLayout.Size = new System.Drawing.Size(594, 346);
            this.AccountContentTableLayout.TabIndex = 3;
            // 
            // NameLb
            // 
            this.NameLb.AutoSize = true;
            this.NameLb.Location = new System.Drawing.Point(3, 52);
            this.NameLb.Name = "NameLb";
            this.NameLb.Size = new System.Drawing.Size(61, 13);
            this.NameLb.TabIndex = 0;
            this.NameLb.Text = "Название*";
            // 
            // NumberAccountLb
            // 
            this.NumberAccountLb.AutoSize = true;
            this.NumberAccountLb.Location = new System.Drawing.Point(3, 78);
            this.NumberAccountLb.Name = "NumberAccountLb";
            this.NumberAccountLb.Size = new System.Drawing.Size(53, 13);
            this.NumberAccountLb.TabIndex = 0;
            this.NumberAccountLb.Text = "№ счета*";
            // 
            // RecipientLb
            // 
            this.RecipientLb.AutoSize = true;
            this.RecipientLb.Location = new System.Drawing.Point(3, 104);
            this.RecipientLb.Name = "RecipientLb";
            this.RecipientLb.Size = new System.Drawing.Size(70, 13);
            this.RecipientLb.TabIndex = 0;
            this.RecipientLb.Text = "Получатель*";
            // 
            // IbanLb
            // 
            this.IbanLb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IbanLb.AutoSize = true;
            this.IbanLb.Location = new System.Drawing.Point(357, 130);
            this.IbanLb.Name = "IbanLb";
            this.IbanLb.Size = new System.Drawing.Size(32, 13);
            this.IbanLb.TabIndex = 0;
            this.IbanLb.Text = "IBAN";
            // 
            // BicLb
            // 
            this.BicLb.AutoSize = true;
            this.BicLb.Location = new System.Drawing.Point(3, 130);
            this.BicLb.Name = "BicLb";
            this.BicLb.Size = new System.Drawing.Size(26, 13);
            this.BicLb.TabIndex = 0;
            this.BicLb.Text = "Бик";
            // 
            // BankLb
            // 
            this.BankLb.AutoSize = true;
            this.BankLb.Location = new System.Drawing.Point(3, 156);
            this.BankLb.Name = "BankLb";
            this.BankLb.Size = new System.Drawing.Size(32, 13);
            this.BankLb.TabIndex = 0;
            this.BankLb.Text = "Банк";
            // 
            // SettlementBankLb
            // 
            this.SettlementBankLb.AutoSize = true;
            this.SettlementBankLb.Location = new System.Drawing.Point(3, 182);
            this.SettlementBankLb.Name = "SettlementBankLb";
            this.SettlementBankLb.Size = new System.Drawing.Size(38, 13);
            this.SettlementBankLb.TabIndex = 0;
            this.SettlementBankLb.Text = "Адрес";
            // 
            // CorAccountLb
            // 
            this.CorAccountLb.AutoSize = true;
            this.CorAccountLb.Location = new System.Drawing.Point(3, 208);
            this.CorAccountLb.Name = "CorAccountLb";
            this.CorAccountLb.Size = new System.Drawing.Size(54, 13);
            this.CorAccountLb.TabIndex = 0;
            this.CorAccountLb.Text = "Кор. счет";
            // 
            // CorBankLb
            // 
            this.CorBankLb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CorBankLb.AutoSize = true;
            this.CorBankLb.Location = new System.Drawing.Point(333, 208);
            this.CorBankLb.Name = "CorBankLb";
            this.CorBankLb.Size = new System.Drawing.Size(56, 13);
            this.CorBankLb.TabIndex = 0;
            this.CorBankLb.Text = "Кор. банк";
            // 
            // NameField
            // 
            this.NameField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.NameField, 5);
            this.NameField.Location = new System.Drawing.Point(101, 55);
            this.NameField.Name = "NameField";
            this.NameField.Size = new System.Drawing.Size(490, 20);
            this.NameField.TabIndex = 1;
            this.NameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // BankField
            // 
            this.BankField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.BankField, 5);
            this.BankField.Location = new System.Drawing.Point(101, 159);
            this.BankField.Name = "BankField";
            this.BankField.Size = new System.Drawing.Size(490, 20);
            this.BankField.TabIndex = 1;
            this.BankField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // DescriptionLb
            // 
            this.DescriptionLb.AutoSize = true;
            this.DescriptionLb.Location = new System.Drawing.Point(3, 234);
            this.DescriptionLb.Name = "DescriptionLb";
            this.DescriptionLb.Size = new System.Drawing.Size(57, 13);
            this.DescriptionLb.TabIndex = 0;
            this.DescriptionLb.Text = "Описание";
            // 
            // NumberAccountField
            // 
            this.NumberAccountField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.NumberAccountField, 2);
            this.NumberAccountField.Location = new System.Drawing.Point(101, 81);
            this.NumberAccountField.Name = "NumberAccountField";
            this.NumberAccountField.Size = new System.Drawing.Size(190, 20);
            this.NumberAccountField.TabIndex = 1;
            this.NumberAccountField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // IbanField
            // 
            this.IbanField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.IbanField, 2);
            this.IbanField.Location = new System.Drawing.Point(395, 133);
            this.IbanField.Name = "IbanField";
            this.IbanField.Size = new System.Drawing.Size(196, 20);
            this.IbanField.TabIndex = 1;
            this.IbanField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // CorBankField
            // 
            this.CorBankField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.CorBankField, 2);
            this.CorBankField.Location = new System.Drawing.Point(395, 211);
            this.CorBankField.Name = "CorBankField";
            this.CorBankField.Size = new System.Drawing.Size(196, 20);
            this.CorBankField.TabIndex = 1;
            this.CorBankField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // CorAccountField
            // 
            this.CorAccountField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.CorAccountField, 2);
            this.CorAccountField.Location = new System.Drawing.Point(101, 211);
            this.CorAccountField.Name = "CorAccountField";
            this.CorAccountField.Size = new System.Drawing.Size(190, 20);
            this.CorAccountField.TabIndex = 1;
            this.CorAccountField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // AddressField
            // 
            this.AddressField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.AddressField, 5);
            this.AddressField.Location = new System.Drawing.Point(101, 185);
            this.AddressField.Name = "AddressField";
            this.AddressField.Size = new System.Drawing.Size(490, 20);
            this.AddressField.TabIndex = 1;
            this.AddressField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // RecipientField
            // 
            this.RecipientField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.RecipientField, 5);
            this.RecipientField.Location = new System.Drawing.Point(101, 107);
            this.RecipientField.Name = "RecipientField";
            this.RecipientField.Size = new System.Drawing.Size(490, 20);
            this.RecipientField.TabIndex = 1;
            this.RecipientField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // DescriptionField
            // 
            this.DescriptionField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountContentTableLayout.SetColumnSpan(this.DescriptionField, 5);
            this.DescriptionField.Location = new System.Drawing.Point(101, 237);
            this.DescriptionField.MaxLength = 2000;
            this.DescriptionField.Multiline = true;
            this.DescriptionField.Name = "DescriptionField";
            this.DescriptionField.Size = new System.Drawing.Size(490, 106);
            this.DescriptionField.TabIndex = 1;
            this.DescriptionField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // AddedDataTableLayout
            // 
            this.AddedDataTableLayout.ColumnCount = 6;
            this.AccountContentTableLayout.SetColumnSpan(this.AddedDataTableLayout, 6);
            this.AddedDataTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.AddedDataTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.AddedDataTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.AddedDataTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.AddedDataTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.AddedDataTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.AddedDataTableLayout.Controls.Add(this.AccountTypeLb, 0, 0);
            this.AddedDataTableLayout.Controls.Add(this.AccountKindLb, 0, 1);
            this.AddedDataTableLayout.Controls.Add(this.AccessTypeLb, 2, 0);
            this.AddedDataTableLayout.Controls.Add(this.OkvLb, 2, 1);
            this.AddedDataTableLayout.Controls.Add(this.FlagLb, 4, 0);
            this.AddedDataTableLayout.Controls.Add(this.AccessTypeControl, 3, 0);
            this.AddedDataTableLayout.Controls.Add(this.FlagControl, 5, 0);
            this.AddedDataTableLayout.Controls.Add(this.AccountTypeControl, 1, 0);
            this.AddedDataTableLayout.Controls.Add(this.AccountKindControl, 1, 1);
            this.AddedDataTableLayout.Controls.Add(this.OkvField, 3, 1);
            this.AddedDataTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddedDataTableLayout.Location = new System.Drawing.Point(0, 0);
            this.AddedDataTableLayout.Margin = new System.Windows.Forms.Padding(0);
            this.AddedDataTableLayout.Name = "AddedDataTableLayout";
            this.AddedDataTableLayout.RowCount = 2;
            this.AccountContentTableLayout.SetRowSpan(this.AddedDataTableLayout, 2);
            this.AddedDataTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.AddedDataTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.AddedDataTableLayout.Size = new System.Drawing.Size(594, 52);
            this.AddedDataTableLayout.TabIndex = 2;
            // 
            // AccountTypeLb
            // 
            this.AccountTypeLb.AutoSize = true;
            this.AccountTypeLb.Location = new System.Drawing.Point(3, 0);
            this.AccountTypeLb.Name = "AccountTypeLb";
            this.AccountTypeLb.Size = new System.Drawing.Size(30, 13);
            this.AccountTypeLb.TabIndex = 0;
            this.AccountTypeLb.Text = "Тип*";
            // 
            // AccountKindLb
            // 
            this.AccountKindLb.AutoSize = true;
            this.AccountKindLb.Location = new System.Drawing.Point(3, 26);
            this.AccountKindLb.Name = "AccountKindLb";
            this.AccountKindLb.Size = new System.Drawing.Size(30, 13);
            this.AccountKindLb.TabIndex = 0;
            this.AccountKindLb.Text = "Вид*";
            // 
            // AccessTypeLb
            // 
            this.AccessTypeLb.AutoSize = true;
            this.AccessTypeLb.Location = new System.Drawing.Point(204, 0);
            this.AccessTypeLb.Name = "AccessTypeLb";
            this.AccessTypeLb.Size = new System.Drawing.Size(48, 13);
            this.AccessTypeLb.TabIndex = 0;
            this.AccessTypeLb.Text = "Доступ*";
            // 
            // OkvLb
            // 
            this.OkvLb.AutoSize = true;
            this.OkvLb.Location = new System.Drawing.Point(204, 26);
            this.OkvLb.Name = "OkvLb";
            this.OkvLb.Size = new System.Drawing.Size(29, 13);
            this.OkvLb.TabIndex = 0;
            this.OkvLb.Text = "ОКВ";
            // 
            // FlagLb
            // 
            this.FlagLb.AutoSize = true;
            this.FlagLb.Location = new System.Drawing.Point(405, 0);
            this.FlagLb.Name = "FlagLb";
            this.FlagLb.Size = new System.Drawing.Size(39, 13);
            this.FlagLb.TabIndex = 0;
            this.FlagLb.Text = "Флаг*";
            // 
            // AccessTypeControl
            // 
            this.AccessTypeControl.DataSource = null;
            this.AccessTypeControl.DisplayProperty = "TypeName";
            this.AccessTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccessTypeControl.Location = new System.Drawing.Point(263, 2);
            this.AccessTypeControl.Margin = new System.Windows.Forms.Padding(2);
            this.AccessTypeControl.Name = "AccessTypeControl";
            this.AccessTypeControl.NameTitle = null;
            this.AccessTypeControl.Presenter = null;
            this.AccessTypeControl.SelectedEntity = null;
            this.AccessTypeControl.Size = new System.Drawing.Size(137, 22);
            this.AccessTypeControl.TabIndex = 1;
            // 
            // FlagControl
            // 
            this.FlagControl.DataSource = null;
            this.FlagControl.DisplayProperty = "TypeName";
            this.FlagControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlagControl.Location = new System.Drawing.Point(454, 2);
            this.FlagControl.Margin = new System.Windows.Forms.Padding(2);
            this.FlagControl.Name = "FlagControl";
            this.FlagControl.NameTitle = null;
            this.FlagControl.Presenter = null;
            this.FlagControl.SelectedEntity = null;
            this.FlagControl.Size = new System.Drawing.Size(138, 22);
            this.FlagControl.TabIndex = 2;
            // 
            // AccountTypeControl
            // 
            this.AccountTypeControl.DataSource = null;
            this.AccountTypeControl.DisplayProperty = "TypeName";
            this.AccountTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountTypeControl.Location = new System.Drawing.Point(62, 2);
            this.AccountTypeControl.Margin = new System.Windows.Forms.Padding(2);
            this.AccountTypeControl.Name = "AccountTypeControl";
            this.AccountTypeControl.NameTitle = null;
            this.AccountTypeControl.Presenter = null;
            this.AccountTypeControl.SelectedEntity = null;
            this.AccountTypeControl.Size = new System.Drawing.Size(137, 22);
            this.AccountTypeControl.TabIndex = 2;
            // 
            // AccountKindControl
            // 
            this.AccountKindControl.DataSource = null;
            this.AccountKindControl.DisplayProperty = "TypeName";
            this.AccountKindControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountKindControl.Location = new System.Drawing.Point(62, 28);
            this.AccountKindControl.Margin = new System.Windows.Forms.Padding(2);
            this.AccountKindControl.Name = "AccountKindControl";
            this.AccountKindControl.NameTitle = null;
            this.AccountKindControl.Presenter = null;
            this.AccountKindControl.SelectedEntity = null;
            this.AccountKindControl.Size = new System.Drawing.Size(137, 22);
            this.AccountKindControl.TabIndex = 2;
            // 
            // OkvField
            // 
            this.OkvField.Classificator = null;
            this.OkvField.ClassificatorCode = "";
            this.OkvField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OkvField.Location = new System.Drawing.Point(264, 29);
            this.OkvField.Name = "OkvField";
            this.OkvField.NameTitle = null;
            this.OkvField.Presenter = null;
            this.OkvField.Size = new System.Drawing.Size(135, 20);
            this.OkvField.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(199, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "ОКВ";
            // 
            // LSLb
            // 
            this.LSLb.AutoSize = true;
            this.LSLb.Location = new System.Drawing.Point(297, 78);
            this.LSLb.Name = "LSLb";
            this.LSLb.Size = new System.Drawing.Size(24, 13);
            this.LSLb.TabIndex = 0;
            this.LSLb.Text = "л/с";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Бик";
            // 
            // BicField
            // 
            this.AccountContentTableLayout.SetColumnSpan(this.BicField, 2);
            this.BicField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BicField.Location = new System.Drawing.Point(101, 133);
            this.BicField.Name = "BicField";
            this.BicField.Size = new System.Drawing.Size(190, 20);
            this.BicField.TabIndex = 3;
            // 
            // AccountControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "AccountControl";
            this.Size = new System.Drawing.Size(600, 380);
            this.MainTableLayout.ResumeLayout(false);
            this.AccountPanel.ResumeLayout(false);
            this.AccountContentTableLayout.ResumeLayout(false);
            this.AccountContentTableLayout.PerformLayout();
            this.AddedDataTableLayout.ResumeLayout(false);
            this.AddedDataTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private MenuControls.EditorToolStrip AccountToolStrip;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label LSLb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel AccountPanel;
        private System.Windows.Forms.TableLayoutPanel AccountContentTableLayout;
        private System.Windows.Forms.Label NameLb;
        private System.Windows.Forms.Label NumberAccountLb;
        private System.Windows.Forms.Label RecipientLb;
        private System.Windows.Forms.Label IbanLb;
        private System.Windows.Forms.Label BicLb;
        private System.Windows.Forms.Label BankLb;
        private System.Windows.Forms.Label SettlementBankLb;
        private System.Windows.Forms.Label CorAccountLb;
        private System.Windows.Forms.Label CorBankLb;
        private System.Windows.Forms.TextBox NameField;
        private System.Windows.Forms.TextBox BankField;
        private System.Windows.Forms.Label DescriptionLb;
        private System.Windows.Forms.TextBox NumberAccountField;
        private System.Windows.Forms.TextBox IbanField;
        private System.Windows.Forms.TextBox CorBankField;
        private System.Windows.Forms.TextBox CorAccountField;
        private System.Windows.Forms.TextBox AddressField;
        private System.Windows.Forms.TextBox RecipientField;
        private System.Windows.Forms.TextBox DescriptionField;
        private System.Windows.Forms.TableLayoutPanel AddedDataTableLayout;
        private System.Windows.Forms.Label AccountTypeLb;
        private System.Windows.Forms.Label AccountKindLb;
        private System.Windows.Forms.Label AccessTypeLb;
        private System.Windows.Forms.Label OkvLb;
        private System.Windows.Forms.Label FlagLb;
        private ExtraControls.EntityBoxControl AccessTypeControl;
        private ExtraControls.EditEntityBoxControl FlagControl;
        private ExtraControls.EditEntityBoxControl AccountTypeControl;
        private ExtraControls.EditEntityBoxControl AccountKindControl;
        private ExtraControls.ClassificatorBox OkvField;
        private System.Windows.Forms.TextBox BicField;

    }
}
