﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info.OtherInfoPresenter;
using Bookkeeping.ClientApp.View.Counterparties.InfoControls.OtherInfoControl;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class LinkListControl : Common.CUIControl, ILinkListView
    {
        public LinkListControl ()
        {
            InitializeComponent ();

            var menu = new ListContextMenu ();
            menu.AddItem += (sender, arg) => Invoke (AddLink);
            menu.RemoveItem += (sender, arg) =>
            {
                if ( LinkList.SelectedItem != null )
                    Invoke (RemoveLink);
            };
            LinkList.ContextMenu = menu;
        }

        public IPresenter Presenter { get; set; }

        public object DataSource
        {
            get { return LinkList.DataSource; }
            set { LinkList.DataSource = value; }
        }

        public Link SelectedItem
        {
            get { return LinkList.SelectedItem as Link; }
        }

        public event Action AddLink;
        public event Action RemoveLink;
    }
}
