﻿namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    partial class DocumentControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.DocumentToolStrip = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.DocumentPanel = new System.Windows.Forms.Panel();
            this.ContentTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.PlaceLb = new System.Windows.Forms.Label();
            this.PlaceField = new System.Windows.Forms.TextBox();
            this.CreateDateLb = new System.Windows.Forms.Label();
            this.CreateDateField = new System.Windows.Forms.DateTimePicker();
            this.ExpDataField = new System.Windows.Forms.DateTimePicker();
            this.EndDateLb = new System.Windows.Forms.Label();
            this.SeriesField = new System.Windows.Forms.TextBox();
            this.SeriesLb = new System.Windows.Forms.Label();
            this.NumberLb = new System.Windows.Forms.Label();
            this.NumberField = new System.Windows.Forms.TextBox();
            this.NameField = new System.Windows.Forms.TextBox();
            this.NameLb = new System.Windows.Forms.Label();
            this.AppointmentLb = new System.Windows.Forms.Label();
            this.AppointmentField = new System.Windows.Forms.TextBox();
            this.FlagControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DocumentTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.AccessTypeControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.NoteLb = new System.Windows.Forms.Label();
            this.NoteField = new System.Windows.Forms.TextBox();
            this.LinkList = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.LinkListControl();
            this.label4 = new System.Windows.Forms.Label();
            this.RenewLb = new System.Windows.Forms.Label();
            this.RenewField = new System.Windows.Forms.TextBox();
            this.SubdivisionCodeLb = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.IssuerField = new System.Windows.Forms.TextBox();
            this.IssuerLb = new System.Windows.Forms.Label();
            this.ParticipantList = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.ParticipantListControl();
            this.SubdivisionCodeField = new System.Windows.Forms.TextBox();
            this.MainTableLayout.SuspendLayout();
            this.DocumentPanel.SuspendLayout();
            this.ContentTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.DocumentToolStrip, 0, 0);
            this.MainTableLayout.Controls.Add(this.DocumentPanel, 0, 1);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(600, 410);
            this.MainTableLayout.TabIndex = 0;
            // 
            // DocumentToolStrip
            // 
            this.DocumentToolStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DocumentToolStrip.Location = new System.Drawing.Point(3, 3);
            this.DocumentToolStrip.Name = "DocumentToolStrip";
            this.DocumentToolStrip.NameTitle = null;
            this.DocumentToolStrip.Size = new System.Drawing.Size(594, 22);
            this.DocumentToolStrip.TabIndex = 3;
            // 
            // DocumentPanel
            // 
            this.DocumentPanel.AutoScroll = true;
            this.DocumentPanel.Controls.Add(this.ContentTableLayout);
            this.DocumentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DocumentPanel.Location = new System.Drawing.Point(3, 31);
            this.DocumentPanel.Name = "DocumentPanel";
            this.DocumentPanel.Size = new System.Drawing.Size(594, 376);
            this.DocumentPanel.TabIndex = 4;
            // 
            // ContentTableLayout
            // 
            this.ContentTableLayout.ColumnCount = 6;
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.ContentTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.ContentTableLayout.Controls.Add(this.PlaceLb, 0, 6);
            this.ContentTableLayout.Controls.Add(this.PlaceField, 1, 6);
            this.ContentTableLayout.Controls.Add(this.CreateDateLb, 0, 5);
            this.ContentTableLayout.Controls.Add(this.CreateDateField, 1, 5);
            this.ContentTableLayout.Controls.Add(this.ExpDataField, 4, 5);
            this.ContentTableLayout.Controls.Add(this.EndDateLb, 3, 5);
            this.ContentTableLayout.Controls.Add(this.SeriesField, 1, 4);
            this.ContentTableLayout.Controls.Add(this.SeriesLb, 0, 4);
            this.ContentTableLayout.Controls.Add(this.NumberLb, 2, 4);
            this.ContentTableLayout.Controls.Add(this.NumberField, 3, 4);
            this.ContentTableLayout.Controls.Add(this.NameField, 1, 3);
            this.ContentTableLayout.Controls.Add(this.NameLb, 0, 3);
            this.ContentTableLayout.Controls.Add(this.AppointmentLb, 0, 2);
            this.ContentTableLayout.Controls.Add(this.AppointmentField, 1, 2);
            this.ContentTableLayout.Controls.Add(this.FlagControl, 4, 0);
            this.ContentTableLayout.Controls.Add(this.label1, 3, 0);
            this.ContentTableLayout.Controls.Add(this.label3, 0, 1);
            this.ContentTableLayout.Controls.Add(this.label2, 0, 0);
            this.ContentTableLayout.Controls.Add(this.DocumentTypeControl, 1, 0);
            this.ContentTableLayout.Controls.Add(this.AccessTypeControl, 1, 1);
            this.ContentTableLayout.Controls.Add(this.NoteLb, 0, 12);
            this.ContentTableLayout.Controls.Add(this.NoteField, 1, 12);
            this.ContentTableLayout.Controls.Add(this.LinkList, 4, 9);
            this.ContentTableLayout.Controls.Add(this.label4, 3, 9);
            this.ContentTableLayout.Controls.Add(this.RenewLb, 0, 8);
            this.ContentTableLayout.Controls.Add(this.RenewField, 1, 8);
            this.ContentTableLayout.Controls.Add(this.SubdivisionCodeLb, 3, 7);
            this.ContentTableLayout.Controls.Add(this.label9, 0, 7);
            this.ContentTableLayout.Controls.Add(this.IssuerField, 1, 7);
            this.ContentTableLayout.Controls.Add(this.IssuerLb, 0, 9);
            this.ContentTableLayout.Controls.Add(this.ParticipantList, 1, 9);
            this.ContentTableLayout.Controls.Add(this.SubdivisionCodeField, 4, 7);
            this.ContentTableLayout.Dock = System.Windows.Forms.DockStyle.Top;
            this.ContentTableLayout.Location = new System.Drawing.Point(0, 0);
            this.ContentTableLayout.Name = "ContentTableLayout";
            this.ContentTableLayout.RowCount = 13;
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.ContentTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.ContentTableLayout.Size = new System.Drawing.Size(594, 376);
            this.ContentTableLayout.TabIndex = 3;
            // 
            // PlaceLb
            // 
            this.PlaceLb.AutoSize = true;
            this.PlaceLb.Location = new System.Drawing.Point(3, 156);
            this.PlaceLb.Name = "PlaceLb";
            this.PlaceLb.Size = new System.Drawing.Size(96, 13);
            this.PlaceLb.TabIndex = 0;
            this.PlaceLb.Text = "Место документа";
            // 
            // PlaceField
            // 
            this.PlaceField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ContentTableLayout.SetColumnSpan(this.PlaceField, 4);
            this.PlaceField.Location = new System.Drawing.Point(123, 159);
            this.PlaceField.Name = "PlaceField";
            this.PlaceField.Size = new System.Drawing.Size(469, 20);
            this.PlaceField.TabIndex = 1;
            this.PlaceField.TextAlignChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // CreateDateLb
            // 
            this.CreateDateLb.AutoSize = true;
            this.CreateDateLb.Location = new System.Drawing.Point(3, 130);
            this.CreateDateLb.Name = "CreateDateLb";
            this.CreateDateLb.Size = new System.Drawing.Size(84, 13);
            this.CreateDateLb.TabIndex = 0;
            this.CreateDateLb.Text = "Дата создания";
            // 
            // CreateDateField
            // 
            this.ContentTableLayout.SetColumnSpan(this.CreateDateField, 2);
            this.CreateDateField.Location = new System.Drawing.Point(123, 133);
            this.CreateDateField.Name = "CreateDateField";
            this.CreateDateField.Size = new System.Drawing.Size(184, 20);
            this.CreateDateField.TabIndex = 2;
            this.CreateDateField.ValueChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // ExpDataField
            // 
            this.ExpDataField.Location = new System.Drawing.Point(448, 133);
            this.ExpDataField.Name = "ExpDataField";
            this.ExpDataField.Size = new System.Drawing.Size(144, 20);
            this.ExpDataField.TabIndex = 2;
            this.ExpDataField.ValueChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // EndDateLb
            // 
            this.EndDateLb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EndDateLb.AutoSize = true;
            this.EndDateLb.Location = new System.Drawing.Point(353, 130);
            this.EndDateLb.Name = "EndDateLb";
            this.EndDateLb.Size = new System.Drawing.Size(89, 13);
            this.EndDateLb.TabIndex = 0;
            this.EndDateLb.Text = "Дата окончания";
            // 
            // SeriesField
            // 
            this.SeriesField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SeriesField.Location = new System.Drawing.Point(123, 107);
            this.SeriesField.Name = "SeriesField";
            this.SeriesField.Size = new System.Drawing.Size(59, 20);
            this.SeriesField.TabIndex = 1;
            this.SeriesField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SeriesLb
            // 
            this.SeriesLb.AutoSize = true;
            this.SeriesLb.Location = new System.Drawing.Point(3, 104);
            this.SeriesLb.Name = "SeriesLb";
            this.SeriesLb.Size = new System.Drawing.Size(42, 13);
            this.SeriesLb.TabIndex = 0;
            this.SeriesLb.Text = "Серия*";
            // 
            // NumberLb
            // 
            this.NumberLb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.NumberLb.AutoSize = true;
            this.NumberLb.Location = new System.Drawing.Point(262, 104);
            this.NumberLb.Name = "NumberLb";
            this.NumberLb.Size = new System.Drawing.Size(45, 13);
            this.NumberLb.TabIndex = 0;
            this.NumberLb.Text = "Номер*";
            // 
            // NumberField
            // 
            this.NumberField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NumberField.Location = new System.Drawing.Point(313, 107);
            this.NumberField.Name = "NumberField";
            this.NumberField.Size = new System.Drawing.Size(129, 20);
            this.NumberField.TabIndex = 1;
            this.NumberField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NameField
            // 
            this.NameField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ContentTableLayout.SetColumnSpan(this.NameField, 4);
            this.NameField.Location = new System.Drawing.Point(123, 81);
            this.NameField.Name = "NameField";
            this.NameField.Size = new System.Drawing.Size(469, 20);
            this.NameField.TabIndex = 1;
            this.NameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NameLb
            // 
            this.NameLb.AutoSize = true;
            this.NameLb.Location = new System.Drawing.Point(3, 78);
            this.NameLb.Name = "NameLb";
            this.NameLb.Size = new System.Drawing.Size(61, 13);
            this.NameLb.TabIndex = 0;
            this.NameLb.Text = "Название*";
            // 
            // AppointmentLb
            // 
            this.AppointmentLb.AutoSize = true;
            this.AppointmentLb.Location = new System.Drawing.Point(3, 52);
            this.AppointmentLb.Name = "AppointmentLb";
            this.AppointmentLb.Size = new System.Drawing.Size(68, 13);
            this.AppointmentLb.TabIndex = 0;
            this.AppointmentLb.Text = "Назначение";
            // 
            // AppointmentField
            // 
            this.AppointmentField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ContentTableLayout.SetColumnSpan(this.AppointmentField, 4);
            this.AppointmentField.Location = new System.Drawing.Point(123, 55);
            this.AppointmentField.Name = "AppointmentField";
            this.AppointmentField.Size = new System.Drawing.Size(469, 20);
            this.AppointmentField.TabIndex = 1;
            this.AppointmentField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // FlagControl
            // 
            this.FlagControl.DataSource = null;
            this.FlagControl.DisplayProperty = "TypeName";
            this.FlagControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlagControl.Location = new System.Drawing.Point(447, 2);
            this.FlagControl.Margin = new System.Windows.Forms.Padding(2);
            this.FlagControl.Name = "FlagControl";
            this.FlagControl.NameTitle = null;
            this.FlagControl.Presenter = null;
            this.FlagControl.SelectedEntity = null;
            this.FlagControl.Size = new System.Drawing.Size(146, 22);
            this.FlagControl.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(403, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Флаг*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Доступ*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Тип документа*";
            // 
            // DocumentTypeControl
            // 
            this.ContentTableLayout.SetColumnSpan(this.DocumentTypeControl, 2);
            this.DocumentTypeControl.DataSource = null;
            this.DocumentTypeControl.DisplayProperty = "TypeName";
            this.DocumentTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DocumentTypeControl.Location = new System.Drawing.Point(122, 2);
            this.DocumentTypeControl.Margin = new System.Windows.Forms.Padding(2);
            this.DocumentTypeControl.Name = "DocumentTypeControl";
            this.DocumentTypeControl.NameTitle = null;
            this.DocumentTypeControl.Presenter = null;
            this.DocumentTypeControl.SelectedEntity = null;
            this.DocumentTypeControl.Size = new System.Drawing.Size(186, 22);
            this.DocumentTypeControl.TabIndex = 4;
            // 
            // AccessTypeControl
            // 
            this.ContentTableLayout.SetColumnSpan(this.AccessTypeControl, 2);
            this.AccessTypeControl.DataSource = null;
            this.AccessTypeControl.DisplayProperty = "TypeName";
            this.AccessTypeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccessTypeControl.Location = new System.Drawing.Point(122, 28);
            this.AccessTypeControl.Margin = new System.Windows.Forms.Padding(2);
            this.AccessTypeControl.Name = "AccessTypeControl";
            this.AccessTypeControl.NameTitle = null;
            this.AccessTypeControl.Presenter = null;
            this.AccessTypeControl.SelectedEntity = null;
            this.AccessTypeControl.Size = new System.Drawing.Size(186, 22);
            this.AccessTypeControl.TabIndex = 5;
            // 
            // NoteLb
            // 
            this.NoteLb.AutoSize = true;
            this.NoteLb.Location = new System.Drawing.Point(3, 312);
            this.NoteLb.Name = "NoteLb";
            this.NoteLb.Size = new System.Drawing.Size(51, 13);
            this.NoteLb.TabIndex = 0;
            this.NoteLb.Text = "Заметка";
            // 
            // NoteField
            // 
            this.ContentTableLayout.SetColumnSpan(this.NoteField, 4);
            this.NoteField.Location = new System.Drawing.Point(123, 315);
            this.NoteField.MaxLength = 2000;
            this.NoteField.Multiline = true;
            this.NoteField.Name = "NoteField";
            this.NoteField.Size = new System.Drawing.Size(469, 58);
            this.NoteField.TabIndex = 1;
            this.NoteField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // LinkList
            // 
            this.LinkList.DataSource = null;
            this.LinkList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LinkList.Location = new System.Drawing.Point(448, 237);
            this.LinkList.Name = "LinkList";
            this.LinkList.NameTitle = null;
            this.LinkList.Presenter = null;
            this.ContentTableLayout.SetRowSpan(this.LinkList, 3);
            this.LinkList.Size = new System.Drawing.Size(144, 72);
            this.LinkList.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ссылки";
            // 
            // RenewLb
            // 
            this.RenewLb.AutoSize = true;
            this.RenewLb.Location = new System.Drawing.Point(3, 208);
            this.RenewLb.Name = "RenewLb";
            this.RenewLb.Size = new System.Drawing.Size(108, 13);
            this.RenewLb.TabIndex = 0;
            this.RenewLb.Text = "Условия продления";
            // 
            // RenewField
            // 
            this.ContentTableLayout.SetColumnSpan(this.RenewField, 4);
            this.RenewField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RenewField.Location = new System.Drawing.Point(123, 211);
            this.RenewField.Name = "RenewField";
            this.RenewField.Size = new System.Drawing.Size(469, 20);
            this.RenewField.TabIndex = 10;
            // 
            // SubdivisionCodeLb
            // 
            this.SubdivisionCodeLb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SubdivisionCodeLb.AutoSize = true;
            this.SubdivisionCodeLb.Location = new System.Drawing.Point(335, 182);
            this.SubdivisionCodeLb.Name = "SubdivisionCodeLb";
            this.SubdivisionCodeLb.Size = new System.Drawing.Size(107, 13);
            this.SubdivisionCodeLb.TabIndex = 11;
            this.SubdivisionCodeLb.Text = "Код подразделения";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Издатель";
            // 
            // IssuerField
            // 
            this.ContentTableLayout.SetColumnSpan(this.IssuerField, 2);
            this.IssuerField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IssuerField.Location = new System.Drawing.Point(123, 185);
            this.IssuerField.Name = "IssuerField";
            this.IssuerField.Size = new System.Drawing.Size(184, 20);
            this.IssuerField.TabIndex = 1;
            this.IssuerField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // IssuerLb
            // 
            this.IssuerLb.AutoSize = true;
            this.IssuerLb.Location = new System.Drawing.Point(3, 234);
            this.IssuerLb.Name = "IssuerLb";
            this.IssuerLb.Size = new System.Drawing.Size(61, 13);
            this.IssuerLb.TabIndex = 0;
            this.IssuerLb.Text = "Участники";
            // 
            // ParticipantList
            // 
            this.ContentTableLayout.SetColumnSpan(this.ParticipantList, 2);
            this.ParticipantList.DataSource = null;
            this.ParticipantList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParticipantList.Location = new System.Drawing.Point(123, 237);
            this.ParticipantList.Margin = new System.Windows.Forms.Padding(3, 3, 0, 0);
            this.ParticipantList.Name = "ParticipantList";
            this.ParticipantList.NameTitle = null;
            this.ParticipantList.Presenter = null;
            this.ContentTableLayout.SetRowSpan(this.ParticipantList, 3);
            this.ParticipantList.Size = new System.Drawing.Size(187, 75);
            this.ParticipantList.TabIndex = 7;
            // 
            // SubdivisionCodeField
            // 
            this.SubdivisionCodeField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SubdivisionCodeField.Location = new System.Drawing.Point(448, 185);
            this.SubdivisionCodeField.Name = "SubdivisionCodeField";
            this.SubdivisionCodeField.Size = new System.Drawing.Size(144, 20);
            this.SubdivisionCodeField.TabIndex = 12;
            // 
            // DocumentControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "DocumentControl";
            this.Size = new System.Drawing.Size(600, 410);
            this.MainTableLayout.ResumeLayout(false);
            this.DocumentPanel.ResumeLayout(false);
            this.ContentTableLayout.ResumeLayout(false);
            this.ContentTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private MenuControls.EditorToolStrip DocumentToolStrip;
        private System.Windows.Forms.Panel DocumentPanel;
        private System.Windows.Forms.TableLayoutPanel ContentTableLayout;
        private System.Windows.Forms.Label NoteLb;
        private System.Windows.Forms.TextBox NoteField;
        private System.Windows.Forms.Label IssuerLb;
        private System.Windows.Forms.TextBox IssuerField;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label RenewLb;
        private System.Windows.Forms.Label PlaceLb;
        private System.Windows.Forms.TextBox PlaceField;
        private System.Windows.Forms.Label CreateDateLb;
        private System.Windows.Forms.DateTimePicker CreateDateField;
        private System.Windows.Forms.DateTimePicker ExpDataField;
        private System.Windows.Forms.Label EndDateLb;
        private System.Windows.Forms.TextBox SeriesField;
        private System.Windows.Forms.Label SeriesLb;
        private System.Windows.Forms.Label NumberLb;
        private System.Windows.Forms.TextBox NumberField;
        private System.Windows.Forms.TextBox NameField;
        private System.Windows.Forms.Label NameLb;
        private System.Windows.Forms.Label AppointmentLb;
        private System.Windows.Forms.TextBox AppointmentField;
        private ExtraControls.EditEntityBoxControl FlagControl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private ExtraControls.EditEntityBoxControl DocumentTypeControl;
        private ExtraControls.EntityBoxControl AccessTypeControl;
        private ParticipantListControl ParticipantList;
        private System.Windows.Forms.Label label4;
        private LinkListControl LinkList;
        private System.Windows.Forms.TextBox RenewField;
        private System.Windows.Forms.Label SubdivisionCodeLb;
        private System.Windows.Forms.TextBox SubdivisionCodeField;
    }
}
