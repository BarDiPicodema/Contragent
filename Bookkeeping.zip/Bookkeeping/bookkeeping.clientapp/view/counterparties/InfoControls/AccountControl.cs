﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.InfoControls
{
    public partial class AccountControl : Common.CUIControlAccess, IAccountView
    {
        public Account Account { get; set; }
        public IPresenter Presenter { get; set; }

        public AccountControl ()
            : base ()
        {
            InitializeComponent ();
            NameTitle = "Счет";

            Presenter = new AccountPresenter (this, new Model.AccessServiceModel<Data.Entities.Account> ());

            AccountTypeControl.Presenter = new EntityPresenter<AccountType> (AccountTypeControl, new Model.ServiceModel<AccountType> ());
            AccountKindControl.Presenter = new EntityPresenter<AccountKind> (AccountKindControl, new Model.ServiceModel<AccountKind>());
            FlagControl.Presenter = new EntityPresenter<Flag> (FlagControl, new Model.ServiceModel<Flag> ());
            AccessTypeControl.Presenter = new EntityPresenter<AccessType> (AccessTypeControl, new Model.ServiceModel<AccessType> ());
            AccessPresenter = AccessTypeView;

            OkvField.Presenter = new ClassificatorPresenter<Okv> (OkvField, new Model.ServiceModel<Okv> ());
        }

        public IEditorToolView ToolView
        {
            get { return AccountToolStrip as IEditorToolView; }
        }

        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        #region Properties
        public string AccountName
        {
            get { return NameField.Text; }
            set { NameField.Text = value; }
        }

        public string NumberAccount
        {
            get { return NumberAccountField.Text; }
            set { NumberAccountField.Text = value; }
        }

        public string Recipient
        {
            get { return RecipientField.Text; }
            set { RecipientField.Text = value; }
        }

        public string Bic
        {
            get { return BicField.Text; }
            set { BicField.Text = value; }
        }

        public string Iban
        {
            get { return IbanField.Text; }
            set { IbanField.Text = value; }
        }

        public string Bank
        {
            get { return BankField.Text; }
            set { BankField.Text = value; }
        }

        public string AddressBank
        {
            get { return AddressField.Text; }
            set { AddressField.Text = value; }
        }

        public string CorAccount
        {
            get { return CorAccountField.Text; }
            set { CorAccountField.Text = value; }
        }

        public string CorBank
        {
            get { return CorBankField.Text; }
            set { CorBankField.Text = value; }
        }

        public string Description
        {
            get { return DescriptionField.Text; }
            set { DescriptionField.Text = value; }
        }
        #endregion

        public Presenter.Counterparties.Extra.IEntityControlView AccountTypeView
        {
            get { return AccountTypeControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<AccountType> AccountType
        {
            get { return AccountTypeControl.Presenter as EntityPresenter<AccountType>; }
        }

        public Presenter.Counterparties.Extra.IEntityControlView AccountKindView
        {
            get { return AccountKindControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<AccountKind> AccountKind
        {
            get { return AccountKindControl.Presenter as EntityPresenter<AccountKind>; }
        }


        public Presenter.Counterparties.Extra.IEntityControlView AccessTypeView
        {
            get { return AccessTypeControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<AccessType> AccessType
        {
            get { return AccessTypeControl.Presenter as EntityPresenter<AccessType>; }
        }

        public Presenter.Counterparties.Extra.IEntityControlView FlagView
        {
            get { return FlagControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<Flag> Flag
        {
            get { return FlagControl.Presenter as EntityPresenter<Flag>; }
        }

        #region Classificator properties
        public IClassificatorView OkvView
        {
            get { return OkvField; }
        }

        public ClassificatorPresenter<Okv> OkvPresenter
        {
            get { return OkvField.Presenter as ClassificatorPresenter<Okv>; }
        }
        #endregion


        public event Action InfoChange;
    }
}
