﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class ContractorGroupTypeTreeControl : Common.CUIControl, IContractorGroupTypeTreeView
    {
        public ContractorGroupTypeTreeControl ()
        {
            InitializeComponent ();

            var menu = new ContextMenu ();
            MenuItem remove = new MenuItem ("Удалить");
            remove.Click += (sender, args) => Invoke (RemoveGroupType);
            menu.MenuItems.Add (remove);
            Tree.ContextMenu = menu;

            Tree.AfterSelect += (sender, args) =>
            {
                if ( Tree.SelectedNode == null )
                    SetSelectedNode (Tree.TopNode);
                else SetSelectedNode (Tree.SelectedNode);
            };

            Presenter = new ContractorGroupTypeTreePresenter (this, new Model.ServiceModel<Data.Entities.Group>(), new Model.ServiceModel<Data.Entities.GroupTypeToType> ());
        }

        public object CheckedItem
        {
            get { return Tree.SelectedNode; }
        }

        public TreeNodeCollection Nodes
        {
            get { return Tree.Nodes; }
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public event Action CheckedTreeItem;
        public event Action RemoveGroupType;

        private TreeNode GetSelectedNode (TreeNode node)
        {
            TreeNode temp = node;
            if ( node.Nodes.Count != 0 )
                temp = GetSelectedNode (node);
            return temp;
        }

        private void SetSelectedNode (TreeNode node)
        {
            if ( node.Nodes.Count != 0 )
                SetSelectedNode (node.Nodes[0]);
            else Tree.SelectedNode = node;
        }

        public event Action AddGroupType;
    }
}
