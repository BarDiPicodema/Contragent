﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class ClassificatorBox : Common.CUIControl, IClassificatorView
    {
        public ClassificatorBox ()
        {
            InitializeComponent ();

            ClassificatorCodeField.DoubleClick += (sender, args) => Invoke (OpenClassificator);
        }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public object Classificator { get; set; }

        public string ClassificatorCode
        {
            get { return ClassificatorCodeField.Text; }
            set { ClassificatorCodeField.Text = value; }
        }

        public event Action OpenClassificator;
        
    }
}
