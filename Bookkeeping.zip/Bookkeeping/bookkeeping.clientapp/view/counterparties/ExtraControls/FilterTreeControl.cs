﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data.Interface;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Common;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class FilterTreeControl : Common.CUIControl, IFilterView
    {
        public FilterTreeControl ()
        {
            InitializeComponent ();

            _checkedProcess = false;
            Tree.AfterCheck += Tree_AfterCheck;

            Presenter = new FilterPresenter (this, new FilterModel ());
        }

        private bool _checkedProcess;

        public IPresenter Presenter { get; set; }

        public object CheckedItem { get; private set; }

        private List<AbstractFilter<Partner>> _partnerFilter;
        public List<AbstractFilter<Partner>> SelectedPartnerFilter
        {
            get
            {
                GetSelectedFilter ("Партнеры");
                return _partnerFilter;
            } 
        }

        private List<AbstractFilter<Individual>> _individualFilter;
        public List<AbstractFilter<Individual>> SelectedIndividualFilter 
        {
            get
            {
                GetSelectedFilter ("Физлица");
                return _individualFilter;
            }
        }

        private List<AbstractFilter<Entrepreneur>> _entrepreneurFilter;
        public List<AbstractFilter<Entrepreneur>> SelectedEntrepreneurFilter 
        {
            get
            {
                GetSelectedFilter ("Юрлица");
                return _entrepreneurFilter;
            }
        }

        public TreeNodeCollection Nodes
        {
            get { return Tree.Nodes; }
        }


        public event Action CheckedTreeItem;

        private void Tree_AfterCheck (object sender, TreeViewEventArgs arg)
        {
            if ( _checkedProcess == false )
            {
                _checkedProcess = true;
                CheckParent (arg.Node, arg.Node.Checked);
                CheckNodes (arg.Node, arg.Node.Checked);
                Invoke (CheckedTreeItem);
            }
        }

        private void CheckNodes (TreeNode node, bool check)
        {
            if ( node.Nodes.Count == 0 )
            {
                node.Checked = check;
                _checkedProcess = false;
                return;
            }
            foreach ( TreeNode item in node.Nodes )
            {
                CheckNodes (item, check);
                item.Checked = check;
            }
        }

        private void CheckParent (TreeNode node, bool check)
        {
            node.Checked = check;
            if ( node.Parent != null )
            {
                foreach ( TreeNode item in node.Parent.Nodes )
                    if ( item.Checked == true )
                        check = true;
                CheckParent (node.Parent, check);
            }
            else return;
        }

        private void GetSelectedFilter (string name)
        {
            _partnerFilter = new List<AbstractFilter<Partner>> ();
            _individualFilter = new List<AbstractFilter<Individual>> ();
            _entrepreneurFilter = new List<AbstractFilter<Entrepreneur>> ();

            foreach ( TreeNode parent in Tree.Nodes )
            {
                if ( parent.Text == "Общие" || parent.Text == name && parent.Checked == true )
                {
                    foreach ( FilterNode node in parent.Nodes )
                    {
                        if ( node.Checked == true )
                        {
                            if ( name == "Партнеры" && parent.Text == name)
                                _partnerFilter.Add (node.PartnerFilter);
                            else if ( name == "Физлица" && parent.Text == name )
                                _individualFilter.Add (node.IndividualFilter);
                            else if ( name == "Юрлица" && parent.Text == name )
                                _entrepreneurFilter.Add (node.EntrepreneurFilter);
                            else
                            {
                                _partnerFilter.Add (node.PartnerFilter);
                                _individualFilter.Add (node.IndividualFilter);
                                _entrepreneurFilter.Add (node.EntrepreneurFilter);
                            }
                        }
                    }
                }
            }
        }

    }

    public class FilterNode : TreeNode
    {
        public FilterNode (AbstractFilter<Partner> partner)
        {
            _partnerFilter = partner;
            Text = partner.Name;

            foreach ( var value in partner.Values )
                Nodes.Add (new FilterNode (value));
        }

        public FilterNode (AbstractFilter<Individual> individual)
        {
            _individualFilter = individual;
            Text = individual.Name;

            foreach ( var value in individual.Values )
                Nodes.Add (new FilterNode (value));
        }

        public FilterNode (AbstractFilter<Entrepreneur> entrepreneur)
        {
            _entrepreneurFilter = entrepreneur;
            Text = entrepreneur.Name;

            foreach ( var value in entrepreneur.Values )
                Nodes.Add (new FilterNode (value));
        }

        public FilterNode (AbstractFilter<Partner> partner, AbstractFilter<Individual> individual, AbstractFilter<Entrepreneur> entrepreneur)
        {
            _partnerFilter = partner;
            _individualFilter = individual;
            _entrepreneurFilter = entrepreneur;

            Text = partner.Name;

            foreach ( var value in partner.Values )
                Nodes.Add (new FilterNode (value));
        }

        public FilterNode (AbstractFilterValue value)
        {
            Value = value;
            Text = value.Name;
        }

        private AbstractFilter<Partner> _partnerFilter;
        public AbstractFilter<Partner> PartnerFilter
        {
            get
            {
                _partnerFilter.SetValue (GetCheckedValue (this.Nodes).ToArray ());
                return _partnerFilter;
            }
        }

        private AbstractFilter<Individual> _individualFilter;
        public AbstractFilter<Individual> IndividualFilter 
        { 
            get
            {
                _individualFilter.SetValue (GetCheckedValue (this.Nodes).ToArray ());
                return _individualFilter;
            }
        }

        private AbstractFilter<Entrepreneur> _entrepreneurFilter;
        public AbstractFilter<Entrepreneur> EntrepreneurFilter 
        { 
            get
            {
                _entrepreneurFilter.SetValue (GetCheckedValue (this.Nodes).ToArray ());
                return _entrepreneurFilter;
            }
        }

        public AbstractFilterValue Value { get; private set; }

        private IList<AbstractFilterValue> GetCheckedValue (TreeNodeCollection collection)
        {
            IList<AbstractFilterValue> values = new List<AbstractFilterValue> ();
            foreach ( FilterNode item in collection )
                if ( item.Checked == true )
                    values.Add (item.Value);
            return values;
        }
    }
}
