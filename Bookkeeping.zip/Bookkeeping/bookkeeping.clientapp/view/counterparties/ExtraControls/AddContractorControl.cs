﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Model.Counterparties;
using Bookkeeping.ClientApp.Presenter.Common;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class AddContractorControl : Common.CUIControl, IAddContractorView
    {
        public AddContractorControl () 
            : base()
        {
            InitializeComponent ();
            this.NameTitle = "Выберите тип контрагента";

            Contractors = new List<string> ();

            Presenter = new AddContractorPresenter (this);

            CreateContractor.Click += (sender, args) => Invoke (Create);
            CreateContractor.Click += (sender, args) => Invoke (Close);
        }

        public IPresenter Presenter { get; set; }

        public event Action Create;

        public event Action Close;

        public List<string> Contractors
        {
            get { return ContractorBox.DataSource as List<string>; }
            set { ContractorBox.DataSource = value; }
        }

        public string SelectedContractor
        {
            get { return ContractorBox.Text; }
        }

        public new Form Parent
        {
            get { return this.ParentForm; }
        }
    }
}
