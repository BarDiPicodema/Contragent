﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class EditEntityBoxControl : Common.CUIControl, IEntityControlView
    {
        public EditEntityBoxControl ()
        {
            InitializeComponent ();

            AddEntityButton.Click += (sender, args) => Invoke (AddEntity);

            var editEntity = new MenuItem ("Редактировать");
            editEntity.Click += (sender, args) => Invoke (EditEntity);
            EntityComboBox.ContextMenu = new System.Windows.Forms.ContextMenu (new MenuItem[] { editEntity });

            EntityComboBox.SelectedIndexChanged += (sender, args) =>
                {
                    if ( SelectedEntityChanged != null )
                        SelectedEntityChanged (this, args);
                };
        }

        public Presenter.Common.IPresenter Presenter
        {
            get;
            set;
        }

        public object DataSource
        {
            get { return EntityComboBox.DataSource; }
            set { EntityComboBox.DataSource = value; }
        }

        public string DisplayProperty
        {
            get { return EntityComboBox.DisplayMember; }
            set 
            { 
                EntityComboBox.DisplayMember = value;
            }
        }

        public object SelectedEntity
        {
            get { return EntityComboBox.SelectedValue; }
            set
            {
                if ( value != null )
                {
                    for ( int i = 0; i < EntityComboBox.Items.Count; i ++ )
                        if ((EntityComboBox.Items[i] as Data.IEntity).Id == (value as Data.IEntity).Id)
                            EntityComboBox.SelectedIndex = i;
                }
            }
        }

        public event EventHandler SelectedEntityChanged;

        public event Action AddEntity;

        public event Action EditEntity;
    }
}
