﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class EntityBoxControl : Common.CUIControl, IEntityControlView
    {
        public EntityBoxControl ()
        {
            InitializeComponent ();

            EntityComboBox.SelectedIndexChanged += (sender, args) =>
                {
                    if ( SelectedEntityChanged != null )
                        SelectedEntityChanged (this, args);
                };
        }

        public IPresenter Presenter { get; set; }

        public object DataSource
        {
            get { return EntityComboBox.DataSource; }
            set { EntityComboBox.DataSource = value; }
        }

        public string DisplayProperty
        {
            get { return EntityComboBox.DisplayMember; }
            set 
            { 
                EntityComboBox.DisplayMember = value;
                EntityComboBox.ValueMember = value;
            }
        }

        public object SelectedEntity 
        {
            get { return EntityComboBox.SelectedItem; }
            set 
            { 
                if (null != value)
                {
                    for ( int i = 0; i < EntityComboBox.Items.Count; i++ )
                        if ( ( EntityComboBox.Items[i] as Data.IEntity ).Id == ( value as Data.IEntity ).Id )
                            EntityComboBox.SelectedIndex = i;
                }
            }
        }

        public event EventHandler SelectedEntityChanged;

        public event Action AddEntity;

        public event Action EditEntity;
    }
}
