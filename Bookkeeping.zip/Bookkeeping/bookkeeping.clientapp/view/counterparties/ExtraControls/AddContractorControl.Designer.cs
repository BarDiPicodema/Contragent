﻿namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    partial class AddContractorControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.CreateContractor = new System.Windows.Forms.Button();
            this.ContractorBox = new System.Windows.Forms.ComboBox();
            this.MainTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 2;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayout.Controls.Add(this.CreateContractor, 1, 1);
            this.MainTableLayout.Controls.Add(this.ContractorBox, 0, 0);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 2;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.Size = new System.Drawing.Size(250, 60);
            this.MainTableLayout.TabIndex = 0;
            // 
            // CreateContractor
            // 
            this.CreateContractor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CreateContractor.Location = new System.Drawing.Point(172, 37);
            this.CreateContractor.Name = "CreateContractor";
            this.CreateContractor.Size = new System.Drawing.Size(75, 20);
            this.CreateContractor.TabIndex = 0;
            this.CreateContractor.Text = "Создать";
            this.CreateContractor.UseVisualStyleBackColor = true;
            // 
            // ContractorBox
            // 
            this.ContractorBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.ContractorBox, 2);
            this.ContractorBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ContractorBox.FormattingEnabled = true;
            this.ContractorBox.Location = new System.Drawing.Point(3, 3);
            this.ContractorBox.Name = "ContractorBox";
            this.ContractorBox.Size = new System.Drawing.Size(244, 21);
            this.ContractorBox.TabIndex = 1;
            // 
            // AddContractorControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.MinimumSize = new System.Drawing.Size(250, 60);
            this.Name = "AddContractorControl";
            this.Size = new System.Drawing.Size(250, 60);
            this.MainTableLayout.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.Button CreateContractor;
        private System.Windows.Forms.ComboBox ContractorBox;
    }
}
