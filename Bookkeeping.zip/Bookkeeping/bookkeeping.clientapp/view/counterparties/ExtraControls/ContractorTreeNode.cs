﻿using Bookkeeping.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public class ContractorTreeNode<TEntity> : TreeNode
        where TEntity : class, ICounterparties
    {
        private TEntity _entity;

        public TEntity Entity
        {
            get { return _entity; }
            set
            {
                _entity = value;
                Text = _entity.Alias;
            }
        }
    }
}
