﻿namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    partial class TypeCreatorControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.TypeNameLb = new System.Windows.Forms.Label();
            this.NameField = new System.Windows.Forms.TextBox();
            this.TypeToolStrip = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.MainLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainLayoutPanel
            // 
            this.MainLayoutPanel.ColumnCount = 2;
            this.MainLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.MainLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainLayoutPanel.Controls.Add(this.TypeNameLb, 0, 1);
            this.MainLayoutPanel.Controls.Add(this.NameField, 1, 1);
            this.MainLayoutPanel.Controls.Add(this.TypeToolStrip, 0, 0);
            this.MainLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainLayoutPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.MainLayoutPanel.Name = "MainLayoutPanel";
            this.MainLayoutPanel.RowCount = 2;
            this.MainLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.MainLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainLayoutPanel.Size = new System.Drawing.Size(300, 65);
            this.MainLayoutPanel.TabIndex = 0;
            // 
            // TypeNameLb
            // 
            this.TypeNameLb.AutoSize = true;
            this.TypeNameLb.Location = new System.Drawing.Point(3, 28);
            this.TypeNameLb.Name = "TypeNameLb";
            this.TypeNameLb.Size = new System.Drawing.Size(64, 15);
            this.TypeNameLb.TabIndex = 1;
            this.TypeNameLb.Text = "Название";
            // 
            // NameField
            // 
            this.NameField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NameField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameField.Location = new System.Drawing.Point(83, 31);
            this.NameField.Name = "NameField";
            this.NameField.Size = new System.Drawing.Size(214, 22);
            this.NameField.TabIndex = 0;
            this.NameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // TypeToolStrip
            // 
            this.MainLayoutPanel.SetColumnSpan(this.TypeToolStrip, 2);
            this.TypeToolStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeToolStrip.Location = new System.Drawing.Point(0, 0);
            this.TypeToolStrip.Margin = new System.Windows.Forms.Padding(0);
            this.TypeToolStrip.Name = "TypeToolStrip";
            this.TypeToolStrip.NameTitle = null;
            this.TypeToolStrip.Size = new System.Drawing.Size(300, 28);
            this.TypeToolStrip.TabIndex = 2;
            // 
            // TypeCreatorControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainLayoutPanel);
            this.MinimumSize = new System.Drawing.Size(300, 65);
            this.Name = "TypeCreatorControl";
            this.Size = new System.Drawing.Size(300, 65);
            this.MainLayoutPanel.ResumeLayout(false);
            this.MainLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainLayoutPanel;
        private System.Windows.Forms.TextBox NameField;
        private System.Windows.Forms.Label TypeNameLb;
        private MenuControls.EditorToolStrip TypeToolStrip;
    }
}
