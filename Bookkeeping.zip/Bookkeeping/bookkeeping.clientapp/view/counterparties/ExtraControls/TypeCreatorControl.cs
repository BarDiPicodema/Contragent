﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data;
using Bookkeeping.Data.Interface;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Common;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class TypeCreatorControl : Common.CUIControl, ITypeView
    {
        public TypeCreatorControl ()
        {
            InitializeComponent ();

            TypeToolStrip.SaveData += () => Invoke (SaveData);
            TypeToolStrip.DeleteData += () => Invoke (DeleteData);
        }

        public IPresenter Presenter { get; set; }

        public event Action SaveData;

        public event Action DeleteData;

        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        public object TypeEntity
        {
            get;
            set;
        }

        public string TypeName
        {
            get { return NameField.Text; }
            set { NameField.Text = value; }
        }
    }
}
