﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Model.DatabaseReflection;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Model.Counterparties.FilterLogic.QueryGenerator;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class SearchTreeControl : Common.CUIControl, ISearchTreeView
    {
        public SearchTreeControl ()
        {
            InitializeComponent ();

            _checkedProcess = false;
            Presenter = new SearchTreePresenter (this, new SearchReflectionService ());

            Tree.AfterCheck += Tree_AfterCheck;
        }

        private bool _checkedProcess;

        public QueryManager PartnerQuery { get; set; }
        public QueryManager EntrepreneurQuery { get; set; }
        public QueryManager IndividualQuery { get; set; }

        public Presenter.Common.IPresenter Presenter { get; set; }

        public object CheckedItem
        {
            get;
            private set;
        }

        public TreeNodeCollection Nodes
        {
            get { return Tree.Nodes; }
        }

        public event Action CheckedTreeItem;

        private void Tree_AfterCheck (object sender, TreeViewEventArgs arg)
        {
            if ( _checkedProcess == false )
            {
                _checkedProcess = true;
                CheckParent (arg.Node, arg.Node.Checked);
                CheckNodes (arg.Node, arg.Node.Checked);
                Invoke (CheckedTreeItem);
            }
        }

        private void CheckNodes (TreeNode node, bool check)
        {
            if ( node.Nodes.Count == 0 )
            {
                node.Checked = check;
                _checkedProcess = false;
                return;
            }
            foreach ( TreeNode item in node.Nodes )
            {
                CheckNodes (item, check);
                item.Checked = check;
            }
        }

        private void CheckParent (TreeNode node, bool check)
        {
            node.Checked = check;
            if ( node.Parent != null )
            {
                foreach ( TreeNode item in node.Parent.Nodes )
                    if ( item.Checked == true )
                        check = true;
                CheckParent (node.Parent, check);
            }
            else return;
        }
    }

    public class SearchNode : TreeNode
    {
        public QueryNodeString Query { get; set; }

        private ElementNode _element;
        public ElementNode Element
        {
            get { return _element; }
            set
            {
                _element = value;
                if ( _element != null )
                {
                    this.Text = _element.ReadebleAssociationName;
                }
            }
        }

        public SearchNode (QueryNodeString query)
        {
            Query = query;
        }

        public SearchNode (ElementNode element)
        {
            Element = element;
        }

        public SearchNode (ElementNode partner, ElementNode individual, ElementNode entrepreneur)
        {
            _elementPartner = partner;
            _elementIndividual = individual;
            _elementEntrepreneur = entrepreneur;
        }

        private ElementNode _elementPartner;
        public ElementNode ElementPartner
        {
            get { return _elementPartner; }
            set
            {
                _elementPartner = value;
                if ( _elementPartner != null )
                {
                    this.Text = _elementPartner.ReadebleAssociationName;
                }
            }
        }

        private ElementNode _elementIndividual;
        public ElementNode ElementIndividual
        {
            get { return _elementIndividual; }
            set
            {
                _elementIndividual = value;
                if ( _elementIndividual != null )
                {
                    this.Text = _elementIndividual.ReadebleAssociationName;
                }
            }
        }

        private ElementNode _elementEntrepreneur;
        public ElementNode ElementEntrepreneur
        {
            get { return _elementEntrepreneur; }
            set
            {
                _elementEntrepreneur = value;
                if ( _elementEntrepreneur != null )
                {
                    this.Text = _elementEntrepreneur.ReadebleAssociationName;
                }
            }
        }
    }
}
