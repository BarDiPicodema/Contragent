﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Common;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    public partial class EntityListControl : Common.CUIControl, IEntityListView
    {
        public EntityListControl ()
        {
            InitializeComponent ();

            EntityList.DoubleClick += (sender, args) => Invoke (AddEntity);
            EntityList.KeyDown += (sender, args) =>
                {
                    if ( SelectedEntity != null && args.KeyCode == Keys.Delete )
                        Invoke (RemoveEntity);
                };
        }

        public IPresenter Presenter { get; set; }

        public object SelectedEntity
        {
            get { return EntityList.SelectedItem; }
        }

        public object DataSource
        {
            get { return EntityList.DataSource; }
            set { EntityList.DataSource = value; }
        }

        public string DisplayProperty
        {
            get { return EntityList.DisplayMember; }
            set { EntityList.DisplayMember = value; }
        }

        public event Action AddEntity;
        public event Action RemoveEntity;
    }
}
