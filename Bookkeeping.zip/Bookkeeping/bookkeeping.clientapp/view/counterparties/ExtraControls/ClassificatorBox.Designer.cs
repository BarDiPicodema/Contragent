﻿namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    partial class ClassificatorBox
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.ClassificatorCodeField = new System.Windows.Forms.TextBox();
            this.MainTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 1;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Controls.Add(this.ClassificatorCodeField, 0, 0);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Margin = new System.Windows.Forms.Padding(0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 1;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.MainTableLayout.Size = new System.Drawing.Size(150, 21);
            this.MainTableLayout.TabIndex = 0;
            // 
            // ClassificatorCodeField
            // 
            this.ClassificatorCodeField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ClassificatorCodeField.Location = new System.Drawing.Point(0, 0);
            this.ClassificatorCodeField.Margin = new System.Windows.Forms.Padding(0);
            this.ClassificatorCodeField.Name = "ClassificatorCodeField";
            this.ClassificatorCodeField.ReadOnly = true;
            this.ClassificatorCodeField.Size = new System.Drawing.Size(150, 20);
            this.ClassificatorCodeField.TabIndex = 1;
            // 
            // ClassificatorBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "ClassificatorBox";
            this.Size = new System.Drawing.Size(150, 21);
            this.MainTableLayout.ResumeLayout(false);
            this.MainTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.TextBox ClassificatorCodeField;

    }
}
