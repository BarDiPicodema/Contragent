﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.Data.Entities;
using Bookkeeping.Data;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Common;

namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    // TODO: FontStyle
    public partial class ExtraTypeEditControl : Common.CUIControl, IExtraTypeView
    {
        public ExtraTypeEditControl ()
        {
            InitializeComponent ();

            ExtraTypeToolSplit.SaveData += () => Invoke (SaveData);
            ExtraTypeToolSplit.DeleteData += () => Invoke (DeleteData);
            SelectImage.Click += (sender, args) => Invoke (GetImage);
            SelectColor.Click += (sender, args) => Invoke (GetColor);
        }

        public IPresenter Presenter { get; set; }

        public event Action SaveData;

        public event Action DeleteData;

        public event Action GetImage;

        public event Action GetColor;

        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        public object ExtraType
        {
            get;
            set;
        }

        public string TypeName
        {
            get { return NameField.Text; }
            set { NameField.Text = value; }
        }

        public string ExtraTypeName
        {
            get { return TypeNameField.Text; }
            set { TypeNameField.Text = value; }
        }

        public Color TypeColor
        {
            get { return ColorPanel.BackColor; }
            set { ColorPanel.BackColor = value; }
        }

        public Image TypeImage
        {
            get { return ImageField.Image; }
            set { ImageField.Image = value; }
        }

        public FontStyle FontStyleType
        {
            get;
            set;
        }
    }
}
