﻿namespace Bookkeeping.ClientApp.View.Counterparties.ExtraControls
{
    partial class ExtraTypeEditControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.NameField = new System.Windows.Forms.TextBox();
            this.FontStyleList = new System.Windows.Forms.ComboBox();
            this.TypeNameField = new System.Windows.Forms.TextBox();
            this.ExtraTypeToolSplit = new Bookkeeping.ClientApp.View.Counterparties.MenuControls.EditorToolStrip();
            this.NameLb = new System.Windows.Forms.Label();
            this.TypeNameLb = new System.Windows.Forms.Label();
            this.FontLb = new System.Windows.Forms.Label();
            this.ColorLb = new System.Windows.Forms.Label();
            this.ExampleText = new System.Windows.Forms.Label();
            this.ImageField = new System.Windows.Forms.PictureBox();
            this.SelectImage = new System.Windows.Forms.Button();
            this.SelectColor = new System.Windows.Forms.Button();
            this.ColorPanel = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageField)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.NameField, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.FontStyleList, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.TypeNameField, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.ExtraTypeToolSplit, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.NameLb, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.TypeNameLb, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.FontLb, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.ColorLb, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.ExampleText, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.ImageField, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.SelectImage, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.SelectColor, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.ColorPanel, 2, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(440, 160);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // NameField
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.NameField, 2);
            this.NameField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NameField.Location = new System.Drawing.Point(83, 29);
            this.NameField.Name = "NameField";
            this.NameField.Size = new System.Drawing.Size(214, 20);
            this.NameField.TabIndex = 1;
            this.NameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // FontStyleList
            // 
            this.FontStyleList.DisplayMember = "Name";
            this.FontStyleList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FontStyleList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FontStyleList.FormattingEnabled = true;
            this.FontStyleList.Location = new System.Drawing.Point(83, 107);
            this.FontStyleList.Name = "FontStyleList";
            this.FontStyleList.Size = new System.Drawing.Size(134, 21);
            this.FontStyleList.TabIndex = 1;
            this.FontStyleList.ValueMember = "Name";
            this.FontStyleList.SelectedIndexChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // TypeNameField
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.TypeNameField, 2);
            this.TypeNameField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeNameField.Location = new System.Drawing.Point(83, 55);
            this.TypeNameField.Name = "TypeNameField";
            this.TypeNameField.Size = new System.Drawing.Size(214, 20);
            this.TypeNameField.TabIndex = 1;
            this.TypeNameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // ExtraTypeToolSplit
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.ExtraTypeToolSplit, 4);
            this.ExtraTypeToolSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ExtraTypeToolSplit.Location = new System.Drawing.Point(0, 0);
            this.ExtraTypeToolSplit.Margin = new System.Windows.Forms.Padding(0);
            this.ExtraTypeToolSplit.Name = "ExtraTypeToolSplit";
            this.ExtraTypeToolSplit.NameTitle = null;
            this.ExtraTypeToolSplit.Size = new System.Drawing.Size(440, 26);
            this.ExtraTypeToolSplit.TabIndex = 5;
            // 
            // NameLb
            // 
            this.NameLb.AutoSize = true;
            this.NameLb.Location = new System.Drawing.Point(3, 26);
            this.NameLb.Name = "NameLb";
            this.NameLb.Size = new System.Drawing.Size(29, 13);
            this.NameLb.TabIndex = 6;
            this.NameLb.Text = "Имя";
            // 
            // TypeNameLb
            // 
            this.TypeNameLb.AutoSize = true;
            this.TypeNameLb.Location = new System.Drawing.Point(3, 52);
            this.TypeNameLb.Name = "TypeNameLb";
            this.TypeNameLb.Size = new System.Drawing.Size(57, 13);
            this.TypeNameLb.TabIndex = 6;
            this.TypeNameLb.Text = "Название";
            // 
            // FontLb
            // 
            this.FontLb.AutoSize = true;
            this.FontLb.Location = new System.Drawing.Point(3, 104);
            this.FontLb.Name = "FontLb";
            this.FontLb.Size = new System.Drawing.Size(41, 13);
            this.FontLb.TabIndex = 6;
            this.FontLb.Text = "Шрифт";
            // 
            // ColorLb
            // 
            this.ColorLb.AutoSize = true;
            this.ColorLb.Location = new System.Drawing.Point(3, 78);
            this.ColorLb.Name = "ColorLb";
            this.ColorLb.Size = new System.Drawing.Size(32, 13);
            this.ColorLb.TabIndex = 6;
            this.ColorLb.Text = "Цвет";
            // 
            // ExampleText
            // 
            this.ExampleText.AutoSize = true;
            this.ExampleText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ExampleText.Location = new System.Drawing.Point(223, 104);
            this.ExampleText.Name = "ExampleText";
            this.ExampleText.Size = new System.Drawing.Size(74, 26);
            this.ExampleText.TabIndex = 7;
            this.ExampleText.Text = "Аа Бб Вв Гг";
            // 
            // ImageField
            // 
            this.ImageField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ImageField.Location = new System.Drawing.Point(303, 29);
            this.ImageField.Name = "ImageField";
            this.tableLayoutPanel1.SetRowSpan(this.ImageField, 4);
            this.ImageField.Size = new System.Drawing.Size(134, 98);
            this.ImageField.TabIndex = 8;
            this.ImageField.TabStop = false;
            // 
            // SelectImage
            // 
            this.SelectImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SelectImage.Location = new System.Drawing.Point(303, 133);
            this.SelectImage.Name = "SelectImage";
            this.SelectImage.Size = new System.Drawing.Size(134, 24);
            this.SelectImage.TabIndex = 1;
            this.SelectImage.Text = "Выбрать";
            this.SelectImage.UseVisualStyleBackColor = true;
            // 
            // SelectColor
            // 
            this.SelectColor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SelectColor.Location = new System.Drawing.Point(83, 81);
            this.SelectColor.Name = "SelectColor";
            this.SelectColor.Size = new System.Drawing.Size(134, 20);
            this.SelectColor.TabIndex = 1;
            this.SelectColor.Text = "Выбрать цвет";
            this.SelectColor.UseVisualStyleBackColor = true;
            // 
            // ColorPanel
            // 
            this.ColorPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ColorPanel.Location = new System.Drawing.Point(236, 81);
            this.ColorPanel.Name = "ColorPanel";
            this.ColorPanel.Size = new System.Drawing.Size(47, 20);
            this.ColorPanel.TabIndex = 2;
            // 
            // ExtraTypeEditControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ExtraTypeEditControl";
            this.Size = new System.Drawing.Size(440, 160);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageField)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel ColorPanel;
        private MenuControls.EditorToolStrip ExtraTypeToolSplit;
        private System.Windows.Forms.TextBox NameField;
        private System.Windows.Forms.ComboBox FontStyleList;
        private System.Windows.Forms.TextBox TypeNameField;
        private System.Windows.Forms.Label NameLb;
        private System.Windows.Forms.Label TypeNameLb;
        private System.Windows.Forms.Label FontLb;
        private System.Windows.Forms.Label ColorLb;
        private System.Windows.Forms.Button SelectImage;
        private System.Windows.Forms.Button SelectColor;
        private System.Windows.Forms.Label ExampleText;
        private System.Windows.Forms.PictureBox ImageField;
    }
}
