﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.Model.Counterparties;

namespace Bookkeeping.ClientApp.View.Counterparties
{
    public partial class ContractorsWindow : Form, IContractorView
    {
        public ContractorsWindow ()
        {
            InitializeComponent ();
        }

        public ITemplateGridView<Partner> PartnerGridView
        {
            get { return PartnerTable as ITemplateGridView<Partner>; }
        }

        public ITemplateGridView<Model.Counterparties.Contractor> ContractorGridView
        {
            get { return ContractorTable as ITemplateGridView<Contractor>; }
        }

        public IContractorMenuView MenuView
        {
            get { return MenuSplit as IContractorMenuView; }
        }

        public ContractorMenuPresenter MenuPresenter
        {
            get { return MenuSplit.Presenter as ContractorMenuPresenter; }
        }

        public PartnerGridPresenter PartnerGridPresenter
        {
            get { return PartnerTable.Presenter as PartnerGridPresenter; }
        }

        public ContractorGridPresenter ContractorGridPresenter
        {
            get { return ContractorTable.Presenter as ContractorGridPresenter; }
        }

        public IFilterView FilterView
        {
            get { return FilterTree; }
        }

        public FilterPresenter FilterPresenter
        {
            get { return FilterTree.Presenter as FilterPresenter ; }
        }

        public IInfoView InfoView
        {
            get { return Info as IInfoView; }
        }

        public InfoPresenter InfoPresenter
        {
            get { return Info.Presenter as InfoPresenter; }
        }
    }
}
