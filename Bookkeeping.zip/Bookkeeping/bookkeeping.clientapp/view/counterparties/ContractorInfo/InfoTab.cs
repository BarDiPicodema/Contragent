﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.ClientApp.View.Counterparties.ContractorInfo
{
    public partial class InfoTab : UserControl, IInfoView
    {
        public InfoTab ()
        {
            InitializeComponent ();
            Presenter = new InfoPresenter (this);
        }

        public AccountGridPresenter AccountGridPresenter
        {
            get { return AccountTable.Presenter as AccountGridPresenter; }
        }

        public AddressGridPresenter AddressGridPresenter
        {
            get { return AddressTable.Presenter as AddressGridPresenter; }
        }

        public ContactGridPresenter ContactGridPresenter
        {
            get { return ContactTable.Presenter as ContactGridPresenter; }
        }

        public DocumentGridPresenter DocumentGridPresenter
        {
            get { return DocumentTable.Presenter as DocumentGridPresenter; }
        }

        public IPresenter Presenter { get; set; }
    }
}
