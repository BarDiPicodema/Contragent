﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;

namespace Bookkeeping.ClientApp.View.Counterparties.ContactorInfo
{
    public partial class EntrepreneurControl : Common.CUIControlAccess, IEntrepreneurView
    {
        public EntrepreneurControl ()
            : base ()
        {
            InitializeComponent ();

            Presenter = new EntrepreneurPresenter (this, new Model.AccessServiceModel<Entrepreneur> ());

            PartnerControl.Presenter = new EntityPresenter<Partner> (PartnerControl, new Model.AccessServiceModel<Partner> ());
            FlagControl.Presenter = new EntityPresenter<Flag> (FlagControl, new Model.ServiceModel<Flag> ());
            SigningControl.Presenter = new EntityPresenter<Signing> (SigningControl, new Model.ServiceModel<Signing> ());
            AccessControl.Presenter = new EntityPresenter<AccessType> (AccessControl, new Model.ServiceModel<AccessType> ());

            OkopfField.Presenter = new ClassificatorPresenter<Okopf> (OkopfField, new Model.ServiceModel<Okopf> ());
            OkfsField.Presenter = new ClassificatorPresenter<Okfs> (OkfsField, new Model.ServiceModel<Okfs> ());
            OkoguField.Presenter = new ClassificatorPresenter<Okogu> (OkoguField, new Model.ServiceModel<Okogu> ());
        }

        public IPresenter Presenter
        {
            get;
            set;
        }

        public Entrepreneur Entrepreneur
        {
            get;
            set;
        }

        #region Property
        public string Alias
        {
            get { return AliasField.Text; }
            set { AliasField.Text = value; }
        }

        public string Brief
        {
            get { return BriefField.Text; }
            set { BriefField.Text = value; }
        }

        public string Foreign
        {
            get { return ForeignField.Text; }
            set { ForeignField.Text = value; }
        }

        public DateTime RegistrationDate
        {
            get { return RegistrationDateField.Value; }
            set
            {
                if ( value != null )
                    RegistrationDateField.Value = value;
                else RegistrationDateField.Value = DateTime.MinValue;
            }
        }

        public string Ogrn
        {
            get { return OgrnField.Text; }
            set { OgrnField.Text = value; }
        }

        public string INN
        {
            get { return InnField.Text; }
            set { InnField.Text = value; }
        }

        public string KPP
        {
            get { return KppField.Text; }
            set { KppField.Text = value; }
        }

        public string Okpo
        {
            get { return OkpoField.Text; }
            set { OkpoField.Text = value; }
        }
        #endregion

        public event EventHandler PropertyChanged;
        public void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        public IEntityControlView PartnerView
        {
            get { return PartnerControl; }
        }

        public EntityPresenter<Partner> Partner
        {
            get { return PartnerControl.Presenter as EntityPresenter<Partner>; }
        }

        public IEntityControlView SigningView
        {
            get { return SigningControl; }
        }

        public EntityPresenter<Signing> Signing
        {
            get { return SigningControl.Presenter as EntityPresenter<Signing>; }
        }


        public IEntityControlView AccessTypeView
        {
            get { return AccessControl; }
        }

        public EntityPresenter<AccessType> AccessType
        {
            get { return AccessControl.Presenter as EntityPresenter<AccessType>; }
        }

        public IEntityControlView FlagView
        {
            get { return FlagControl; }
        }

        public EntityPresenter<Flag> Flag
        {
            get { return FlagControl.Presenter as EntityPresenter<Flag>; }
        }

        private IEditorToolView _editorToolView;
        public IEditorToolView EditorToolView
        {
            get { return _editorToolView; }
            set
            {
                if ( value == null )
                    return;

                _editorToolView = value;
                _editorToolView.SaveData += () => Invoke (InfoChange);
                _editorToolView.DeleteData += () => Invoke (InfoChange);
            }
        }

        #region Classificators
        public IClassificatorView OkvedView
        {
            get { return null; }
        }

        public ClassificatorPresenter<Okved> OkvedPresenter
        {
            get { return null; }
        }


        public IClassificatorView OkopfView
        {
            get { return OkopfField; }
        }

        public ClassificatorPresenter<Okopf> OkopfPresenter
        {
            get { return OkopfField.Presenter as ClassificatorPresenter<Okopf>; }
        }


        public IClassificatorView OkfsView
        {
            get { return OkfsField; }
        }

        public ClassificatorPresenter<Okfs> OkfsPresenter
        {
            get { return OkfsField.Presenter as ClassificatorPresenter<Okfs>; }
        }


        public IClassificatorView OkoguView
        {
            get { return OkoguField; }
        }

        public ClassificatorPresenter<Okogu> OkoguPresenter
        {
            get { return OkoguField.Presenter as ClassificatorPresenter<Okogu>; }
        }
        #endregion


        public event Action InfoChange;
    }
}
