﻿namespace Bookkeeping.ClientApp.View.Counterparties.ContractorInfo
{
    partial class InfoTab
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.AddressTab = new System.Windows.Forms.TabControl();
            this.ContactTab = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.AccountTab = new System.Windows.Forms.TabPage();
            this.DocumentTab = new System.Windows.Forms.TabPage();
            this.SpecificationTab = new System.Windows.Forms.TabPage();
            this.ContactTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.ContactGrid();
            this.AddressTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.AddressGrid();
            this.AccountTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.AccountGrid();
            this.DocumentTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.DocumentGrid();
            this.AddressTab.SuspendLayout();
            this.ContactTab.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.AccountTab.SuspendLayout();
            this.DocumentTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddressTab
            // 
            this.AddressTab.Controls.Add(this.ContactTab);
            this.AddressTab.Controls.Add(this.tabPage2);
            this.AddressTab.Controls.Add(this.AccountTab);
            this.AddressTab.Controls.Add(this.DocumentTab);
            this.AddressTab.Controls.Add(this.SpecificationTab);
            this.AddressTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTab.Location = new System.Drawing.Point(0, 0);
            this.AddressTab.Name = "AddressTab";
            this.AddressTab.SelectedIndex = 0;
            this.AddressTab.Size = new System.Drawing.Size(600, 250);
            this.AddressTab.TabIndex = 0;
            // 
            // ContactTab
            // 
            this.ContactTab.Controls.Add(this.ContactTable);
            this.ContactTab.Location = new System.Drawing.Point(4, 22);
            this.ContactTab.Name = "ContactTab";
            this.ContactTab.Padding = new System.Windows.Forms.Padding(3);
            this.ContactTab.Size = new System.Drawing.Size(592, 224);
            this.ContactTab.TabIndex = 0;
            this.ContactTab.Text = "Контакты";
            this.ContactTab.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.AddressTable);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(592, 224);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Адреса";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // AccountTab
            // 
            this.AccountTab.Controls.Add(this.AccountTable);
            this.AccountTab.Location = new System.Drawing.Point(4, 22);
            this.AccountTab.Name = "AccountTab";
            this.AccountTab.Padding = new System.Windows.Forms.Padding(3);
            this.AccountTab.Size = new System.Drawing.Size(592, 224);
            this.AccountTab.TabIndex = 2;
            this.AccountTab.Text = "Счета";
            this.AccountTab.UseVisualStyleBackColor = true;
            // 
            // DocumentTab
            // 
            this.DocumentTab.Controls.Add(this.DocumentTable);
            this.DocumentTab.Location = new System.Drawing.Point(4, 22);
            this.DocumentTab.Name = "DocumentTab";
            this.DocumentTab.Padding = new System.Windows.Forms.Padding(3);
            this.DocumentTab.Size = new System.Drawing.Size(592, 224);
            this.DocumentTab.TabIndex = 3;
            this.DocumentTab.Text = "Документы";
            this.DocumentTab.UseVisualStyleBackColor = true;
            // 
            // SpecificationTab
            // 
            this.SpecificationTab.Location = new System.Drawing.Point(4, 22);
            this.SpecificationTab.Name = "SpecificationTab";
            this.SpecificationTab.Padding = new System.Windows.Forms.Padding(3);
            this.SpecificationTab.Size = new System.Drawing.Size(592, 224);
            this.SpecificationTab.TabIndex = 4;
            this.SpecificationTab.Text = "Спецификация";
            this.SpecificationTab.UseVisualStyleBackColor = true;
            // 
            // ContactTable
            // 
            this.ContactTable.DataSource = null;
            this.ContactTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactTable.Location = new System.Drawing.Point(3, 3);
            this.ContactTable.Name = "ContactTable";
            this.ContactTable.NameTitle = null;
            this.ContactTable.Size = new System.Drawing.Size(586, 218);
            this.ContactTable.TabIndex = 0;
            // 
            // AddressTable
            // 
            this.AddressTable.DataSource = null;
            this.AddressTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTable.Location = new System.Drawing.Point(3, 3);
            this.AddressTable.Name = "AddressTable";
            this.AddressTable.NameTitle = null;
            this.AddressTable.Size = new System.Drawing.Size(586, 218);
            this.AddressTable.TabIndex = 0;
            // 
            // AccountTable
            // 
            this.AccountTable.DataSource = null;
            this.AccountTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountTable.Location = new System.Drawing.Point(3, 3);
            this.AccountTable.Name = "AccountTable";
            this.AccountTable.NameTitle = null;
            this.AccountTable.Size = new System.Drawing.Size(586, 218);
            this.AccountTable.TabIndex = 0;
            // 
            // DocumentTable
            // 
            this.DocumentTable.DataSource = null;
            this.DocumentTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DocumentTable.Location = new System.Drawing.Point(3, 3);
            this.DocumentTable.Name = "DocumentTable";
            this.DocumentTable.NameTitle = null;
            this.DocumentTable.Size = new System.Drawing.Size(586, 218);
            this.DocumentTable.TabIndex = 0;
            // 
            // InfoTab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.AddressTab);
            this.Name = "InfoTab";
            this.Size = new System.Drawing.Size(600, 250);
            this.AddressTab.ResumeLayout(false);
            this.ContactTab.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.AccountTab.ResumeLayout(false);
            this.DocumentTab.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl AddressTab;
        private System.Windows.Forms.TabPage ContactTab;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage AccountTab;
        private System.Windows.Forms.TabPage DocumentTab;
        private System.Windows.Forms.TabPage SpecificationTab;
        private TableControls.ContactGrid ContactTable;
        private TableControls.AddressGrid AddressTable;
        private TableControls.AccountGrid AccountTable;
        private TableControls.DocumentGrid DocumentTable;
    }
}
