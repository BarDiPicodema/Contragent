﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.Presenter.Counterparties.Table;
using Bookkeeping.ClientApp.Presenter.Counterparties.Info;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.Entities;

namespace Bookkeeping.ClientApp.View.Counterparties.ContractorInfo
{
    public partial class DetailInfoTab : Common.CUIControl, IDetailInfoView
    {
        public DetailInfoTab ()
        {
            InitializeComponent ();

            Presenter = new DetailInfoPresenter (this);
        }

        private void Message (string message)
        {
            MessageBox.Show (message);
        }

        public IPresenter Presenter { get; set; }

        public AccountPresenter AccountPresenter
        {
            get { return AccountDetail.Presenter as AccountPresenter; }
        }

        public AddressPresenter AddressPresenter
        {
            get { return AddressDetail.Presenter as AddressPresenter; }
        }

        public ContactPresenter ContactPresenter
        {
            get { return ContactDetail.Presenter as ContactPresenter; }
        }

        public DocumentPresenter DocumentPresenter
        {
            get { return DocumentDetail.Presenter as DocumentPresenter; }
        }

        public ITemplateGridView<Account> AccountGridView
        {
            get { return AccountTable; }
        }

        public ITemplateGridView<Address> AddressGridView
        {
            get { return AddressTable; }
        }

        public ITemplateGridView<Contact> ContactGridView
        {
            get { return ContactTable; }
        }

        public ITemplateGridView<Document> DocumentGridView
        {
            get { return DocumentTable; }
        }

        public AccountGridPresenter AccountGridPresenter
        {
            get { return AccountTable.Presenter as AccountGridPresenter; }
        }

        public AddressGridPresenter AddressGridPresenter
        {
            get { return AddressTable.Presenter as AddressGridPresenter; }
        }

        public ContactGridPresenter ContactGridPresenter
        {
            get { return ContactTable.Presenter as ContactGridPresenter; }
        }

        public DocumentGridPresenter DocumentGridPresenter
        {
            get { return DocumentTable.Presenter as DocumentGridPresenter; }
        }


        public SpecificationPresenter SpecificationPresenter
        {
            get { return SpecificationView.Presenter as SpecificationPresenter; }
        }

        ISpecificationView IDetailInfoView.SpecificationView
        {
            get { return SpecificationView; }
        }

        public GroupPresenter GroupPresenter
        {
            get { return GroupDetailView.Presenter as GroupPresenter; }
        }

        public IGroupView GroupView
        {
            get { return GroupDetailView; }
        }

        public IAccountView AccountView
        {
            get { return AccountDetail; }
        }

        public IAddressView AddressView
        {
            get { return AddressDetail; }
        }

        public IContactView ContactView
        {
            get { return ContactDetail; }
        }

        public IDocumentView DocumentView
        {
            get { return DocumentDetail; }
        }
    }
}
