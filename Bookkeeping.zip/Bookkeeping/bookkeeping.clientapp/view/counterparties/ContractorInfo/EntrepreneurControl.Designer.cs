﻿namespace Bookkeeping.ClientApp.View.Counterparties.ContactorInfo
{
    partial class EntrepreneurControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.PartnerLb = new System.Windows.Forms.Label();
            this.AliasLb = new System.Windows.Forms.Label();
            this.RegistrationDateLb = new System.Windows.Forms.Label();
            this.KppLb = new System.Windows.Forms.Label();
            this.InnLb = new System.Windows.Forms.Label();
            this.OkpoLb = new System.Windows.Forms.Label();
            this.BriefLb = new System.Windows.Forms.Label();
            this.ForeignLb = new System.Windows.Forms.Label();
            this.NameLb = new System.Windows.Forms.Label();
            this.FlagLb = new System.Windows.Forms.Label();
            this.AliasField = new System.Windows.Forms.TextBox();
            this.NameField = new System.Windows.Forms.TextBox();
            this.BriefField = new System.Windows.Forms.TextBox();
            this.ForeignField = new System.Windows.Forms.TextBox();
            this.InnField = new System.Windows.Forms.TextBox();
            this.KppField = new System.Windows.Forms.TextBox();
            this.OkpoField = new System.Windows.Forms.TextBox();
            this.OkfsLb = new System.Windows.Forms.Label();
            this.OgrnLb = new System.Windows.Forms.Label();
            this.OgrnField = new System.Windows.Forms.TextBox();
            this.OkoguLb = new System.Windows.Forms.Label();
            this.OkopfLb = new System.Windows.Forms.Label();
            this.AccessLb = new System.Windows.Forms.Label();
            this.SigningLb = new System.Windows.Forms.Label();
            this.IsDeleteField = new System.Windows.Forms.CheckBox();
            this.NoteLb = new System.Windows.Forms.Label();
            this.NoteField = new System.Windows.Forms.TextBox();
            this.AddedClassificationLb = new System.Windows.Forms.Label();
            this.AddedClassification = new System.Windows.Forms.ListBox();
            this.RegistrationDateField = new System.Windows.Forms.DateTimePicker();
            this.FlagControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.SigningControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.AccessControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.PartnerControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.OkopfField = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ClassificatorBox();
            this.OkfsField = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ClassificatorBox();
            this.OkoguField = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.ClassificatorBox();
            this.MainTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.ColumnCount = 4;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayout.Controls.Add(this.PartnerLb, 0, 0);
            this.MainTableLayout.Controls.Add(this.AliasLb, 0, 2);
            this.MainTableLayout.Controls.Add(this.RegistrationDateLb, 0, 5);
            this.MainTableLayout.Controls.Add(this.KppLb, 0, 7);
            this.MainTableLayout.Controls.Add(this.InnLb, 0, 6);
            this.MainTableLayout.Controls.Add(this.OkpoLb, 2, 5);
            this.MainTableLayout.Controls.Add(this.BriefLb, 0, 4);
            this.MainTableLayout.Controls.Add(this.ForeignLb, 2, 4);
            this.MainTableLayout.Controls.Add(this.NameLb, 0, 3);
            this.MainTableLayout.Controls.Add(this.FlagLb, 2, 1);
            this.MainTableLayout.Controls.Add(this.AliasField, 1, 2);
            this.MainTableLayout.Controls.Add(this.NameField, 1, 3);
            this.MainTableLayout.Controls.Add(this.BriefField, 1, 4);
            this.MainTableLayout.Controls.Add(this.ForeignField, 3, 4);
            this.MainTableLayout.Controls.Add(this.InnField, 1, 6);
            this.MainTableLayout.Controls.Add(this.KppField, 1, 7);
            this.MainTableLayout.Controls.Add(this.OkpoField, 3, 5);
            this.MainTableLayout.Controls.Add(this.OkfsLb, 2, 7);
            this.MainTableLayout.Controls.Add(this.OgrnLb, 2, 6);
            this.MainTableLayout.Controls.Add(this.OgrnField, 3, 6);
            this.MainTableLayout.Controls.Add(this.OkoguLb, 2, 8);
            this.MainTableLayout.Controls.Add(this.OkopfLb, 0, 8);
            this.MainTableLayout.Controls.Add(this.AccessLb, 2, 0);
            this.MainTableLayout.Controls.Add(this.SigningLb, 0, 1);
            this.MainTableLayout.Controls.Add(this.IsDeleteField, 3, 2);
            this.MainTableLayout.Controls.Add(this.NoteLb, 0, 10);
            this.MainTableLayout.Controls.Add(this.NoteField, 1, 10);
            this.MainTableLayout.Controls.Add(this.AddedClassificationLb, 0, 9);
            this.MainTableLayout.Controls.Add(this.AddedClassification, 1, 9);
            this.MainTableLayout.Controls.Add(this.RegistrationDateField, 1, 5);
            this.MainTableLayout.Controls.Add(this.FlagControl, 3, 1);
            this.MainTableLayout.Controls.Add(this.SigningControl, 1, 1);
            this.MainTableLayout.Controls.Add(this.AccessControl, 3, 0);
            this.MainTableLayout.Controls.Add(this.PartnerControl, 1, 0);
            this.MainTableLayout.Controls.Add(this.OkopfField, 1, 8);
            this.MainTableLayout.Controls.Add(this.OkfsField, 3, 7);
            this.MainTableLayout.Controls.Add(this.OkoguField, 3, 8);
            this.MainTableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 11;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.MainTableLayout.Size = new System.Drawing.Size(600, 370);
            this.MainTableLayout.TabIndex = 0;
            // 
            // PartnerLb
            // 
            this.PartnerLb.AutoSize = true;
            this.PartnerLb.Location = new System.Drawing.Point(3, 0);
            this.PartnerLb.Name = "PartnerLb";
            this.PartnerLb.Size = new System.Drawing.Size(54, 13);
            this.PartnerLb.TabIndex = 0;
            this.PartnerLb.Text = "Партнер*";
            // 
            // AliasLb
            // 
            this.AliasLb.AutoSize = true;
            this.AliasLb.Location = new System.Drawing.Point(3, 52);
            this.AliasLb.Name = "AliasLb";
            this.AliasLb.Size = new System.Drawing.Size(69, 13);
            this.AliasLb.TabIndex = 0;
            this.AliasLb.Text = "Псевдоним*";
            // 
            // RegistrationDateLb
            // 
            this.RegistrationDateLb.AutoSize = true;
            this.RegistrationDateLb.Location = new System.Drawing.Point(3, 130);
            this.RegistrationDateLb.Name = "RegistrationDateLb";
            this.RegistrationDateLb.Size = new System.Drawing.Size(71, 26);
            this.RegistrationDateLb.TabIndex = 0;
            this.RegistrationDateLb.Text = "Дата регистрации";
            // 
            // KppLb
            // 
            this.KppLb.AutoSize = true;
            this.KppLb.Location = new System.Drawing.Point(3, 182);
            this.KppLb.Name = "KppLb";
            this.KppLb.Size = new System.Drawing.Size(30, 13);
            this.KppLb.TabIndex = 0;
            this.KppLb.Text = "КПП";
            // 
            // InnLb
            // 
            this.InnLb.AutoSize = true;
            this.InnLb.Location = new System.Drawing.Point(3, 156);
            this.InnLb.Name = "InnLb";
            this.InnLb.Size = new System.Drawing.Size(31, 13);
            this.InnLb.TabIndex = 0;
            this.InnLb.Text = "ИНН";
            // 
            // OkpoLb
            // 
            this.OkpoLb.AutoSize = true;
            this.OkpoLb.Location = new System.Drawing.Point(303, 130);
            this.OkpoLb.Name = "OkpoLb";
            this.OkpoLb.Size = new System.Drawing.Size(38, 13);
            this.OkpoLb.TabIndex = 0;
            this.OkpoLb.Text = "ОКПО";
            // 
            // BriefLb
            // 
            this.BriefLb.AutoSize = true;
            this.BriefLb.Location = new System.Drawing.Point(3, 104);
            this.BriefLb.Name = "BriefLb";
            this.BriefLb.Size = new System.Drawing.Size(80, 26);
            this.BriefLb.TabIndex = 0;
            this.BriefLb.Text = "Сокращенное (рус.)";
            // 
            // ForeignLb
            // 
            this.ForeignLb.AutoSize = true;
            this.ForeignLb.Location = new System.Drawing.Point(303, 104);
            this.ForeignLb.Name = "ForeignLb";
            this.ForeignLb.Size = new System.Drawing.Size(80, 26);
            this.ForeignLb.TabIndex = 0;
            this.ForeignLb.Text = "Сокращенное (ин.)";
            // 
            // NameLb
            // 
            this.NameLb.AutoSize = true;
            this.NameLb.Location = new System.Drawing.Point(3, 78);
            this.NameLb.Name = "NameLb";
            this.NameLb.Size = new System.Drawing.Size(61, 13);
            this.NameLb.TabIndex = 0;
            this.NameLb.Text = "Название*";
            // 
            // FlagLb
            // 
            this.FlagLb.AutoSize = true;
            this.FlagLb.Location = new System.Drawing.Point(303, 26);
            this.FlagLb.Name = "FlagLb";
            this.FlagLb.Size = new System.Drawing.Size(39, 13);
            this.FlagLb.TabIndex = 0;
            this.FlagLb.Text = "Флаг*";
            // 
            // AliasField
            // 
            this.AliasField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.AliasField, 2);
            this.AliasField.Location = new System.Drawing.Point(103, 55);
            this.AliasField.Name = "AliasField";
            this.AliasField.Size = new System.Drawing.Size(294, 20);
            this.AliasField.TabIndex = 1;
            this.AliasField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NameField
            // 
            this.NameField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.NameField, 3);
            this.NameField.Location = new System.Drawing.Point(103, 81);
            this.NameField.Name = "NameField";
            this.NameField.Size = new System.Drawing.Size(494, 20);
            this.NameField.TabIndex = 1;
            this.NameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // BriefField
            // 
            this.BriefField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BriefField.Location = new System.Drawing.Point(103, 107);
            this.BriefField.Name = "BriefField";
            this.BriefField.Size = new System.Drawing.Size(194, 20);
            this.BriefField.TabIndex = 1;
            this.BriefField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // ForeignField
            // 
            this.ForeignField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ForeignField.Location = new System.Drawing.Point(403, 107);
            this.ForeignField.Name = "ForeignField";
            this.ForeignField.Size = new System.Drawing.Size(194, 20);
            this.ForeignField.TabIndex = 1;
            this.ForeignField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // InnField
            // 
            this.InnField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InnField.Location = new System.Drawing.Point(103, 159);
            this.InnField.Name = "InnField";
            this.InnField.Size = new System.Drawing.Size(194, 20);
            this.InnField.TabIndex = 1;
            this.InnField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // KppField
            // 
            this.KppField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.KppField.Location = new System.Drawing.Point(103, 185);
            this.KppField.Name = "KppField";
            this.KppField.Size = new System.Drawing.Size(194, 20);
            this.KppField.TabIndex = 1;
            this.KppField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // OkpoField
            // 
            this.OkpoField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OkpoField.Location = new System.Drawing.Point(403, 133);
            this.OkpoField.Name = "OkpoField";
            this.OkpoField.Size = new System.Drawing.Size(194, 20);
            this.OkpoField.TabIndex = 1;
            this.OkpoField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // OkfsLb
            // 
            this.OkfsLb.AutoSize = true;
            this.OkfsLb.Location = new System.Drawing.Point(303, 182);
            this.OkfsLb.Name = "OkfsLb";
            this.OkfsLb.Size = new System.Drawing.Size(40, 13);
            this.OkfsLb.TabIndex = 0;
            this.OkfsLb.Text = "ОКФС";
            // 
            // OgrnLb
            // 
            this.OgrnLb.AutoSize = true;
            this.OgrnLb.Location = new System.Drawing.Point(303, 156);
            this.OgrnLb.Name = "OgrnLb";
            this.OgrnLb.Size = new System.Drawing.Size(36, 13);
            this.OgrnLb.TabIndex = 0;
            this.OgrnLb.Text = "ОГРН";
            // 
            // OgrnField
            // 
            this.OgrnField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OgrnField.Location = new System.Drawing.Point(403, 159);
            this.OgrnField.Name = "OgrnField";
            this.OgrnField.Size = new System.Drawing.Size(194, 20);
            this.OgrnField.TabIndex = 1;
            this.OgrnField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // OkoguLb
            // 
            this.OkoguLb.AutoSize = true;
            this.OkoguLb.Location = new System.Drawing.Point(303, 208);
            this.OkoguLb.Name = "OkoguLb";
            this.OkoguLb.Size = new System.Drawing.Size(44, 13);
            this.OkoguLb.TabIndex = 0;
            this.OkoguLb.Text = "ОКОГУ";
            // 
            // OkopfLb
            // 
            this.OkopfLb.AutoSize = true;
            this.OkopfLb.Location = new System.Drawing.Point(3, 208);
            this.OkopfLb.Name = "OkopfLb";
            this.OkopfLb.Size = new System.Drawing.Size(49, 13);
            this.OkopfLb.TabIndex = 0;
            this.OkopfLb.Text = "ОКОПФ";
            // 
            // AccessLb
            // 
            this.AccessLb.AutoSize = true;
            this.AccessLb.Location = new System.Drawing.Point(303, 0);
            this.AccessLb.Name = "AccessLb";
            this.AccessLb.Size = new System.Drawing.Size(48, 13);
            this.AccessLb.TabIndex = 0;
            this.AccessLb.Text = "Доступ*";
            // 
            // SigningLb
            // 
            this.SigningLb.AutoSize = true;
            this.SigningLb.Location = new System.Drawing.Point(3, 26);
            this.SigningLb.Name = "SigningLb";
            this.SigningLb.Size = new System.Drawing.Size(61, 13);
            this.SigningLb.TabIndex = 0;
            this.SigningLb.Text = "Важность*";
            // 
            // IsDeleteField
            // 
            this.IsDeleteField.AutoSize = true;
            this.IsDeleteField.Location = new System.Drawing.Point(403, 55);
            this.IsDeleteField.Name = "IsDeleteField";
            this.IsDeleteField.Size = new System.Drawing.Size(84, 17);
            this.IsDeleteField.TabIndex = 2;
            this.IsDeleteField.Text = "Удаленный";
            this.IsDeleteField.UseVisualStyleBackColor = true;
            this.IsDeleteField.CheckedChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NoteLb
            // 
            this.NoteLb.AutoSize = true;
            this.NoteLb.Location = new System.Drawing.Point(3, 318);
            this.NoteLb.Name = "NoteLb";
            this.NoteLb.Size = new System.Drawing.Size(51, 13);
            this.NoteLb.TabIndex = 0;
            this.NoteLb.Text = "Заметка";
            // 
            // NoteField
            // 
            this.NoteField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.NoteField, 3);
            this.NoteField.Location = new System.Drawing.Point(103, 321);
            this.NoteField.Multiline = true;
            this.NoteField.Name = "NoteField";
            this.NoteField.Size = new System.Drawing.Size(494, 46);
            this.NoteField.TabIndex = 3;
            this.NoteField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // AddedClassificationLb
            // 
            this.AddedClassificationLb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddedClassificationLb.AutoSize = true;
            this.AddedClassificationLb.Location = new System.Drawing.Point(3, 234);
            this.AddedClassificationLb.Name = "AddedClassificationLb";
            this.AddedClassificationLb.Size = new System.Drawing.Size(94, 26);
            this.AddedClassificationLb.TabIndex = 0;
            this.AddedClassificationLb.Text = "Доп. классификаторы";
            // 
            // AddedClassification
            // 
            this.AddedClassification.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.AddedClassification, 2);
            this.AddedClassification.FormattingEnabled = true;
            this.AddedClassification.Location = new System.Drawing.Point(103, 237);
            this.AddedClassification.Name = "AddedClassification";
            this.AddedClassification.Size = new System.Drawing.Size(294, 69);
            this.AddedClassification.TabIndex = 4;
            // 
            // RegistrationDateField
            // 
            this.RegistrationDateField.Location = new System.Drawing.Point(103, 133);
            this.RegistrationDateField.Name = "RegistrationDateField";
            this.RegistrationDateField.Size = new System.Drawing.Size(175, 20);
            this.RegistrationDateField.TabIndex = 7;
            this.RegistrationDateField.ValueChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // FlagControl
            // 
            this.FlagControl.DataSource = null;
            this.FlagControl.DisplayProperty = "TypeName";
            this.FlagControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlagControl.Location = new System.Drawing.Point(402, 28);
            this.FlagControl.Margin = new System.Windows.Forms.Padding(2);
            this.FlagControl.Name = "FlagControl";
            this.FlagControl.NameTitle = null;
            this.FlagControl.Presenter = null;
            this.FlagControl.SelectedEntity = null;
            this.FlagControl.Size = new System.Drawing.Size(196, 22);
            this.FlagControl.TabIndex = 8;
            // 
            // SigningControl
            // 
            this.SigningControl.DataSource = null;
            this.SigningControl.DisplayProperty = "TypeName";
            this.SigningControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SigningControl.Location = new System.Drawing.Point(102, 28);
            this.SigningControl.Margin = new System.Windows.Forms.Padding(2);
            this.SigningControl.Name = "SigningControl";
            this.SigningControl.NameTitle = null;
            this.SigningControl.Presenter = null;
            this.SigningControl.SelectedEntity = null;
            this.SigningControl.Size = new System.Drawing.Size(196, 22);
            this.SigningControl.TabIndex = 8;
            // 
            // AccessControl
            // 
            this.AccessControl.DataSource = null;
            this.AccessControl.DisplayProperty = "TypeName";
            this.AccessControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccessControl.Location = new System.Drawing.Point(402, 2);
            this.AccessControl.Margin = new System.Windows.Forms.Padding(2);
            this.AccessControl.Name = "AccessControl";
            this.AccessControl.NameTitle = null;
            this.AccessControl.Presenter = null;
            this.AccessControl.SelectedEntity = null;
            this.AccessControl.Size = new System.Drawing.Size(196, 22);
            this.AccessControl.TabIndex = 9;
            // 
            // PartnerControl
            // 
            this.PartnerControl.DataSource = null;
            this.PartnerControl.DisplayProperty = "Alias";
            this.PartnerControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PartnerControl.Location = new System.Drawing.Point(102, 2);
            this.PartnerControl.Margin = new System.Windows.Forms.Padding(2);
            this.PartnerControl.Name = "PartnerControl";
            this.PartnerControl.NameTitle = null;
            this.PartnerControl.Presenter = null;
            this.PartnerControl.SelectedEntity = null;
            this.PartnerControl.Size = new System.Drawing.Size(196, 22);
            this.PartnerControl.TabIndex = 9;
            // 
            // OkopfField
            // 
            this.OkopfField.Classificator = null;
            this.OkopfField.ClassificatorCode = "";
            this.OkopfField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OkopfField.Location = new System.Drawing.Point(103, 211);
            this.OkopfField.Name = "OkopfField";
            this.OkopfField.NameTitle = null;
            this.OkopfField.Presenter = null;
            this.OkopfField.Size = new System.Drawing.Size(194, 20);
            this.OkopfField.TabIndex = 10;
            // 
            // OkfsField
            // 
            this.OkfsField.Classificator = null;
            this.OkfsField.ClassificatorCode = "";
            this.OkfsField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OkfsField.Location = new System.Drawing.Point(403, 185);
            this.OkfsField.Name = "OkfsField";
            this.OkfsField.NameTitle = null;
            this.OkfsField.Presenter = null;
            this.OkfsField.Size = new System.Drawing.Size(194, 20);
            this.OkfsField.TabIndex = 10;
            // 
            // OkoguField
            // 
            this.OkoguField.Classificator = null;
            this.OkoguField.ClassificatorCode = "";
            this.OkoguField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OkoguField.Location = new System.Drawing.Point(403, 211);
            this.OkoguField.Name = "OkoguField";
            this.OkoguField.NameTitle = null;
            this.OkoguField.Presenter = null;
            this.OkoguField.Size = new System.Drawing.Size(194, 20);
            this.OkoguField.TabIndex = 10;
            // 
            // EntrepreneurControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "EntrepreneurControl";
            this.Size = new System.Drawing.Size(600, 370);
            this.MainTableLayout.ResumeLayout(false);
            this.MainTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.Label PartnerLb;
        private System.Windows.Forms.Label AliasLb;
        private System.Windows.Forms.Label NameLb;
        private System.Windows.Forms.Label BriefLb;
        private System.Windows.Forms.Label ForeignLb;
        private System.Windows.Forms.Label InnLb;
        private System.Windows.Forms.Label OkfsLb;
        private System.Windows.Forms.Label OkoguLb;
        private System.Windows.Forms.Label RegistrationDateLb;
        private System.Windows.Forms.Label KppLb;
        private System.Windows.Forms.Label OkpoLb;
        private System.Windows.Forms.Label OgrnLb;
        private System.Windows.Forms.Label AccessLb;
        private System.Windows.Forms.Label FlagLb;
        private System.Windows.Forms.TextBox AliasField;
        private System.Windows.Forms.TextBox NameField;
        private System.Windows.Forms.TextBox BriefField;
        private System.Windows.Forms.TextBox ForeignField;
        private System.Windows.Forms.TextBox InnField;
        private System.Windows.Forms.TextBox KppField;
        private System.Windows.Forms.TextBox OkpoField;
        private System.Windows.Forms.TextBox OgrnField;
        private System.Windows.Forms.Label OkopfLb;
        private System.Windows.Forms.Label SigningLb;
        private System.Windows.Forms.CheckBox IsDeleteField;
        private System.Windows.Forms.Label NoteLb;
        private System.Windows.Forms.Label AddedClassificationLb;
        private System.Windows.Forms.TextBox NoteField;
        private System.Windows.Forms.ListBox AddedClassification;
        private System.Windows.Forms.DateTimePicker RegistrationDateField;
        private ExtraControls.EditEntityBoxControl FlagControl;
        private ExtraControls.EditEntityBoxControl SigningControl;
        private ExtraControls.EntityBoxControl AccessControl;
        private ExtraControls.EntityBoxControl PartnerControl;
        private ExtraControls.ClassificatorBox OkopfField;
        private ExtraControls.ClassificatorBox OkfsField;
        private ExtraControls.ClassificatorBox OkoguField;
    }
}
