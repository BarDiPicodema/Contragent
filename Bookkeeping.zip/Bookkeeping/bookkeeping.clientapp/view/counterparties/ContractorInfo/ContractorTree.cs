﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.ClientApp.View.Counterparties.ExtraControls;

namespace Bookkeeping.ClientApp.View.Counterparties.ContractorInfo
{
    //TODO selected contractor
    public partial class ContractorTree : Common.CUIControl, IContractorTreeView
    {
        public ContractorTree ()
        {
            InitializeComponent ();
            
            Presenter = new ContractorTreePresenter (this, new Model.AccessServiceModel<Data.Entities.Partner> ());

            Tree.MouseDoubleClick += (sender, args) => Invoke (ContractorView);
        }

        public Presenter.Common.IPresenter Presenter
        {
            get;
            set;
        }

        public object CheckedItem
        {
            get { return ( Tree.SelectedNode != null ) ? ( Tree.SelectedNode as ContractorTreeNode<Data.Interface.ICounterparties> ).Entity : null; }
        }

        public TreeNode CheckedNode
        {
            get { return Tree.SelectedNode; }
        }


        public event Action ContractorView;

        public event Action CheckedTreeItem;


        TreeNodeCollection Presenter.Common.IViewTreeControl.Nodes
        {
            get
            {
                return Tree.Nodes;
            }
        }

        public void Expand ()
        {
            Tree.ExpandAll ();
        }
    }
}
