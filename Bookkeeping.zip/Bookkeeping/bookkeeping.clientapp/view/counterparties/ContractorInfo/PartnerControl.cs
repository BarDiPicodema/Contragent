﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.Data.Interface;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;

namespace Bookkeeping.ClientApp.View.Counterparties.ContactorInfo
{
    public partial class PartnerControl : Common.CUIControlAccess, IPartnerView
    {
        public PartnerControl () 
            : base ()
        {
            InitializeComponent ();

            Presenter = new PartnerPresenter (this, new Model.AccessServiceModel<Data.Entities.Partner> ());
            SigningControl.Presenter = new EntityPresenter<Signing> (SigningControl, new Model.ServiceModel<Signing> ());
            FlagControl.Presenter = new EntityPresenter<Flag> (FlagControl, new Model.ServiceModel<Flag> ());
            
            //TODO: CurrentUser AccessType
            AccessControl.Presenter = new EntityPresenter<AccessType> (AccessControl, new Model.ServiceModel<AccessType> ());
            AccessPresenter = AccessTypeView;
        }

        public IPresenter Presenter { get; set; }

        public Partner Partner { get; set; }

        public string Alias
        {
            get { return AliasField.Text; }
            set { AliasField.Text = value; }
        }

        public new string Region
        {
            get { return RegionField.Text; }
            set { RegionField.Text = value; }
        }

        public string Activity
        {
            get { return ActivityField.Text; }
            set { ActivityField.Text = value; }
        }

        public StateEntity IsDelete
        {
            get { return ( IsDeleteField.Checked ) ? StateEntity.DeleteEntity : StateEntity.ExistsEntity; }
            set { IsDeleteField.Checked = ( value == StateEntity.DeleteEntity ) ? true : false; }
        }

        public string Process
        {
            get
            {
                throw new NotImplementedException ();
            }
            set
            {
                throw new NotImplementedException ();
            }
        }

        public event EventHandler PropertyChanged;
        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }

        public Presenter.Counterparties.Extra.IEntityControlView SigningView
        {
            get { return SigningControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<Signing> Signing
        {
            get { return SigningControl.Presenter as EntityPresenter<Signing>; }
        }


        public Presenter.Counterparties.Extra.IEntityControlView AccessTypeView
        {
            get { return AccessControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<AccessType> AccessType
        {
            get { return AccessControl.Presenter as EntityPresenter<AccessType>; }
        }

        public Presenter.Counterparties.Extra.IEntityControlView FlagView
        {
            get { return FlagControl; }
        }

        public Presenter.Counterparties.Extra.EntityPresenter<Flag> Flag
        {
            get { return FlagControl.Presenter as EntityPresenter<Flag>; }
        }

        public Presenter.Counterparties.Menu.IEditorToolView _editorToolView;
        public Presenter.Counterparties.Menu.IEditorToolView EditorToolView
        {
            get { return _editorToolView; }
            set
            {
                if ( value == null )
                    return;

                _editorToolView = value;
                _editorToolView.SaveData += () => Invoke (InfoChange);
                _editorToolView.DeleteData += () => Invoke (InfoChange);
            }
        }


        public event Action InfoChange;
    }
}
