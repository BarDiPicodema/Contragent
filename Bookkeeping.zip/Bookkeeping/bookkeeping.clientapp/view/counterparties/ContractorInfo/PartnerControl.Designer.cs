﻿namespace Bookkeeping.ClientApp.View.Counterparties.ContactorInfo
{
    partial class PartnerControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.AliasField = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.RegionField = new System.Windows.Forms.TextBox();
            this.ActivityField = new System.Windows.Forms.TextBox();
            this.IsDeleteField = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.AccessControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.FlagControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.SigningControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.AliasField, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.RegionField, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.ActivityField, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.IsDeleteField, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.AccessControl, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.FlagControl, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.SigningControl, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(600, 137);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Псевдоним*";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(317, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Пользователь";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Регион";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Деятельность";
            // 
            // AliasField
            // 
            this.AliasField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AliasField.Location = new System.Drawing.Point(103, 63);
            this.AliasField.Name = "AliasField";
            this.AliasField.Size = new System.Drawing.Size(194, 20);
            this.AliasField.TabIndex = 1;
            this.AliasField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox2.Location = new System.Drawing.Point(403, 63);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(194, 20);
            this.textBox2.TabIndex = 1;
            // 
            // RegionField
            // 
            this.RegionField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.RegionField, 2);
            this.RegionField.Location = new System.Drawing.Point(103, 89);
            this.RegionField.Name = "RegionField";
            this.RegionField.Size = new System.Drawing.Size(294, 20);
            this.RegionField.TabIndex = 1;
            this.RegionField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // ActivityField
            // 
            this.ActivityField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ActivityField.Location = new System.Drawing.Point(103, 115);
            this.ActivityField.Name = "ActivityField";
            this.ActivityField.Size = new System.Drawing.Size(194, 20);
            this.ActivityField.TabIndex = 1;
            this.ActivityField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // IsDeleteField
            // 
            this.IsDeleteField.AutoSize = true;
            this.IsDeleteField.Location = new System.Drawing.Point(403, 33);
            this.IsDeleteField.Name = "IsDeleteField";
            this.IsDeleteField.Size = new System.Drawing.Size(84, 17);
            this.IsDeleteField.TabIndex = 2;
            this.IsDeleteField.Text = "Удаленный";
            this.IsDeleteField.UseVisualStyleBackColor = true;
            this.IsDeleteField.CheckedChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Доступ*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Важность*";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(358, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Флаг*";
            // 
            // AccessControl
            // 
            this.AccessControl.DataSource = null;
            this.AccessControl.DisplayProperty = "TypeName";
            this.AccessControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.AccessControl.Location = new System.Drawing.Point(103, 3);
            this.AccessControl.Name = "AccessControl";
            this.AccessControl.NameTitle = null;
            this.AccessControl.Presenter = null;
            this.AccessControl.SelectedEntity = null;
            this.AccessControl.Size = new System.Drawing.Size(194, 21);
            this.AccessControl.TabIndex = 3;
            // 
            // FlagControl
            // 
            this.FlagControl.DataSource = null;
            this.FlagControl.DisplayProperty = "TypeName";
            this.FlagControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.FlagControl.Location = new System.Drawing.Point(403, 3);
            this.FlagControl.Name = "FlagControl";
            this.FlagControl.NameTitle = null;
            this.FlagControl.Presenter = null;
            this.FlagControl.SelectedEntity = null;
            this.FlagControl.Size = new System.Drawing.Size(194, 21);
            this.FlagControl.TabIndex = 4;
            // 
            // SigningControl
            // 
            this.SigningControl.DataSource = null;
            this.SigningControl.DisplayProperty = "TypeName";
            this.SigningControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.SigningControl.Location = new System.Drawing.Point(103, 33);
            this.SigningControl.Name = "SigningControl";
            this.SigningControl.NameTitle = null;
            this.SigningControl.Presenter = null;
            this.SigningControl.SelectedEntity = null;
            this.SigningControl.Size = new System.Drawing.Size(194, 21);
            this.SigningControl.TabIndex = 4;
            // 
            // PartnerControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "PartnerControl";
            this.Size = new System.Drawing.Size(600, 137);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox AliasField;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox RegionField;
        private System.Windows.Forms.TextBox ActivityField;
        private System.Windows.Forms.CheckBox IsDeleteField;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private ExtraControls.EntityBoxControl AccessControl;
        private ExtraControls.EditEntityBoxControl FlagControl;
        private ExtraControls.EditEntityBoxControl SigningControl;

    }
}
