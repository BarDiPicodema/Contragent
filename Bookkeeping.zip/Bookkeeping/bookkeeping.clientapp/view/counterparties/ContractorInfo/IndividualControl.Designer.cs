﻿namespace Bookkeeping.ClientApp.View.Counterparties.ContactorInfo
{
    partial class IndividualControl
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.PartnerLb = new System.Windows.Forms.Label();
            this.AccessLb = new System.Windows.Forms.Label();
            this.FlagLb = new System.Windows.Forms.Label();
            this.NameLb = new System.Windows.Forms.Label();
            this.SigningLb = new System.Windows.Forms.Label();
            this.AliasLb = new System.Windows.Forms.Label();
            this.AliasField = new System.Windows.Forms.TextBox();
            this.SecondNameField = new System.Windows.Forms.TextBox();
            this.NoteLb = new System.Windows.Forms.Label();
            this.NoteField = new System.Windows.Forms.TextBox();
            this.BloodGroupLb = new System.Windows.Forms.Label();
            this.BloodGroupField = new System.Windows.Forms.TextBox();
            this.InnLb = new System.Windows.Forms.Label();
            this.InnField = new System.Windows.Forms.TextBox();
            this.CityzenshipLb = new System.Windows.Forms.Label();
            this.CitizenshipField = new System.Windows.Forms.TextBox();
            this.SnilsField = new System.Windows.Forms.TextBox();
            this.NationalityLb = new System.Windows.Forms.Label();
            this.NationalityField = new System.Windows.Forms.TextBox();
            this.SecondNameLb = new System.Windows.Forms.Label();
            this.FirstNameField = new System.Windows.Forms.TextBox();
            this.SnilsLb = new System.Windows.Forms.Label();
            this.MedLb = new System.Windows.Forms.Label();
            this.MedField = new System.Windows.Forms.TextBox();
            this.BirthPlaceField = new System.Windows.Forms.TextBox();
            this.InfoWorkLb = new System.Windows.Forms.Label();
            this.BirthPlaceLb = new System.Windows.Forms.Label();
            this.WorkInfoField = new System.Windows.Forms.TextBox();
            this.SigningControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.FlagControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EditEntityBoxControl();
            this.PartnerControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.AccessControl = new Bookkeeping.ClientApp.View.Counterparties.ExtraControls.EntityBoxControl();
            this.BirthDateLb = new System.Windows.Forms.Label();
            this.BirthDateField = new System.Windows.Forms.DateTimePicker();
            this.MiddleNameLb = new System.Windows.Forms.Label();
            this.MiddleNameField = new System.Windows.Forms.TextBox();
            this.SexField = new System.Windows.Forms.CheckBox();
            this.IsDeletedField = new System.Windows.Forms.CheckBox();
            this.MainTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTableLayout
            // 
            this.MainTableLayout.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.ColumnCount = 4;
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.MainTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.MainTableLayout.Controls.Add(this.PartnerLb, 0, 0);
            this.MainTableLayout.Controls.Add(this.AccessLb, 2, 0);
            this.MainTableLayout.Controls.Add(this.FlagLb, 2, 1);
            this.MainTableLayout.Controls.Add(this.NameLb, 0, 3);
            this.MainTableLayout.Controls.Add(this.SigningLb, 0, 1);
            this.MainTableLayout.Controls.Add(this.AliasLb, 0, 2);
            this.MainTableLayout.Controls.Add(this.AliasField, 1, 2);
            this.MainTableLayout.Controls.Add(this.SecondNameField, 1, 3);
            this.MainTableLayout.Controls.Add(this.NoteLb, 0, 11);
            this.MainTableLayout.Controls.Add(this.NoteField, 1, 11);
            this.MainTableLayout.Controls.Add(this.BloodGroupLb, 0, 10);
            this.MainTableLayout.Controls.Add(this.BloodGroupField, 1, 10);
            this.MainTableLayout.Controls.Add(this.InnLb, 0, 9);
            this.MainTableLayout.Controls.Add(this.InnField, 1, 9);
            this.MainTableLayout.Controls.Add(this.CityzenshipLb, 0, 8);
            this.MainTableLayout.Controls.Add(this.CitizenshipField, 1, 8);
            this.MainTableLayout.Controls.Add(this.SnilsField, 3, 9);
            this.MainTableLayout.Controls.Add(this.NationalityLb, 2, 8);
            this.MainTableLayout.Controls.Add(this.NationalityField, 3, 8);
            this.MainTableLayout.Controls.Add(this.SecondNameLb, 0, 4);
            this.MainTableLayout.Controls.Add(this.FirstNameField, 1, 4);
            this.MainTableLayout.Controls.Add(this.SnilsLb, 2, 9);
            this.MainTableLayout.Controls.Add(this.MedLb, 2, 10);
            this.MainTableLayout.Controls.Add(this.MedField, 3, 10);
            this.MainTableLayout.Controls.Add(this.BirthPlaceField, 1, 6);
            this.MainTableLayout.Controls.Add(this.InfoWorkLb, 0, 7);
            this.MainTableLayout.Controls.Add(this.BirthPlaceLb, 0, 6);
            this.MainTableLayout.Controls.Add(this.WorkInfoField, 1, 7);
            this.MainTableLayout.Controls.Add(this.SigningControl, 1, 1);
            this.MainTableLayout.Controls.Add(this.FlagControl, 3, 1);
            this.MainTableLayout.Controls.Add(this.PartnerControl, 1, 0);
            this.MainTableLayout.Controls.Add(this.AccessControl, 3, 0);
            this.MainTableLayout.Controls.Add(this.BirthDateLb, 2, 5);
            this.MainTableLayout.Controls.Add(this.BirthDateField, 3, 5);
            this.MainTableLayout.Controls.Add(this.MiddleNameLb, 0, 5);
            this.MainTableLayout.Controls.Add(this.MiddleNameField, 1, 5);
            this.MainTableLayout.Controls.Add(this.SexField, 2, 4);
            this.MainTableLayout.Controls.Add(this.IsDeletedField, 2, 2);
            this.MainTableLayout.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayout.Name = "MainTableLayout";
            this.MainTableLayout.RowCount = 12;
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.MainTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayout.Size = new System.Drawing.Size(600, 340);
            this.MainTableLayout.TabIndex = 0;
            // 
            // PartnerLb
            // 
            this.PartnerLb.AutoSize = true;
            this.PartnerLb.Location = new System.Drawing.Point(3, 0);
            this.PartnerLb.Name = "PartnerLb";
            this.PartnerLb.Size = new System.Drawing.Size(54, 13);
            this.PartnerLb.TabIndex = 0;
            this.PartnerLb.Text = "Партнер*";
            // 
            // AccessLb
            // 
            this.AccessLb.AutoSize = true;
            this.AccessLb.Location = new System.Drawing.Point(303, 0);
            this.AccessLb.Name = "AccessLb";
            this.AccessLb.Size = new System.Drawing.Size(48, 13);
            this.AccessLb.TabIndex = 0;
            this.AccessLb.Text = "Доступ*";
            // 
            // FlagLb
            // 
            this.FlagLb.AutoSize = true;
            this.FlagLb.Location = new System.Drawing.Point(303, 26);
            this.FlagLb.Name = "FlagLb";
            this.FlagLb.Size = new System.Drawing.Size(39, 13);
            this.FlagLb.TabIndex = 0;
            this.FlagLb.Text = "Флаг*";
            // 
            // NameLb
            // 
            this.NameLb.AutoSize = true;
            this.NameLb.Location = new System.Drawing.Point(3, 78);
            this.NameLb.Name = "NameLb";
            this.NameLb.Size = new System.Drawing.Size(60, 13);
            this.NameLb.TabIndex = 0;
            this.NameLb.Text = "Фамилия*";
            // 
            // SigningLb
            // 
            this.SigningLb.AutoSize = true;
            this.SigningLb.Location = new System.Drawing.Point(3, 26);
            this.SigningLb.Name = "SigningLb";
            this.SigningLb.Size = new System.Drawing.Size(57, 13);
            this.SigningLb.TabIndex = 0;
            this.SigningLb.Text = "Важность";
            // 
            // AliasLb
            // 
            this.AliasLb.AutoSize = true;
            this.AliasLb.Location = new System.Drawing.Point(3, 52);
            this.AliasLb.Name = "AliasLb";
            this.AliasLb.Size = new System.Drawing.Size(69, 13);
            this.AliasLb.TabIndex = 0;
            this.AliasLb.Text = "Псевдоним*";
            // 
            // AliasField
            // 
            this.AliasField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AliasField.Location = new System.Drawing.Point(103, 55);
            this.AliasField.Name = "AliasField";
            this.AliasField.Size = new System.Drawing.Size(194, 20);
            this.AliasField.TabIndex = 1;
            this.AliasField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SecondNameField
            // 
            this.SecondNameField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SecondNameField.Location = new System.Drawing.Point(103, 81);
            this.SecondNameField.Name = "SecondNameField";
            this.SecondNameField.Size = new System.Drawing.Size(194, 20);
            this.SecondNameField.TabIndex = 1;
            this.SecondNameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NoteLb
            // 
            this.NoteLb.AutoSize = true;
            this.NoteLb.Location = new System.Drawing.Point(3, 286);
            this.NoteLb.Name = "NoteLb";
            this.NoteLb.Size = new System.Drawing.Size(51, 13);
            this.NoteLb.TabIndex = 0;
            this.NoteLb.Text = "Заметка";
            // 
            // NoteField
            // 
            this.NoteField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.NoteField, 3);
            this.NoteField.Location = new System.Drawing.Point(103, 289);
            this.NoteField.Multiline = true;
            this.NoteField.Name = "NoteField";
            this.NoteField.Size = new System.Drawing.Size(494, 48);
            this.NoteField.TabIndex = 1;
            this.NoteField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // BloodGroupLb
            // 
            this.BloodGroupLb.AutoSize = true;
            this.BloodGroupLb.Location = new System.Drawing.Point(3, 260);
            this.BloodGroupLb.Name = "BloodGroupLb";
            this.BloodGroupLb.Size = new System.Drawing.Size(75, 13);
            this.BloodGroupLb.TabIndex = 0;
            this.BloodGroupLb.Text = "Группа крови";
            // 
            // BloodGroupField
            // 
            this.BloodGroupField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BloodGroupField.Location = new System.Drawing.Point(103, 263);
            this.BloodGroupField.Name = "BloodGroupField";
            this.BloodGroupField.Size = new System.Drawing.Size(194, 20);
            this.BloodGroupField.TabIndex = 1;
            this.BloodGroupField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // InnLb
            // 
            this.InnLb.AutoSize = true;
            this.InnLb.Location = new System.Drawing.Point(3, 234);
            this.InnLb.Name = "InnLb";
            this.InnLb.Size = new System.Drawing.Size(31, 13);
            this.InnLb.TabIndex = 0;
            this.InnLb.Text = "ИНН";
            // 
            // InnField
            // 
            this.InnField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InnField.Location = new System.Drawing.Point(103, 237);
            this.InnField.Name = "InnField";
            this.InnField.Size = new System.Drawing.Size(194, 20);
            this.InnField.TabIndex = 1;
            this.InnField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // CityzenshipLb
            // 
            this.CityzenshipLb.AutoSize = true;
            this.CityzenshipLb.Location = new System.Drawing.Point(3, 208);
            this.CityzenshipLb.Name = "CityzenshipLb";
            this.CityzenshipLb.Size = new System.Drawing.Size(74, 13);
            this.CityzenshipLb.TabIndex = 0;
            this.CityzenshipLb.Text = "Гражданство";
            // 
            // CitizenshipField
            // 
            this.CitizenshipField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CitizenshipField.Location = new System.Drawing.Point(103, 211);
            this.CitizenshipField.Name = "CitizenshipField";
            this.CitizenshipField.Size = new System.Drawing.Size(194, 20);
            this.CitizenshipField.TabIndex = 1;
            this.CitizenshipField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SnilsField
            // 
            this.SnilsField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SnilsField.Location = new System.Drawing.Point(403, 237);
            this.SnilsField.Name = "SnilsField";
            this.SnilsField.Size = new System.Drawing.Size(194, 20);
            this.SnilsField.TabIndex = 1;
            this.SnilsField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // NationalityLb
            // 
            this.NationalityLb.AutoSize = true;
            this.NationalityLb.Location = new System.Drawing.Point(303, 208);
            this.NationalityLb.Name = "NationalityLb";
            this.NationalityLb.Size = new System.Drawing.Size(92, 13);
            this.NationalityLb.TabIndex = 0;
            this.NationalityLb.Text = "Национальность";
            // 
            // NationalityField
            // 
            this.NationalityField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NationalityField.Location = new System.Drawing.Point(403, 211);
            this.NationalityField.Name = "NationalityField";
            this.NationalityField.Size = new System.Drawing.Size(194, 20);
            this.NationalityField.TabIndex = 1;
            this.NationalityField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SecondNameLb
            // 
            this.SecondNameLb.AutoSize = true;
            this.SecondNameLb.Location = new System.Drawing.Point(3, 104);
            this.SecondNameLb.Name = "SecondNameLb";
            this.SecondNameLb.Size = new System.Drawing.Size(33, 13);
            this.SecondNameLb.TabIndex = 0;
            this.SecondNameLb.Text = "Имя*";
            // 
            // FirstNameField
            // 
            this.FirstNameField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FirstNameField.Location = new System.Drawing.Point(103, 107);
            this.FirstNameField.Name = "FirstNameField";
            this.FirstNameField.Size = new System.Drawing.Size(194, 20);
            this.FirstNameField.TabIndex = 1;
            this.FirstNameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SnilsLb
            // 
            this.SnilsLb.AutoSize = true;
            this.SnilsLb.Location = new System.Drawing.Point(303, 234);
            this.SnilsLb.Name = "SnilsLb";
            this.SnilsLb.Size = new System.Drawing.Size(45, 13);
            this.SnilsLb.TabIndex = 0;
            this.SnilsLb.Text = "СНИЛС";
            // 
            // MedLb
            // 
            this.MedLb.AutoSize = true;
            this.MedLb.Location = new System.Drawing.Point(303, 260);
            this.MedLb.Name = "MedLb";
            this.MedLb.Size = new System.Drawing.Size(64, 13);
            this.MedLb.TabIndex = 0;
            this.MedLb.Text = "Мед. полис";
            // 
            // MedField
            // 
            this.MedField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MedField.Location = new System.Drawing.Point(403, 263);
            this.MedField.Name = "MedField";
            this.MedField.Size = new System.Drawing.Size(194, 20);
            this.MedField.TabIndex = 1;
            this.MedField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // BirthPlaceField
            // 
            this.BirthPlaceField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.BirthPlaceField, 3);
            this.BirthPlaceField.Location = new System.Drawing.Point(103, 159);
            this.BirthPlaceField.Name = "BirthPlaceField";
            this.BirthPlaceField.Size = new System.Drawing.Size(494, 20);
            this.BirthPlaceField.TabIndex = 1;
            this.BirthPlaceField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // InfoWorkLb
            // 
            this.InfoWorkLb.AutoSize = true;
            this.InfoWorkLb.Location = new System.Drawing.Point(3, 182);
            this.InfoWorkLb.Name = "InfoWorkLb";
            this.InfoWorkLb.Size = new System.Drawing.Size(79, 13);
            this.InfoWorkLb.TabIndex = 0;
            this.InfoWorkLb.Text = "Инф. о работе";
            // 
            // BirthPlaceLb
            // 
            this.BirthPlaceLb.AutoSize = true;
            this.BirthPlaceLb.Location = new System.Drawing.Point(3, 156);
            this.BirthPlaceLb.Name = "BirthPlaceLb";
            this.BirthPlaceLb.Size = new System.Drawing.Size(92, 13);
            this.BirthPlaceLb.TabIndex = 0;
            this.BirthPlaceLb.Text = "Место рождения";
            // 
            // WorkInfoField
            // 
            this.WorkInfoField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTableLayout.SetColumnSpan(this.WorkInfoField, 3);
            this.WorkInfoField.Location = new System.Drawing.Point(103, 185);
            this.WorkInfoField.Name = "WorkInfoField";
            this.WorkInfoField.Size = new System.Drawing.Size(494, 20);
            this.WorkInfoField.TabIndex = 1;
            this.WorkInfoField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SigningControl
            // 
            this.SigningControl.DataSource = null;
            this.SigningControl.DisplayProperty = "TypeName";
            this.SigningControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SigningControl.Location = new System.Drawing.Point(102, 28);
            this.SigningControl.Margin = new System.Windows.Forms.Padding(2);
            this.SigningControl.Name = "SigningControl";
            this.SigningControl.NameTitle = null;
            this.SigningControl.Presenter = null;
            this.SigningControl.SelectedEntity = null;
            this.SigningControl.Size = new System.Drawing.Size(196, 22);
            this.SigningControl.TabIndex = 5;
            // 
            // FlagControl
            // 
            this.FlagControl.DataSource = null;
            this.FlagControl.DisplayProperty = "TypeName";
            this.FlagControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlagControl.Location = new System.Drawing.Point(402, 28);
            this.FlagControl.Margin = new System.Windows.Forms.Padding(2);
            this.FlagControl.Name = "FlagControl";
            this.FlagControl.NameTitle = null;
            this.FlagControl.Presenter = null;
            this.FlagControl.SelectedEntity = null;
            this.FlagControl.Size = new System.Drawing.Size(196, 22);
            this.FlagControl.TabIndex = 5;
            // 
            // PartnerControl
            // 
            this.PartnerControl.DataSource = null;
            this.PartnerControl.DisplayProperty = "Alias";
            this.PartnerControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PartnerControl.Location = new System.Drawing.Point(102, 2);
            this.PartnerControl.Margin = new System.Windows.Forms.Padding(2);
            this.PartnerControl.Name = "PartnerControl";
            this.PartnerControl.NameTitle = null;
            this.PartnerControl.Presenter = null;
            this.PartnerControl.SelectedEntity = null;
            this.PartnerControl.Size = new System.Drawing.Size(196, 22);
            this.PartnerControl.TabIndex = 6;
            // 
            // AccessControl
            // 
            this.AccessControl.DataSource = null;
            this.AccessControl.DisplayProperty = "TypeName";
            this.AccessControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccessControl.Location = new System.Drawing.Point(402, 2);
            this.AccessControl.Margin = new System.Windows.Forms.Padding(2);
            this.AccessControl.Name = "AccessControl";
            this.AccessControl.NameTitle = null;
            this.AccessControl.Presenter = null;
            this.AccessControl.SelectedEntity = null;
            this.AccessControl.Size = new System.Drawing.Size(196, 22);
            this.AccessControl.TabIndex = 6;
            // 
            // BirthDateLb
            // 
            this.BirthDateLb.AutoSize = true;
            this.BirthDateLb.Location = new System.Drawing.Point(303, 130);
            this.BirthDateLb.Name = "BirthDateLb";
            this.BirthDateLb.Size = new System.Drawing.Size(86, 13);
            this.BirthDateLb.TabIndex = 0;
            this.BirthDateLb.Text = "Дата рождения";
            // 
            // BirthDateField
            // 
            this.BirthDateField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BirthDateField.Location = new System.Drawing.Point(403, 133);
            this.BirthDateField.Name = "BirthDateField";
            this.BirthDateField.Size = new System.Drawing.Size(194, 20);
            this.BirthDateField.TabIndex = 2;
            this.BirthDateField.ValueChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // MiddleNameLb
            // 
            this.MiddleNameLb.AutoSize = true;
            this.MiddleNameLb.Location = new System.Drawing.Point(3, 130);
            this.MiddleNameLb.Name = "MiddleNameLb";
            this.MiddleNameLb.Size = new System.Drawing.Size(54, 13);
            this.MiddleNameLb.TabIndex = 0;
            this.MiddleNameLb.Text = "Отчество";
            // 
            // MiddleNameField
            // 
            this.MiddleNameField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MiddleNameField.Location = new System.Drawing.Point(103, 133);
            this.MiddleNameField.Name = "MiddleNameField";
            this.MiddleNameField.Size = new System.Drawing.Size(194, 20);
            this.MiddleNameField.TabIndex = 1;
            this.MiddleNameField.TextChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // SexField
            // 
            this.SexField.AutoSize = true;
            this.SexField.Location = new System.Drawing.Point(303, 107);
            this.SexField.Name = "SexField";
            this.SexField.Size = new System.Drawing.Size(46, 17);
            this.SexField.TabIndex = 4;
            this.SexField.Text = "Пол";
            this.SexField.UseVisualStyleBackColor = true;
            this.SexField.CheckedChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // IsDeletedField
            // 
            this.IsDeletedField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IsDeletedField.AutoSize = true;
            this.IsDeletedField.Location = new System.Drawing.Point(303, 55);
            this.IsDeletedField.Name = "IsDeletedField";
            this.IsDeletedField.Size = new System.Drawing.Size(94, 17);
            this.IsDeletedField.TabIndex = 3;
            this.IsDeletedField.Text = "Удаленный";
            this.IsDeletedField.UseVisualStyleBackColor = true;
            this.IsDeletedField.CheckedChanged += new System.EventHandler(this.OnPropertyChanged);
            // 
            // IndividualControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTableLayout);
            this.Name = "IndividualControl";
            this.Size = new System.Drawing.Size(600, 340);
            this.MainTableLayout.ResumeLayout(false);
            this.MainTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel MainTableLayout;
        private System.Windows.Forms.Label PartnerLb;
        private System.Windows.Forms.Label AliasLb;
        private System.Windows.Forms.Label AccessLb;
        private System.Windows.Forms.Label FlagLb;
        private System.Windows.Forms.Label NameLb;
        private System.Windows.Forms.Label InfoWorkLb;
        private System.Windows.Forms.Label BirthDateLb;
        private System.Windows.Forms.Label BirthPlaceLb;
        private System.Windows.Forms.Label CityzenshipLb;
        private System.Windows.Forms.Label NationalityLb;
        private System.Windows.Forms.Label InnLb;
        private System.Windows.Forms.Label SnilsLb;
        private System.Windows.Forms.Label BloodGroupLb;
        private System.Windows.Forms.Label NoteLb;
        private System.Windows.Forms.Label SigningLb;
        private System.Windows.Forms.TextBox AliasField;
        private System.Windows.Forms.TextBox SecondNameField;
        private System.Windows.Forms.TextBox WorkInfoField;
        private System.Windows.Forms.TextBox BirthPlaceField;
        private System.Windows.Forms.TextBox CitizenshipField;
        private System.Windows.Forms.TextBox NationalityField;
        private System.Windows.Forms.TextBox InnField;
        private System.Windows.Forms.TextBox SnilsField;
        private System.Windows.Forms.TextBox BloodGroupField;
        private System.Windows.Forms.TextBox NoteField;
        private System.Windows.Forms.DateTimePicker BirthDateField;
        private System.Windows.Forms.CheckBox IsDeletedField;
        private System.Windows.Forms.CheckBox SexField;
        private System.Windows.Forms.Label SecondNameLb;
        private System.Windows.Forms.TextBox FirstNameField;
        private System.Windows.Forms.TextBox MiddleNameField;
        private System.Windows.Forms.Label MiddleNameLb;
        private System.Windows.Forms.Label MedLb;
        private System.Windows.Forms.TextBox MedField;
        private ExtraControls.EditEntityBoxControl SigningControl;
        private ExtraControls.EditEntityBoxControl FlagControl;
        private ExtraControls.EntityBoxControl PartnerControl;
        private ExtraControls.EntityBoxControl AccessControl;
    }
}
