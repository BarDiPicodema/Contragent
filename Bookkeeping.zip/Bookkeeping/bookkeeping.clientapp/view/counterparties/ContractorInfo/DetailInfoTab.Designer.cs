﻿namespace Bookkeeping.ClientApp.View.Counterparties.ContractorInfo
{
    partial class DetailInfoTab
    {
        /// <summary> 
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Обязательный метод для поддержки конструктора - не изменяйте 
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.MainTabControl = new System.Windows.Forms.TabControl();
            this.ContactTab = new System.Windows.Forms.TabPage();
            this.ContactTabSplitContainer = new System.Windows.Forms.SplitContainer();
            this.ContactDetail = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.ContactControl();
            this.ContactTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.ContactGrid();
            this.AddressTab = new System.Windows.Forms.TabPage();
            this.AddressTabSplitContainer = new System.Windows.Forms.SplitContainer();
            this.AddressDetail = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.AddressControl();
            this.AddressTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.AddressGrid();
            this.AccountTab = new System.Windows.Forms.TabPage();
            this.AccountTabSplitContainer = new System.Windows.Forms.SplitContainer();
            this.AccountDetail = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.AccountControl();
            this.AccountTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.AccountGrid();
            this.DocumentTab = new System.Windows.Forms.TabPage();
            this.DocumentTabSplitContainer = new System.Windows.Forms.SplitContainer();
            this.DocumentDetail = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.DocumentControl();
            this.DocumentTable = new Bookkeeping.ClientApp.View.Counterparties.TableControls.DocumentGrid();
            this.SpecificationTab = new System.Windows.Forms.TabPage();
            this.SpecificationView = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.SpecificationControl();
            this.GroupTab = new System.Windows.Forms.TabPage();
            this.GroupDetailView = new Bookkeeping.ClientApp.View.Counterparties.InfoControls.GroupControl();
            this.MainTabControl.SuspendLayout();
            this.ContactTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContactTabSplitContainer)).BeginInit();
            this.ContactTabSplitContainer.Panel1.SuspendLayout();
            this.ContactTabSplitContainer.Panel2.SuspendLayout();
            this.ContactTabSplitContainer.SuspendLayout();
            this.AddressTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddressTabSplitContainer)).BeginInit();
            this.AddressTabSplitContainer.Panel1.SuspendLayout();
            this.AddressTabSplitContainer.Panel2.SuspendLayout();
            this.AddressTabSplitContainer.SuspendLayout();
            this.AccountTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AccountTabSplitContainer)).BeginInit();
            this.AccountTabSplitContainer.Panel1.SuspendLayout();
            this.AccountTabSplitContainer.Panel2.SuspendLayout();
            this.AccountTabSplitContainer.SuspendLayout();
            this.DocumentTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DocumentTabSplitContainer)).BeginInit();
            this.DocumentTabSplitContainer.Panel1.SuspendLayout();
            this.DocumentTabSplitContainer.Panel2.SuspendLayout();
            this.DocumentTabSplitContainer.SuspendLayout();
            this.SpecificationTab.SuspendLayout();
            this.GroupTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTabControl
            // 
            this.MainTabControl.Controls.Add(this.ContactTab);
            this.MainTabControl.Controls.Add(this.AddressTab);
            this.MainTabControl.Controls.Add(this.AccountTab);
            this.MainTabControl.Controls.Add(this.DocumentTab);
            this.MainTabControl.Controls.Add(this.SpecificationTab);
            this.MainTabControl.Controls.Add(this.GroupTab);
            this.MainTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTabControl.Location = new System.Drawing.Point(0, 0);
            this.MainTabControl.Name = "MainTabControl";
            this.MainTabControl.SelectedIndex = 0;
            this.MainTabControl.Size = new System.Drawing.Size(600, 340);
            this.MainTabControl.TabIndex = 0;
            // 
            // ContactTab
            // 
            this.ContactTab.AutoScroll = true;
            this.ContactTab.Controls.Add(this.ContactTabSplitContainer);
            this.ContactTab.Location = new System.Drawing.Point(4, 22);
            this.ContactTab.Name = "ContactTab";
            this.ContactTab.Padding = new System.Windows.Forms.Padding(3);
            this.ContactTab.Size = new System.Drawing.Size(592, 314);
            this.ContactTab.TabIndex = 0;
            this.ContactTab.Text = "Контакты";
            this.ContactTab.UseVisualStyleBackColor = true;
            // 
            // ContactTabSplitContainer
            // 
            this.ContactTabSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactTabSplitContainer.Location = new System.Drawing.Point(3, 3);
            this.ContactTabSplitContainer.Name = "ContactTabSplitContainer";
            this.ContactTabSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // ContactTabSplitContainer.Panel1
            // 
            this.ContactTabSplitContainer.Panel1.Controls.Add(this.ContactDetail);
            // 
            // ContactTabSplitContainer.Panel2
            // 
            this.ContactTabSplitContainer.Panel2.Controls.Add(this.ContactTable);
            this.ContactTabSplitContainer.Panel2MinSize = 50;
            this.ContactTabSplitContainer.Size = new System.Drawing.Size(586, 308);
            this.ContactTabSplitContainer.SplitterDistance = 179;
            this.ContactTabSplitContainer.TabIndex = 0;
            // 
            // ContactDetail
            // 
            this.ContactDetail.Contact = null;
            this.ContactDetail.ContactName = "";
            this.ContactDetail.ContactText = "";
            this.ContactDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactDetail.Location = new System.Drawing.Point(0, 0);
            this.ContactDetail.Name = "ContactDetail";
            this.ContactDetail.NameTitle = "Контакт";
            this.ContactDetail.Note = "";
            this.ContactDetail.Post = "";
            this.ContactDetail.Size = new System.Drawing.Size(586, 179);
            this.ContactDetail.Sub = "";
            this.ContactDetail.TabIndex = 0;
            // 
            // ContactTable
            // 
            this.ContactTable.DataSource = null;
            this.ContactTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContactTable.Location = new System.Drawing.Point(0, 0);
            this.ContactTable.Name = "ContactTable";
            this.ContactTable.NameTitle = null;
            this.ContactTable.Size = new System.Drawing.Size(586, 125);
            this.ContactTable.TabIndex = 0;
            // 
            // AddressTab
            // 
            this.AddressTab.AutoScroll = true;
            this.AddressTab.Controls.Add(this.AddressTabSplitContainer);
            this.AddressTab.Location = new System.Drawing.Point(4, 22);
            this.AddressTab.Name = "AddressTab";
            this.AddressTab.Padding = new System.Windows.Forms.Padding(3);
            this.AddressTab.Size = new System.Drawing.Size(592, 314);
            this.AddressTab.TabIndex = 1;
            this.AddressTab.Text = "Адреса";
            this.AddressTab.UseVisualStyleBackColor = true;
            // 
            // AddressTabSplitContainer
            // 
            this.AddressTabSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTabSplitContainer.Location = new System.Drawing.Point(3, 3);
            this.AddressTabSplitContainer.Name = "AddressTabSplitContainer";
            this.AddressTabSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // AddressTabSplitContainer.Panel1
            // 
            this.AddressTabSplitContainer.Panel1.Controls.Add(this.AddressDetail);
            // 
            // AddressTabSplitContainer.Panel2
            // 
            this.AddressTabSplitContainer.Panel2.Controls.Add(this.AddressTable);
            this.AddressTabSplitContainer.Panel2MinSize = 50;
            this.AddressTabSplitContainer.Size = new System.Drawing.Size(586, 308);
            this.AddressTabSplitContainer.SplitterDistance = 179;
            this.AddressTabSplitContainer.TabIndex = 0;
            // 
            // AddressDetail
            // 
            this.AddressDetail.Address = null;
            this.AddressDetail.Area = "";
            this.AddressDetail.City = "";
            this.AddressDetail.Description = "";
            this.AddressDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressDetail.House = "";
            this.AddressDetail.Index = "";
            this.AddressDetail.Land = "";
            this.AddressDetail.Location = new System.Drawing.Point(0, 0);
            this.AddressDetail.Name = "AddressDetail";
            this.AddressDetail.AddressName = "";
            this.AddressDetail.NameTitle = "Адрес";
            this.AddressDetail.Office = "";
            this.AddressDetail.Settlement = "";
            this.AddressDetail.Size = new System.Drawing.Size(586, 179);
            this.AddressDetail.Street = "";
            this.AddressDetail.Structure = "";
            this.AddressDetail.TabIndex = 0;
            // 
            // AddressTable
            // 
            this.AddressTable.DataSource = null;
            this.AddressTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddressTable.Location = new System.Drawing.Point(0, 0);
            this.AddressTable.Name = "AddressTable";
            this.AddressTable.NameTitle = null;
            this.AddressTable.Size = new System.Drawing.Size(586, 125);
            this.AddressTable.TabIndex = 0;
            // 
            // AccountTab
            // 
            this.AccountTab.AutoScroll = true;
            this.AccountTab.Controls.Add(this.AccountTabSplitContainer);
            this.AccountTab.Location = new System.Drawing.Point(4, 22);
            this.AccountTab.Name = "AccountTab";
            this.AccountTab.Padding = new System.Windows.Forms.Padding(3);
            this.AccountTab.Size = new System.Drawing.Size(592, 314);
            this.AccountTab.TabIndex = 2;
            this.AccountTab.Text = "Счета";
            this.AccountTab.UseVisualStyleBackColor = true;
            // 
            // AccountTabSplitContainer
            // 
            this.AccountTabSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountTabSplitContainer.Location = new System.Drawing.Point(3, 3);
            this.AccountTabSplitContainer.Name = "AccountTabSplitContainer";
            this.AccountTabSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // AccountTabSplitContainer.Panel1
            // 
            this.AccountTabSplitContainer.Panel1.Controls.Add(this.AccountDetail);
            // 
            // AccountTabSplitContainer.Panel2
            // 
            this.AccountTabSplitContainer.Panel2.Controls.Add(this.AccountTable);
            this.AccountTabSplitContainer.Size = new System.Drawing.Size(586, 308);
            this.AccountTabSplitContainer.SplitterDistance = 179;
            this.AccountTabSplitContainer.TabIndex = 0;
            // 
            // AccountDetail
            // 
            this.AccountDetail.Account = null;
            this.AccountDetail.AddressBank = "";
            this.AccountDetail.Bank = "";
            this.AccountDetail.CorAccount = "";
            this.AccountDetail.CorBank = "";
            this.AccountDetail.Description = "";
            this.AccountDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountDetail.Iban = "";
            this.AccountDetail.Location = new System.Drawing.Point(0, 0);
            this.AccountDetail.Name = "AccountDetail";
            this.AccountDetail.AccountName = "";
            this.AccountDetail.NameTitle = "Счет";
            this.AccountDetail.NumberAccount = "";
            this.AccountDetail.Recipient = "";
            this.AccountDetail.Size = new System.Drawing.Size(586, 179);
            this.AccountDetail.TabIndex = 0;
            // 
            // AccountTable
            // 
            this.AccountTable.DataSource = null;
            this.AccountTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountTable.Location = new System.Drawing.Point(0, 0);
            this.AccountTable.Name = "AccountTable";
            this.AccountTable.NameTitle = null;
            this.AccountTable.Size = new System.Drawing.Size(586, 125);
            this.AccountTable.TabIndex = 0;
            // 
            // DocumentTab
            // 
            this.DocumentTab.AutoScroll = true;
            this.DocumentTab.Controls.Add(this.DocumentTabSplitContainer);
            this.DocumentTab.Location = new System.Drawing.Point(4, 22);
            this.DocumentTab.Name = "DocumentTab";
            this.DocumentTab.Padding = new System.Windows.Forms.Padding(3);
            this.DocumentTab.Size = new System.Drawing.Size(592, 314);
            this.DocumentTab.TabIndex = 3;
            this.DocumentTab.Text = "Документы";
            this.DocumentTab.UseVisualStyleBackColor = true;
            // 
            // DocumentTabSplitContainer
            // 
            this.DocumentTabSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DocumentTabSplitContainer.Location = new System.Drawing.Point(3, 3);
            this.DocumentTabSplitContainer.Name = "DocumentTabSplitContainer";
            this.DocumentTabSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // DocumentTabSplitContainer.Panel1
            // 
            this.DocumentTabSplitContainer.Panel1.Controls.Add(this.DocumentDetail);
            // 
            // DocumentTabSplitContainer.Panel2
            // 
            this.DocumentTabSplitContainer.Panel2.Controls.Add(this.DocumentTable);
            this.DocumentTabSplitContainer.Panel2MinSize = 50;
            this.DocumentTabSplitContainer.Size = new System.Drawing.Size(586, 308);
            this.DocumentTabSplitContainer.SplitterDistance = 179;
            this.DocumentTabSplitContainer.TabIndex = 0;
            // 
            // DocumentDetail
            // 
            this.DocumentDetail.Appointment = "";
            this.DocumentDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DocumentDetail.Document = null;
            this.DocumentDetail.DocumentDate = new System.DateTime(2015, 11, 7, 13, 47, 33, 223);
            this.DocumentDetail.DocumentPlace = "";
            this.DocumentDetail.ExpDate = new System.DateTime(2015, 11, 7, 13, 47, 33, 216);
            this.DocumentDetail.Issues = "";
            this.DocumentDetail.Location = new System.Drawing.Point(0, 0);
            this.DocumentDetail.Name = "DocumentDetail";
            this.DocumentDetail.DocumentName = "";
            this.DocumentDetail.NameTitle = "Документ";
            this.DocumentDetail.Note = "";
            this.DocumentDetail.Number = "";
            this.DocumentDetail.Renew = null;
            this.DocumentDetail.Series = "";
            this.DocumentDetail.Size = new System.Drawing.Size(586, 179);
            this.DocumentDetail.SubdivisionCode = null;
            this.DocumentDetail.TabIndex = 0;
            // 
            // DocumentTable
            // 
            this.DocumentTable.DataSource = null;
            this.DocumentTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DocumentTable.Location = new System.Drawing.Point(0, 0);
            this.DocumentTable.Name = "DocumentTable";
            this.DocumentTable.NameTitle = null;
            this.DocumentTable.Size = new System.Drawing.Size(586, 125);
            this.DocumentTable.TabIndex = 0;
            // 
            // SpecificationTab
            // 
            this.SpecificationTab.AutoScroll = true;
            this.SpecificationTab.Controls.Add(this.SpecificationView);
            this.SpecificationTab.Location = new System.Drawing.Point(4, 22);
            this.SpecificationTab.Name = "SpecificationTab";
            this.SpecificationTab.Padding = new System.Windows.Forms.Padding(3);
            this.SpecificationTab.Size = new System.Drawing.Size(592, 314);
            this.SpecificationTab.TabIndex = 4;
            this.SpecificationTab.Text = "Спецификация";
            this.SpecificationTab.UseVisualStyleBackColor = true;
            // 
            // SpecificationView
            // 
            this.SpecificationView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SpecificationView.Location = new System.Drawing.Point(3, 3);
            this.SpecificationView.Name = "SpecificationView";
            this.SpecificationView.NameTitle = null;
            this.SpecificationView.ReadOnly = true;
            this.SpecificationView.RtfText = "{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fnil\\fcharset204 Microsoft" +
    " Sans Serif;}}\r\n\\viewkind4\\uc1\\pard\\f0\\fs17\\par\r\n}\r\n";
            this.SpecificationView.Size = new System.Drawing.Size(586, 308);
            this.SpecificationView.Specification = null;
            this.SpecificationView.TabIndex = 0;
            this.SpecificationView.TextSpecification = "{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fnil\\fcharset204 Microsoft" +
    " Sans Serif;}}\r\n\\viewkind4\\uc1\\pard\\f0\\fs17\\par\r\n}\r\n";
            // 
            // GroupTab
            // 
            this.GroupTab.AutoScroll = true;
            this.GroupTab.Controls.Add(this.GroupDetailView);
            this.GroupTab.Location = new System.Drawing.Point(4, 22);
            this.GroupTab.Name = "GroupTab";
            this.GroupTab.Padding = new System.Windows.Forms.Padding(3);
            this.GroupTab.Size = new System.Drawing.Size(592, 314);
            this.GroupTab.TabIndex = 5;
            this.GroupTab.Text = "Группы";
            this.GroupTab.UseVisualStyleBackColor = true;
            // 
            // GroupDetailView
            // 
            this.GroupDetailView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupDetailView.Location = new System.Drawing.Point(3, 3);
            this.GroupDetailView.Name = "GroupDetailView";
            this.GroupDetailView.NameTitle = "Группа";
            this.GroupDetailView.Size = new System.Drawing.Size(586, 308);
            this.GroupDetailView.TabIndex = 0;
            // 
            // DetailInfoTab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.MainTabControl);
            this.Name = "DetailInfoTab";
            this.Size = new System.Drawing.Size(600, 340);
            this.MainTabControl.ResumeLayout(false);
            this.ContactTab.ResumeLayout(false);
            this.ContactTabSplitContainer.Panel1.ResumeLayout(false);
            this.ContactTabSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContactTabSplitContainer)).EndInit();
            this.ContactTabSplitContainer.ResumeLayout(false);
            this.AddressTab.ResumeLayout(false);
            this.AddressTabSplitContainer.Panel1.ResumeLayout(false);
            this.AddressTabSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AddressTabSplitContainer)).EndInit();
            this.AddressTabSplitContainer.ResumeLayout(false);
            this.AccountTab.ResumeLayout(false);
            this.AccountTabSplitContainer.Panel1.ResumeLayout(false);
            this.AccountTabSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AccountTabSplitContainer)).EndInit();
            this.AccountTabSplitContainer.ResumeLayout(false);
            this.DocumentTab.ResumeLayout(false);
            this.DocumentTabSplitContainer.Panel1.ResumeLayout(false);
            this.DocumentTabSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DocumentTabSplitContainer)).EndInit();
            this.DocumentTabSplitContainer.ResumeLayout(false);
            this.SpecificationTab.ResumeLayout(false);
            this.GroupTab.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl MainTabControl;
        private System.Windows.Forms.TabPage ContactTab;
        private System.Windows.Forms.TabPage AddressTab;
        private System.Windows.Forms.TabPage AccountTab;
        private System.Windows.Forms.TabPage DocumentTab;
        private System.Windows.Forms.TabPage SpecificationTab;
        private System.Windows.Forms.TabPage GroupTab;
        private System.Windows.Forms.SplitContainer ContactTabSplitContainer;
        private System.Windows.Forms.SplitContainer AddressTabSplitContainer;
        private System.Windows.Forms.SplitContainer AccountTabSplitContainer;
        private System.Windows.Forms.SplitContainer DocumentTabSplitContainer;
        private TableControls.ContactGrid ContactTable;
        private TableControls.AddressGrid AddressTable;
        private TableControls.AccountGrid AccountTable;
        private TableControls.DocumentGrid DocumentTable;
        private InfoControls.ContactControl ContactDetail;
        private InfoControls.AddressControl AddressDetail;
        private InfoControls.AccountControl AccountDetail;
        private InfoControls.DocumentControl DocumentDetail;
        private InfoControls.SpecificationControl SpecificationView;
        private InfoControls.GroupControl GroupDetailView;
    }
}
