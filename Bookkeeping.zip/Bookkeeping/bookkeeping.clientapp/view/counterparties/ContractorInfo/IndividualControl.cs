﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bookkeeping.ClientApp.Presenter.Counterparties.ContractorInfo;
using Bookkeeping.Data.Interface;
using Bookkeeping.ClientApp.Presenter.Common;
using Bookkeeping.Data.Entities;
using Bookkeeping.ClientApp.Presenter.Counterparties.Extra;
using Bookkeeping.ClientApp.Presenter.Counterparties.Menu;

namespace Bookkeeping.ClientApp.View.Counterparties.ContactorInfo
{
    public partial class IndividualControl : Common.CUIControlAccess, IIndividualView
    {
        public IndividualControl ()
            : base ()
        {
            InitializeComponent ();

            Presenter = new IndividualPresenter (this, new Model.AccessServiceModel<Data.Entities.Individual> ());

            PartnerControl.Presenter = new EntityPresenter<Partner> (PartnerControl, new Model.AccessServiceModel<Partner> ());
            SigningControl.Presenter = new EntityPresenter<Signing> (SigningControl, new Model.ServiceModel<Signing> ());
            FlagControl.Presenter = new EntityPresenter<Flag> (FlagControl, new Model.ServiceModel<Flag> ());

            ///TODO Service = CurrentUser.List<AccessType>.
            AccessControl.Presenter = new EntityPresenter<AccessType> (AccessControl, new Model.ServiceModel<AccessType> ());
            AccessPresenter = AccessTypeView;
        }

        public IPresenter Presenter
        {
            get;
            set;
        }

        public Data.Entities.Individual Individual
        {
            get;
            set;
        }

        #region Properties
        public string Alias
        {
            get { return AliasField.Text; }
            set { AliasField.Text = value; }
        }

        public string FirstName
        {
            get { return SecondNameField.Text; }
            set { SecondNameField.Text = value; }
        }

        public string SecondName
        {
            get { return FirstNameField.Text; }
            set { FirstNameField.Text = value; }
        }

        public string MiddleName
        {
            get { return MiddleNameField.Text; }
            set { MiddleNameField.Text = value; }
        }

        public Sex Sex
        {
            get { return ( SexField.Checked == true ) ? Sex.Man : Sex.Woman; }
            set { SexField.Checked = ( value == Sex.Man ) ? true : false; }
        }

        public DateTime BirthDate
        {
            get { return BirthDateField.Value; }
            set
            {
                BirthDateField.Value = value;
            }
        }

        public string BirthPlace
        {
            get { return BirthPlaceField.Text; }
            set { BirthPlaceField.Text = value; }
        }

        public string Citizenship
        {
            get { return CitizenshipField.Text; }
            set { CitizenshipField.Text = value; }
        }

        public string INN
        {
            get { return InnField.Text; }
            set { InnField.Text = value; }
        }

        public string Nationality
        {
            get { return NationalityField.Text; }
            set { NationalityField.Text = value; }
        }

        public string Note
        {
            get { return NoteField.Text; }
            set { NoteField.Text = value; }
        }

        public string InfoWork
        {
            get { return WorkInfoField.Text; }
            set { WorkInfoField.Text = value; }
        }

        public string BloodGroup
        {
            get { return BloodGroupField.Text; }
            set { BloodGroupField.Text = value; }
        }

        public string Snils
        {
            get { return SnilsField.Text; }
            set { SnilsField.Text = value; }
        }

        public string Med
        {
            get { return MedField.Text; }
            set { MedField.Text = value; }
        }

        public StateEntity IsDelete
        {
            get { return ( IsDeletedField.Checked == true ) ? StateEntity.DeleteEntity : StateEntity.ExistsEntity; }
            set { IsDeletedField.Checked = ( value == StateEntity.ExistsEntity ) ? false : true; }
        }
        #endregion

        public event EventHandler PropertyChanged;

        private void OnPropertyChanged (object sender, EventArgs e)
        {
            if ( PropertyChanged != null )
                PropertyChanged (this, e);
        }


        public IEntityControlView PartnerView
        {
            get { return PartnerControl; }
        }

        public EntityPresenter<Partner> Partner
        {
            get { return PartnerControl.Presenter as EntityPresenter<Partner>; }
        }

        
        public IEntityControlView SigningView
        {
            get { return SigningControl; }
        }

        public EntityPresenter<Signing> Signing
        {
            get { return SigningControl.Presenter as EntityPresenter<Signing>; }
        }


        public IEntityControlView AccessTypeView
        {
            get { return AccessControl; }
        }

        public EntityPresenter<AccessType> AccessType
        {
            get { return AccessControl.Presenter as EntityPresenter<AccessType>; }
        }

        public IEntityControlView FlagView
        {
            get { return FlagControl; }
        }

        public EntityPresenter<Flag> Flag
        {
            get { return FlagControl.Presenter as EntityPresenter<Flag>; }
        }

        private IEditorToolView _editorToolView;
        public IEditorToolView EditorToolView
        {
            get { return _editorToolView; }
            set 
            {
                if ( value == null )
                    return;

                _editorToolView = value;
                _editorToolView.SaveData += () => Invoke (InfoChange);
                _editorToolView.DeleteData += () => Invoke (InfoChange);
            }
        }

        public event Action InfoChange;
    }
}
